/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package apdutool2;

import apdutool2.commands.ScriptCommand;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Hashtable;

/**
 *
 * @author Anki R. Nelaturu
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Apdu apdu;
        ScriptCommand cmd;
        boolean output = true;
        APDUScriptParser parser = new APDUScriptParser(
                new ByteArrayInputStream(preprocess("./test.scr")));

        try {
            while ((cmd = parser.getScriptCommand()) != null) {
                System.out.println("Executing " + cmd);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] preprocess(String fileName) throws Exception {
        Hashtable<String, String> definesList = new Hashtable<String, String>();
        String symbol = null;
        String value = null;
        int lineNumber = 0;
        String line = null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));

        while ((line = br.readLine()) != null) {
            lineNumber++;
            line = line.trim();
            if (line.length() <= 0) {
                bos.write("\n".getBytes()); // just so that we have real line nu,bers in preprocessed script
                continue;
            }
            if (line.startsWith("#define ")) {
                String rest = line.substring(8);
                rest = rest.trim();
                if (rest.length() <= 0) {
                    throw new Exception("Empty #define statement at " + fileName + "#" + lineNumber);
                }

                int idx = rest.indexOf(" ");
                if (idx == -1) {
                    idx = rest.indexOf("\t");
                }

                if (idx == -1) {
                    symbol = rest;
                    value = "";
                } else {
                    symbol = rest.substring(0, idx).trim();
                    value = rest.substring(idx + 1).trim();
                }
                if (!isValidAPDUScriptDefine(symbol)) { // just piggyback on valid class name
                    throw new Exception("Invalid/Illegal define symbol '" + symbol + "' at " + fileName + "#" + lineNumber);
                }
                value = replaceDefines(value, definesList);
                definesList.put(symbol, value);
                bos.write("\n".getBytes()); // just so that we have real line nu,bers in preprocessed script
                continue;
            }
            // this is regular script line. replace any defines in this line and write it out into bos
            line = replaceDefines(line, definesList);
            bos.write(line.getBytes());
            bos.write("\n".getBytes());
        }

        byte[] pbs = bos.toByteArray();

        //if (Main.keepPreprocessedFiles) {
        FileOutputStream fos = new FileOutputStream(fileName + ".preprocessed");
        fos.write(pbs);
        //}

        return pbs;
    }

    private static String replaceDefines(String line, Hashtable<String, String> definesList) {
        String regexp = null;
        for (String define : definesList.keySet()) {

            regexp = "[ \\t]*" + define + "[ \\t]*";

            line = line.replaceAll(regexp, " " + definesList.get(define) + " ");
        }


        return line;
    }

    public static final boolean isValidAPDUScriptDefine(String id) {
        if (id == null || id.equals("")) {
            return false;
        }

        if (!(Character.isJavaIdentifierStart(id.charAt(0)))) {
            return false;
        }

        for (int i = 1; i < id.length(); i++) {
            if (Character.isJavaIdentifierPart(id.charAt(i)) || id.charAt(i) == '.') {
                continue;
            }

            return false;

        }
        boolean keyword = Arrays.asList(APDU_KEYWORDS).contains(id.toLowerCase());

        return !keyword;
    }
    
    private static final String[] APDU_KEYWORDS = new String[]{
        "select",
        "aid",
        "send",
        "create",
        "on",
        "to",
        "channel",
        "applet",
        "delay",
        "echo",
        "powerdown",
        "powerup",
        "open",
        "close",
        "on",
        "off",
        "output",
        "extended",
        "contacted",
        "contactless"
    };
}
