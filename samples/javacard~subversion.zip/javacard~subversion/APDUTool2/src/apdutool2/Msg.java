/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package apdutool2;

import java.io.PrintStream;
import java.text.MessageFormat;
import java.util.ResourceBundle;

public class Msg {

    protected static ResourceBundle messages = ResourceBundle.getBundle("apdutool2/MessagesBundle");

    public static String eol = System.getProperty("line.separator", "\n");

    protected static PrintStream out = System.out;

    protected static PrintStream err = System.err;

    public void setOut(PrintStream newOut) {
        Msg.out = newOut;
    }

    public void setErr(PrintStream newErr) {
        Msg.err = newErr;
    }

    public static void warn(String msg) {
        // Globals.warnings++;
        // err.print(messages.getString("Msg.warning") + " ");
        Msg.err.println(msg);
    }

    public static void warn(String key, Object[] args) {
        // Globals.warnings++;
        // err.print(messages.getString("Msg.warning") + " ");
        Msg.err.println(MessageFormat.format(Msg.messages.getString(key), args));
    }

    public static void error(String msg) {
        // Globals.errors++;
        // err.print(messages.getString("Msg.error") + " ");
        Msg.err.println(msg);
    }

    public static void error(Exception e) {
        // Globals.errors++;
        // err.print(messages.getString("Msg.error") + " ");
        Msg.err.println(e.getMessage());
    }

    public static void error(String key, Object[] args) {
        // Globals.errors++;
        // err.print(messages.getString("Msg.error") + " ");
        Msg.err.println(MessageFormat.format(Msg.messages.getString(key), args));
    }

    public static void info(String msg) {
        Msg.out.println(msg);
    }

    public static void info(String key, Object[] args) {
        Msg.out.println(MessageFormat.format(Msg.messages.getString(key), args));
    }

    public static String getMessage(String key) {
        return Msg.messages.getString(key);
    }

    public static String getMessage(String key, Object[] args) {
        return MessageFormat.format(Msg.messages.getString(key), args);
    }

    /**
     * Format a byte as a 2 character hexadecimal String.
     * 
     * @param value
     *            The data to format.
     * @return A String representation of <CODE>value</CODE>
     */
    public static String toHexString(byte value) {
        int nvalue = value & 0xff;
        if (nvalue > 0xf) {
            return "0x" + Integer.toHexString(nvalue);
        } else {
            return "0x0" + Integer.toHexString(nvalue);
        }
    }

}
