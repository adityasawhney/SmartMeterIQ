/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package apdutool2.commands;

/**
 *
 * @author Anki R. Nelaturu
 */
public class Data {
    protected String value;
}

class BooleanData extends Data {
    public boolean getValue() {
        return "true".equals(value);
    }
}