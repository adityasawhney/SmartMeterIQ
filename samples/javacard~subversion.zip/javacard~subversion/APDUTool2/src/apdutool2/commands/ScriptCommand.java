/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package apdutool2.commands;

public class ScriptCommand {

    public final static int POWER_UP = 1;
    public final static int POWER_DOWN = 2;
    public final static int DELAY = 3;
    public final static int APDU = 4;
    public final static int ECHOON = 5;
    public final static int ECHOOFF = 6;
    public final static int OUTPUTON = 7;
    public final static int OUTPUTOFF = 8;
    public final static int EXTENDEDON = 9;
    public final static int EXTENDEDOFF = 10;
    public final static int CONTACTED = 11;
    public final static int CONTACTLESS = 12;
    public final static int SELECT = 13;
    public final static int OPEN_CHANNEL = 14;
    public final static int CLOSE_CHANNEL = 15;
    public final static int SEND = 16;
    public final static int PRINT = 17;

    protected int type;
    protected Object data;
    protected Object data1;
    protected Object data2;

    public ScriptCommand(int type) {
        this.type = type;
        this.data = null;
    }

    public ScriptCommand(int type, Object data) {
        this.type = type;
        this.data = data;
    }

     public ScriptCommand(int type, Object data, Object data1) {
        this.type = type;
        this.data = data;
        this.data1 = data1;
    }

    public ScriptCommand(int type, Object data, Object data1,Object data2) {
        this.type = type;
        this.data = data;
        this.data1 = data1;
        this.data2 = data2;
    }

    public int getType() {
        return type;
    }

    public Object getData() {
        return data;
    }

    public Object getSecondData() {
        return data1;
    }

    public Object getThirdData() {
        return data2;
    }

    @Override
    public String toString() {
        return "" + type + " " + data + " " + data1 + " " + data2;
    }

    public void execute() {
        //
    }
}
