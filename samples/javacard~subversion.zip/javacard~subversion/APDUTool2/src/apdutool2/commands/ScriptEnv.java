/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package apdutool2.commands;

import java.util.Hashtable;

/**
 *
 * @author Anki R. Nelaturu
 */
public final class ScriptEnv {
    public static boolean echo;
    public static boolean output;
    public static boolean contacted;
    public static boolean extended;

    public static Hashtable<String, Data> variables = new Hashtable<String, Data>();
}
