/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common
 * Development and Distribution License("CDDL") (collectively, the
 * "License"). You may not use this file except in compliance with the
 * License. You can obtain a copy of the License at
 * http://www.netbeans.org/cddl-gplv2.html
 * or nbbuild/licenses/CDDL-GPL-2-CP. See the License for the
 * specific language governing permissions and limitations under the
 * License.  When distributing the software, include this License Header
 * Notice in each file and include the License file at
 * nbbuild/licenses/CDDL-GPL-2-CP.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the GPL Version 2 section of the License file that
 * accompanied this code. If applicable, add the following below the
 * License Header, with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 *
 * If you wish your version of this file to be governed by only the CDDL
 * or only the GPL Version 2, indicate your decision by adding
 * "[Contributor] elects to include this software in this distribution
 * under the [CDDL or GPL Version 2] license." If you do not indicate a
 * single choice of license, a recipient has the option to distribute
 * your version of this file under either the CDDL, the GPL Version 2 or
 * to extend the choice of license to its licensees as provided above.
 * However, if you add GPL Version 2 code and therefore, elected the GPL
 * Version 2 license, then the option applies only if the new code is
 * made subject to such option by the copyright holder.
 */
package com.sun.javacard.nbtasks;

import com.sun.javacard.AID;
import com.sun.javacard.filemodels.DeploymentXmlAppletEntry;
import com.sun.javacard.filemodels.DeploymentXmlInstanceEntry;
import com.sun.javacard.filemodels.DeploymentXmlModel;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import org.apache.tools.ant.BuildException;

/**
 *
 */
public class DeleteTask extends JCInstallerTask {

    private String instanceID;
    private File instancesFile;

    @Override
    public void execute() throws BuildException {
        if (isWebApplication()) {
            validateInstanceID();
        } else {
            validateInstancesFile();
        }

        if (isWebApplication()) {
            createArg().setValue("delete");

            if (instanceID != null) {
                createArg().setValue("--instance");
                createArg().setValue(instanceID);
            }
            super.execute();
        } else {
            try {
                DeploymentXmlModel mdl;
                BufferedInputStream in = new BufferedInputStream(new FileInputStream(instancesFile));
                try {
                    mdl = new DeploymentXmlModel(in);
                } finally {
                    in.close();
                }

                for (DeploymentXmlAppletEntry e : mdl.getData()) {
                    AID aid = e.getAppletAid();
                    deleteForOneApplet(aid, e.getData());
                }
            } catch (IOException ex) {
                throw new BuildException(ex);
            }
        }
    }

    private void deleteForOneApplet(AID appletAID, List<? extends DeploymentXmlInstanceEntry> instances) throws BuildException {
        for (DeploymentXmlInstanceEntry iEntry : instances) {
            String deployParams = iEntry.getDeploymentParams();
            AID instanceAID = iEntry.getInstanceAID();
            deleteOneInstanceForOneApplet(appletAID, instanceAID, deployParams);
        }
    }

    private void deleteOneInstanceForOneApplet(AID appletAID, AID instanceAID, String deployParams) throws BuildException {
        String applet_ID = appletAID.toString();
        String instance_ID = instanceAID.toString();
        String data = deployParams.trim();
        if (data.length() <= 0) {
            data = null; // if empty don't even send the argument
        }

        super.clearArgs();

        createArg().setValue("delete");

        if (instance_ID != null) {
            createArg().setValue("--instance");
            createArg().setValue(instance_ID);
        }
        super.execute();
    }

    private void validateInstanceID() throws BuildException {
        if (instanceID == null) {
            instanceID = getProject().getProperty("webcontextpath");
        }

        if (instanceID == null) {
            throw new BuildException("InstanceID value not specified");
        }

        instanceID = instanceID.trim();
        if (instanceID.length() <= 0) {
            throw new BuildException("Empty value for InstanceID");
        }
    }

    private void validateInstancesFile() {
        if (instancesFile == null) {
            instancesFile = new File(getProject().getBaseDir(), "nbproject" + File.separatorChar + "deployment.xml");
        }

        if (!instancesFile.exists()) {
            throw new BuildException(instancesFile.getPath() + " does not exist");
        }

        if (!instancesFile.isFile()) {
            throw new BuildException(instancesFile.getPath() + " is not a regular file");
        }
    }

    public String getInstanceID() {
        return instanceID;
    }

    public void setInstanceID(String instanceID) {
        this.instanceID = instanceID;
    }

}
