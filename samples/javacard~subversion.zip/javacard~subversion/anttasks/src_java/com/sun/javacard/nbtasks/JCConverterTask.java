/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common
 * Development and Distribution License("CDDL") (collectively, the
 * "License"). You may not use this file except in compliance with the
 * License. You can obtain a copy of the License at
 * http://www.netbeans.org/cddl-gplv2.html
 * or nbbuild/licenses/CDDL-GPL-2-CP. See the License for the
 * specific language governing permissions and limitations under the
 * License.  When distributing the software, include this License Header
 * Notice in each file and include the License file at
 * nbbuild/licenses/CDDL-GPL-2-CP.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the GPL Version 2 section of the License file that
 * accompanied this code. If applicable, add the following below the
 * License Header, with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 *
 * If you wish your version of this file to be governed by only the CDDL
 * or only the GPL Version 2, indicate your decision by adding
 * "[Contributor] elects to include this software in this distribution
 * under the [CDDL or GPL Version 2] license." If you do not indicate a
 * single choice of license, a recipient has the option to distribute
 * your version of this file under either the CDDL, the GPL Version 2 or
 * to extend the choice of license to its licensees as provided above.
 * However, if you add GPL Version 2 code and therefore, elected the GPL
 * Version 2 license, then the option applies only if the new code is
 * made subject to such option by the copyright holder.
 */
package com.sun.javacard.nbtasks;

import java.io.File;
import java.io.FileFilter;
import org.apache.tools.ant.BuildException;

/**
 * This task converts compiled classes of classic library or application to
 * distributable module in CAP format.
 *
 * Note: this task can be used for classic libraries conversion without modifications.
 * For converting classic applets additional arguments should be provided:
 *  <code>-applet APPLET_AID APPLET_CLASS</code>
 * This can be done via subclassing and overriding setAdditionalArguments() method.
 *
 * Alternatively PackTask could be used for creation of CAP files for classic
 * applications.
 * 
 * @author Mikhail Smirnov
 */
public class JCConverterTask extends JCToolTask {

    public JCConverterTask() {
        super("com.sun.javacard.converter.Main");
    }

    @Override
    public void execute() throws BuildException {
        if (!isClassicApplication() && !isClassicLibrary()) {
            return;
        }
        String expPath = getExportPath();
        if (expPath != null && expPath.length() > 0) {
            expPath = expPath + File.pathSeparator;
        } else {
            expPath = "";
        }
        
        createArg().setValue("-exportpath");
        File jcHome = getFileProp("javacard.home");
        StringBuilder sb = new StringBuilder(jcHome.getAbsolutePath());
        if (!sb.toString().endsWith(File.separator)) {
            sb.append (File.separator);
        }
        sb.append ("api_export_files");
        expPath += sb.toString();
        createArg().setValue(expPath);

        File classDir = getFileProp("build.classes.dir");
        createArg().setValue("-classdir");
        createArg().setFile(classDir);

        File destDir = getFileProp("dist.dir");
        createArg().setValue("-d");
        createArg().setFile(destDir);

        createArg().setValue("-i");
        
        setAdditionalArguments();

        createArg().setValue(getPackageName());
        createArg().setValue(getPackageAID());
        createArg().setValue("1.0");
        super.execute();
    }

    /**
     * This method should be overridden in subclasses that need to add more arguments
     * for Converter command
     * @throws BuildException
     */
    protected void setAdditionalArguments() throws BuildException {
    }

    // Classic library can contain only one Java package
    // so we determine package by any Java class found
    protected String getPackageName() throws BuildException {
        File buildDir = getFileProp("build.classes.dir");
        File[] classFiles = null;
        classFiles = searchFiles(buildDir, "class");
        if (classFiles == null || classFiles.length == 0) {
            throw new BuildException("No classes found in directory: " + buildDir);
        }
        String packageDir = classFiles[0].getParent();
        packageDir = packageDir.substring(buildDir.getPath().length() + 1);
        return packageDir.replace(File.separatorChar, '.');
    }

    /**
     * Gets package.aid property and converts it to 0xZZ:0xYY.. form
     */
    protected String getPackageAID() {
        String aid = getProp("package.aid");
        aid = aid.substring("//aid/".length());
        aid = aid.replaceAll("/", "");
        String packageAID = "";
        char[] aidChars = aid.toCharArray();
        char[] buf = new char[2];
        for (int index = 0; index < aidChars.length;) {
            buf[0] = aidChars[index++];
            buf[1] = aidChars[index++];
            packageAID += "0x" + new String(buf) + ":";
        }
        return packageAID.substring(0, packageAID.length() - 1);
    }

    /**
     * Searches for files with given extension in some directory
     *
     * @param parent directory to search files
     * @param ext extension of files to search
     * @return array of File objects with given extension in given directory
     */
    static File[] searchFiles(File parent, final String ext) {
        if (parent.isDirectory()) {
            File[] files = parent.listFiles(new FileFilter() {

                public boolean accept(File pathname) {
                    return pathname.getName().endsWith("." + ext);
                }
            });
            if (files == null || files.length == 0) {
                for (File child : parent.listFiles()) {
                    files = searchFiles(child, ext);
                    if (files != null && files.length != 0) {
                        break;
                    }
                }
            }
            return files;
        } else {
            return null;
        }
    }
}
