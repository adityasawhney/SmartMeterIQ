/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common
 * Development and Distribution License("CDDL") (collectively, the
 * "License"). You may not use this file except in compliance with the
 * License. You can obtain a copy of the License at
 * http://www.netbeans.org/cddl-gplv2.html
 * or nbbuild/licenses/CDDL-GPL-2-CP. See the License for the
 * specific language governing permissions and limitations under the
 * License.  When distributing the software, include this License Header
 * Notice in each file and include the License file at
 * nbbuild/licenses/CDDL-GPL-2-CP.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the GPL Version 2 section of the License file that
 * accompanied this code. If applicable, add the following below the
 * License Header, with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 *
 * If you wish your version of this file to be governed by only the CDDL
 * or only the GPL Version 2, indicate your decision by adding
 * "[Contributor] elects to include this software in this distribution
 * under the [CDDL or GPL Version 2] license." If you do not indicate a
 * single choice of license, a recipient has the option to distribute
 * your version of this file under either the CDDL, the GPL Version 2 or
 * to extend the choice of license to its licensees as provided above.
 * However, if you add GPL Version 2 code and therefore, elected the GPL
 * Version 2 license, then the option applies only if the new code is
 * made subject to such option by the copyright holder.
 */
package com.sun.javacard.nbtasks;

import java.io.File;
import java.util.logging.Level;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

/**
 *
 * @author Anki R Nelaturu
 */
public class JCPackagerTask extends JCToolTask {

    private boolean overwrite;

    public JCPackagerTask() {
        this(true);
    }

    /**
     * If some subclass needs to forbid overwriting of destination archive
     * its constructor should use super(false);
     * @param force
     */
    public JCPackagerTask(boolean overwrite) {
        super(System.getProperty("packager.task") == null ? "com.sun.javacard.packager.Main" : System.getProperty("packager.task"));
        this.overwrite = overwrite;
    }

    @Override
    public void execute() throws BuildException {
        createArg().setValue("create");
        assert getProject() != null;
        assert getProject().getBaseDir() != null;
        Project p = getProject();
        File basedir = p.getBaseDir();
        if (basedir == null) {
            throw new BuildException("Basedir not set");
        }
        File distBundle = getFileProp("dist.bundle", true);
        createArg().setValue("--out");
        createArg().setFile(distBundle);

        if (overwrite) {
            // we're trying to delete destination file to know if it is created
            // after packager operation
            distBundle.delete();
            createArg().setValue("--force");
        }

        if (isClassicLibrary()) {
            createArg().setValue("--packageaid");
            createArg().setValue(getProject().getProperty("package.aid"));
        }

        boolean signbundle = getBool(PROPERTY_SIGN_BUNDLE);
        if (signbundle) {
            createArg().setValue("--sign");

            createArg().setValue("-K");
            createArg().setFile(new File(getProp("keystore.resolved")));

            createArg().setValue("-S");
            createArg().setValue(getProp("sign.storepass"));

            createArg().setValue("-P");
            createArg().setValue(getProp("sign.passkey"));

            createArg().setValue("-A");
            createArg().setValue(getProp("sign.alias"));
        }

        createArg().setValue("--type");
        createArg().setValue(getType());

        // For classic applets and libraries we need to set --exportpath argument
        if (isClassicLibrary() || isClassicApplication()) {
            String exportPath = getExportPath();
            
            if (exportPath.length() > 0) {
                createArg().setValue("--exportpath");
                createArg().setValue(exportPath);
            }

        }
        setAdditionalArguments();
        File bdirFile = getFileProp("build.dir");
        if (!bdirFile.exists()) {
            throw new BuildException (bdirFile.getAbsolutePath() + " does not exist");
        }
        if (!bdirFile.isDirectory()) {
            throw new BuildException (bdirFile.getAbsolutePath() + " is not a folder");
        }
        createArg().setFile(bdirFile);
        log("Execute\n" + getCommandLine(), Project.MSG_VERBOSE);
        super.execute();
        if (!distBundle.exists()) {
            throw new BuildException("Creation of " + distBundle + " was not successful. See Packager output");
        }
    }

    /**
     * This method should be overridden in subclasses that need to add more arguments
     * for Packager command
     * @throws BuildException
     */
    protected void setAdditionalArguments() throws BuildException {
    }
}
