/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common
 * Development and Distribution License("CDDL") (collectively, the
 * "License"). You may not use this file except in compliance with the
 * License. You can obtain a copy of the License at
 * http://www.netbeans.org/cddl-gplv2.html
 * or nbbuild/licenses/CDDL-GPL-2-CP. See the License for the
 * specific language governing permissions and limitations under the
 * License.  When distributing the software, include this License Header
 * Notice in each file and include the License file at
 * nbbuild/licenses/CDDL-GPL-2-CP.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the GPL Version 2 section of the License file that
 * accompanied this code. If applicable, add the following below the
 * License Header, with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 *
 * If you wish your version of this file to be governed by only the CDDL
 * or only the GPL Version 2, indicate your decision by adding
 * "[Contributor] elects to include this software in this distribution
 * under the [CDDL or GPL Version 2] license." If you do not indicate a
 * single choice of license, a recipient has the option to distribute
 * your version of this file under either the CDDL, the GPL Version 2 or
 * to extend the choice of license to its licensees as provided above.
 * However, if you add GPL Version 2 code and therefore, elected the GPL
 * Version 2 license, then the option applies only if the new code is
 * made subject to such option by the copyright holder.
 */
package com.sun.javacard.nbtasks;

import java.io.File;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

/**
 * Depends on platform.properties and device.properties
 */
public abstract class JCServerTask extends Task {

    boolean inNetBeans() {
        return System.getProperty ("netbeans.home") != null;
    }

    protected void startServer() {
        if (inNetBeans()) {
            return;
        }
        File emulatorBinary = getFileProp("javacard.emulator");
        String[] commandLine = new String[]{
            emulatorBinary.getAbsolutePath(),
            "-ramsize",
            getRamSize(),
            "-e2psize",
            getE2pSize(),
            "-corsize",
            getCorSize(),
            //            debug ? "-debugger" : "",
            //            debug ? "-debugport" : "",
            //            debug ? getProxy2cjcrePort() : "",
            "-e2pfile",
            getEepromFile().getAbsolutePath(),
            "-loggerlevel",
            getLoggerLevel().toLowerCase(),
            "-httpport",
            getHttpPort(),
            "-contactedport",
            getContactedPort(),
            "-contactedprotocol",
            getContactedProtocol(),
            "-contactlessport",
            getContactlessPort(),
            isSuspend() ? "" : "-nosuspend",};

        //??? - Tim

        // FIXME
        // ServerUtils.run(getPlatformID(), getDeviceID(), commandLine);
    }

    protected void resumeServer() {
        if (inNetBeans()) {
            return;
        }
        File emulatorBinary = getFileProp("javacard.emulator");
        String[] commandLine = new String[]{
            emulatorBinary.getAbsolutePath(),
            "-resume",};

        // FIXME
        // ServerUtils.run(getPlatformID(), getDeviceID(), commandLine);
    }

    protected void stopServer() {
        if (inNetBeans()) {
            return;
        }
        // FIXME
        // ServerUtils.kill(getPlatformID(), getDeviceID());
    }

    protected void restartServer() {
        if (inNetBeans()) {
            return;
        }
        stopServer();
        startServer();
    }

    private String getPlatformID() {
        return getProp("javacard.instance.id");
    }

    private String getDeviceID() {
        return getProp("javacard.device.name");
    }

    private String getJCDKHome() {
        return getProp("javacard.home");
    }

    private boolean isSuspend() {
        return !getBool("javacard.device.nosuspend");
    }

    private String getContactedPort() {
        return getProp("javacard.device.contactedPort");
    }

    private String getContactedProtocol() {
        return getProp("javacard.device.contactedProtocol");
    }

    private String getContactlessPort() {
        return getProp("javacard.device.contactlessPort");
    }

    private String getCorSize() {
        return getProp("javacard.device.corSize");
    }

    private String getE2pSize() {
        return getProp("javacard.device.e2pSize");
    }

    private File getEepromFile() {
        File f = getFileProp("javacard.device.eeprom.folder", true);
        String deviceId = getProp("javacard.device.name");
        String ext = getProp ("javacard.device.eprom.file.extension", false);
        if (ext == null) {
            ext = "eprom";
        }
        File epromFile = new File (f, deviceId + '.' + ext);
        return epromFile;
    }

    private String getHttpPort() {
        return getProp("javacard.device.httpPort");
    }

    private String getLoggerLevel() {
        return getProp("javacard.device.loggerLevel");
    }

    private String getProxy2cjcrePort() {
        return getProp("javacard.device.proxy2cjcrePort");
    }

    private String getRamSize() {
        return getProp("javacard.device.ramSize");
    }

    protected boolean getBool (String key) {
        String val = getProp (key, false);
        return val == null ? false : Boolean.valueOf(val);
    }

    protected String getProp (String key) throws BuildException {
        return getProp (key, true);
    }

    protected String getProp (String key, boolean failOnNull) throws BuildException {
        String result = getProject().getProperty(key);
        if (failOnNull && result == null) {
            throw new BuildException (key + " not set");
        }
        return result;
    }

    protected File getFileProp (String key) throws BuildException {
        return getFileProp (key, true);
    }

    protected File getFileProp (String key, boolean mustBeSet) throws BuildException {
        String prop = getProp (key, mustBeSet);
        if (prop != null) {
            prop = prop.replace ('/', File.separatorChar);
            File f = new File(prop);
            File[] roots = File.listRoots();
            boolean absolute = false;
            if (f != null) { //can be null according to spec
                for (File r : roots) {
                    if (prop.startsWith(r.getAbsolutePath())) {
                        absolute = true;
                        break;
                    }
                    File upper = new File (r.getAbsolutePath().toUpperCase());
                    if (upper.exists()) {
                        String s = prop.toUpperCase();
                        if (s.startsWith (upper.getAbsolutePath())) {
                            absolute = true;
                            break;
                        }
                    }
                }
            }
            if (absolute) {
                log ("Resolved " + key + " as absolute file " + f);
                return f;
            }
            f = new File (getProject().getBaseDir(), prop);
            log ("Resolved " + key + " as relative file " + f);
            return f;
        }
        throw new AssertionError(); //should never get here
    }
}
