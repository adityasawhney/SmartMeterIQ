/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 1997-2009 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common
 * Development and Distribution License("CDDL") (collectively, the
 * "License"). You may not use this file except in compliance with the
 * License. You can obtain a copy of the License at
 * http://www.netbeans.org/cddl-gplv2.html
 * or nbbuild/licenses/CDDL-GPL-2-CP. See the License for the
 * specific language governing permissions and limitations under the
 * License.  When distributing the software, include this License Header
 * Notice in each file and include the License file at
 * nbbuild/licenses/CDDL-GPL-2-CP.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the GPL Version 2 section of the License file that
 * accompanied this code. If applicable, add the following below the
 * License Header, with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 * The Original Software is NetBeans. The Initial Developer of the Original
 * Software is Sun Microsystems, Inc. Portions Copyright 1997-2006 Sun
 * Microsystems, Inc. All Rights Reserved.
 *
 * If you wish your version of this file to be governed by only the CDDL
 * or only the GPL Version 2, indicate your decision by adding
 * "[Contributor] elects to include this software in this distribution
 * under the [CDDL or GPL Version 2] license." If you do not indicate a
 * single choice of license, a recipient has the option to distribute
 * your version of this file under either the CDDL, the GPL Version 2 or
 * to extend the choice of license to its licensees as provided above.
 * However, if you add GPL Version 2 code and therefore, elected the GPL
 * Version 2 license, then the option applies only if the new code is
 * made subject to such option by the copyright holder.
 */
package com.sun.javacard.nbtasks;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.types.Path;

/**
 *
 * @author Anki R Nelaturu
 * @author Tim Boudreau
 */
public abstract class JCToolTask extends JCTask {
    public JCToolTask(String className) {
        super.setClassname(className);
    }

    @Override
    public void execute() throws BuildException {
        //super.setDir(new File(getProject().getProperty("javacard.home") + "/bin"));
        super.setClasspath(new Path(getProject(), getProp("javacard.toolClassPath")));
        setFork(!Boolean.getBoolean("javacard.ant.unit.test"));
        createJvmarg().setValue("-Djc.home=" + getProp("javacard.home"));
        log("Execute\n" + getCommandLine(), Project.MSG_VERBOSE);
        executeJava();
    }

    public final String getProjectProperty(String name) {
        return getProject().getProperty(name);
    }

    protected boolean getBool (String key) {
        String val = getProp (key, false);
        return val == null ? false : Boolean.valueOf(val);
    }

    protected String getProp (String key) throws BuildException {
        return getProp (key, true);
    }
    
    protected String getProp (String key, boolean failOnNull) throws BuildException {
        String result = getProject().getProperty(key);
        if (failOnNull && result == null) {
            throw new BuildException (key + " not set");
        }
        return result;
    }

    protected File getFileProp (String key) throws BuildException {
        return getFileProp (key, true);
    }

    protected File getFileProp (String key, boolean mustBeSet) throws BuildException {
        String prop = getProp (key, mustBeSet);
        if (prop != null) {
            prop = prop.replace ('/', File.separatorChar);
            File f = new File(prop);
            File[] roots = File.listRoots();
            boolean absolute = false;
            if (f != null) { //can be null according to spec
                for (File r : roots) {
                    if (prop.startsWith(r.getAbsolutePath())) {
                        absolute = true;
                        break;
                    }
                    File upper = new File (r.getAbsolutePath().toUpperCase());
                    if (upper.exists()) {
                        String s = prop.toUpperCase();
                        if (s.startsWith (upper.getAbsolutePath())) {
                            absolute = true;
                            break;
                        }
                    }
                }
            }
            if (absolute) {
                log ("Resolved " + key + " as absolute file " + f);
                return f;
            }
            f = new File (getProject().getBaseDir(), prop);
            log ("Resolved " + key + " as relative file " + f);
            return f;
        }
        log ("File prop " + key + " not set: " + prop);
        return null;
    }

    /**
     * Returns export path for application based on export.path and
     * dependency.${capFileName}.expfile properties.
     *
     * @return export path that is ready to be passed as --exportpath argument
     * @throws BuildException
     */
    protected String getExportPath() throws BuildException {
        //Export path could be set in export.path property
        String str = getProp("export.path", false);
        if (str == null || str.trim().length() == 0) {
            str = "";
        } else {
            str = str.trim();
        }
        //Or it could be set via dependencies on CAP files via
        // dependency.${capFileName}.expfile properties
        ArrayList<String> expFileKeys = new ArrayList<String>();
        Hashtable ht = getProject().getProperties();
        for (Object obj : ht.keySet()) {
            String key = (String) obj;
            key = key.trim();
            if (key.endsWith(".expfile")) {
                expFileKeys.add(key);
            }
        }
        String exportPath = getExportPathForExpFiles(expFileKeys);
        if (exportPath != null && exportPath.length() > 0) {
            if (str.length() > 0) {
                exportPath += File.pathSeparator + str;
            }
        } else {
            if (str.length() > 0) {
                exportPath = str;
            } else {
                exportPath = "";
            }
        }
        return exportPath;
    }


    /**
     * Returns export path for all EXP files locations
     * @param expFileKeys - list of properties which names end with ".expfile"
     * @return - correct export path for all EXP files locations
     * @throws BuildException
     */
    private String getExportPathForExpFiles(ArrayList<String> expFileKeys) throws BuildException {
        String exportPath = "";
        Hashtable ht = getProject().getProperties();
        for (String expFileKey : expFileKeys) {
            String capFileKey = expFileKey.substring(0, expFileKey.indexOf(".expfile"))
                    + ".origin";
            //FIXME: workaround for incorrect property name of .expfile
            //TDB fixed in recent builds
            if (expFileKey.startsWith("dependency..")) {
                String expFileKey2 = expFileKey.replace("dependency..", "dependency.");
                capFileKey = expFileKey2.substring(0, expFileKey2.indexOf(".expfile"))
                    + ".origin";
            }
            //

            String capFile = (String) ht.get(capFileKey);
            if (capFile == null) {
               throw new BuildException("Couldn't find CAP file corresponding to export file listed in dependencies");
            }

            String packagePath = getPackagePath(capFile);

            if (packagePath != null) {
                String expFile = (String)ht.get(expFileKey);
                int javacardDirIndex = expFile.indexOf(packagePath + "/javacard/");
                String expFileSegment;
                if (javacardDirIndex >= 0) {
                    expFileSegment = expFile.substring(0, javacardDirIndex);
                } else {
                    expFileSegment = expFile;
                }
                if (exportPath.length() > 0) {
                    exportPath += File.pathSeparator;
                }
                log ("Resolve export path for " + expFileKey + " to " + expFileSegment, Project.MSG_VERBOSE);
                exportPath += expFileSegment;
            }
        }
        log ("Computed export path as " + exportPath, Project.MSG_VERBOSE);
        return exportPath;
    }

    /**
     * Returns path of a classic package from a library's CAP file
     * @param capFile - Path to a classic library's CAP file
     * @return Path of the classic library's package in the form '/a/b/c'
     * @throws BuildException
     */
    private String getPackagePath(String capFile) throws BuildException {
        String packagePath = null;
        JarFile jar = null;
        try {
            jar = new JarFile(new File(getProject().getBaseDir(), capFile));
            if (jar == null) {
                throw new BuildException("Couldn't open file: " + capFile
                        + " listed in dependencies");
            }
            Enumeration<JarEntry> jarEntries = jar.entries();
            while (jarEntries.hasMoreElements()) {
                JarEntry entry = jarEntries.nextElement();
                String entryName = entry.getName();
                if (entryName.endsWith(".class")) {
                    if (entryName.contains("/")) {
                        packagePath = "/" + entryName.substring(0, entryName.lastIndexOf('/'));
                    } else {
                        packagePath = "/";
                    }
                    break;
                }
            }

        } catch (IOException e) {
            throw new BuildException("Error while openinig file: " + capFile
                        + " listed in dependencies");
        } finally {
            if (jar != null) {
                try {
                    jar.close();
                } catch (IOException e) {
                }
            }
        }
        return packagePath;
    }

}
