/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sun.javacard.nbtasks;

import java.io.IOException;
import org.junit.After;
import java.io.File;
import java.util.Properties;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tim Boudreau
 */
public class JCPackagerTaskTest extends TestAnt {
    Properties map;
    File fakeBundle;
    File build;

    @Before
    public void setUp() throws IOException {
        System.setProperty("javacard.toolClassPath", System.getProperty("java.class.path"));
        System.setProperty("packager.task", getClass().getName());
        map = new Properties();
        fakeBundle = createFakeJar();
        assertTrue(fakeBundle.delete());
        assertFalse (fakeBundle.exists());
        map.put("build.dir", ".");
        map.put("deployment.type.arg", "extension-lib");
        map.put("basedir", System.getProperty("java.io.tmpdir"));
        build = super.createBuildScript(PackTask.class);
    }

    @After
    public void tearDown() {
        assertTrue (fakeBundle.delete());
        assertTrue (build.delete());
    }

    @Test
    public void testRelativeAndAbsolutePaths() throws Exception {
        map.put("dist.bundle", fakeBundle.getAbsolutePath());
        runBuildScript(build, map);

        assertTrue ("Passing absolute path " + fakeBundle.getAbsolutePath() + " failed", fakeBundle.exists());
        assertTrue (fakeBundle.delete());
        assertFalse (fakeBundle.exists());

        map.put ("dist.bundle", fakeBundle.getName());
        runBuildScript(build, map);
        assertTrue ("Passing relative path " + map.get("dist.bundle") + " failed", fakeBundle.exists());
    }

    static String[] args;
    static Thread t;
    static File created;

    public static void main(String[] args) throws Exception {
        JCPackagerTaskTest.args = args;
        File f = new File(args[2]);
        assertTrue(f.createNewFile());
        created = f;
    }
}
