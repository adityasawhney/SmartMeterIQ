/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sun.javacard.nbtasks;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.String;
import java.security.Permission;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.junit.Assert.*;
import org.apache.tools.ant.Main;

/**
 *
 * @author Tim Boudreau
 */
public class TestAnt {
    static {
        System.setProperty ("javacard.ant.unit.test", true + "");
    }

    public File createBuildScript(Class<?> taskClass) throws IOException {
        return createBuildScript (taskClass, new HashMap<String,String>());
    }

    public File createBuildScript(Class<?> taskClass, Map<String, String> properties) throws IOException {
        String ANT_TEMPLATE = "<project name=\"" + getClass().getName().replace('.', '-') + "\" default=\"go\">\n"
                + "  <taskdef classname=\"" + taskClass.getName() + "\" classpath=\"" + System.getProperty("java.class.path") + "\" name=\"go\"/>\n"
                + "    <target name=\"go\">\n"
                + "      <go";
        for (String key : properties.keySet()) {
            String val = properties.get(key);
            ANT_TEMPLATE += " " + key + "=\"" + val + "\"";
        }
        ANT_TEMPLATE += " />\n"
                + "    </target>\n"
                + "  </project>\n";

        File tmpdir = new File (System.getProperty ("java.io.tmpdir"));
        File result = new File (tmpdir, System.currentTimeMillis() + "build.xml");
        assert (result.createNewFile());
        FileOutputStream out = new FileOutputStream(result);
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(out);
            pw.println(ANT_TEMPLATE);
        } finally {
            if (pw != null) {
                pw.flush();
                pw.close();
            }
            out.close();
        }
        return result;
    }

    public void runBuildScript (File buildScript) {
        runBuildScript (buildScript, new Properties());
    }

    public void runBuildScript (File buildScript, Properties props) {
        SecurityManager oldSm = System.getSecurityManager();
        try {
            System.setSecurityManager(new SecMan());
            assert buildScript.exists() && buildScript.isFile();
            assert props != null;
            List<String> l = new ArrayList<String>();
//            l.add ("-debug");
            l.add ("-f");
            l.add (buildScript.getAbsolutePath());
            for (String key : props.stringPropertyNames()) {
                l.add ("-D" +  key + "=" + props.getProperty(key));
            }
            String[] strings = (String[]) l.toArray(new String[l.size()]);
            try {
                Main.main(strings);
            } catch (SecurityException e) {
                if ("No early exit".equals(e.getMessage())) {
                    //do nothing
                }
            }
        } finally {
            System.setSecurityManager(oldSm);
        }
    }


    public File createFakeJar () throws IOException {
        File tmpdir = new File (System.getProperty ("java.io.tmpdir"));
        String name = System.currentTimeMillis() + "";
        int ct = 0;
        File f;
        do {
            String nm = name + "_" + ct++;
            f = new File (tmpdir, nm + ".jar");

        } while (f.exists());
        assert f.createNewFile();
        return f;
    }

    private static final class SecMan extends SecurityManager {

        @Override
        public void checkExit(int status) {
            throw new SecurityException ("No early exit");
        }

        @Override
        public void checkPermission(Permission perm) {
            //do nothing
        }

        @Override
        public void checkPermission(Permission perm, Object context) {
            //do nothing
        }



    }
}
