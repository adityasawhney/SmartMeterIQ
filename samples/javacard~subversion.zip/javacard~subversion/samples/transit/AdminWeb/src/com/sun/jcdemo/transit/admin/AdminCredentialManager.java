/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.admin;

import javacard.security.Key;
import javacard.security.PrivateKey;
import javacardx.security.CredentialManager;
import javax.microedition.pki.Certificate;
import javax.microedition.pki.CertificateException;

/**
 * This class implements the (application-defined)
 * <code>CredentialManager</code> of the <em>Transit Admin</em> web application.
 * <p>
 * The <code>AdminCredentialManager</code> manages the credentials required for
 * securing connections to the <em>Transit Admin</em> web front end. Only the
 * methods invoked for web container-managed connections in the mode
 * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER} are implemented.
 * <p>
 * An instance of this class is registered for the mode
 * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
 */
public class AdminCredentialManager extends CredentialManager {
    /**
     * The web server certificate chain, for securing web connections.
     */
    private Certificate[] webServerCertChain;

    /**
     * The web server private key, for securing web connections.
     */
    private PrivateKey webServerPrivateKey;

    /**
     * The trusted web client or CA certificates, for securing web connections.
     */
    private Certificate[] webClientCertIssuers;

    /**
     * Creates an instance of the <code>AdminCredentialManager</code> that
     * manages the provided authentication credentials for securing connections
     * to the web front-end.
     * 
     * @param webServerCertChain
     *            the web server certificate chain, for securing web
     *            connections.
     * @param webServerPrivateKey
     *            the web server private key, for securing web connections.
     * @param webClientCertIssuers
     *            the trusted web client or CA certificates, for securing web
     *            connections.
     */
    public AdminCredentialManager(Certificate[] webServerCertChain,
            PrivateKey webServerPrivateKey, Certificate[] webClientCertIssuers) {
        this.webServerCertChain = webServerCertChain;
        this.webServerPrivateKey = webServerPrivateKey;
        this.webClientCertIssuers = webClientCertIssuers;
    }

    /**
     * Checks whether the provided certificate was issued by one of the trusted
     * client Certificate Authorities or is one of the trusted client
     * certificates, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
     * 
     * {@inheritDoc}
     */
    @Override
    public void checkTrusted(Certificate[] certificateChain, String authType,
            String endpointURI, byte mode) throws CertificateException {
        if (mode == MODE_WEB_SERVER) {
            for (Certificate certificate : certificateChain) {
                for (Certificate trustedCertificate : webClientCertIssuers) {
                    if (trustedCertificate.equals(certificate)) {
                        return;
                    }
                }
            }
            throw new CertificateException(
                    certificateChain[certificateChain.length - 1],
                    CertificateException.UNRECOGNIZED_ISSUER);
        }
        throw new CertificateException(
                certificateChain[certificateChain.length - 1],
                CertificateException.VERIFICATION_FAILED);
    }

    /**
     * Returns the list of trusted web client or CA certificates, when invoked
     * for the mode {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
     * Returns <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] getAcceptedCertificateIssuers(String endpointURI,
            byte mode) {
        if (mode == MODE_WEB_SERVER) {
            return webClientCertIssuers;
        }
        return null;
    }

    /**
     * Returns the web server certificate chain, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}. Returns
     * <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] chooseCertificateChain(String[] types,
            String[] issuers, String endpointURI, byte mode) {
        if (mode == MODE_WEB_SERVER) {
            return webServerCertChain;
        }
        return null;
    }

    /**
     * Returns the web server private key, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}. Returns
     * <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public PrivateKey getMatchingPrivateKey(Certificate certificate,
            String endpointURI, byte mode) {
        if (mode == MODE_WEB_SERVER) {
            if (webServerCertChain[0].equals(certificate)) {
                return webServerPrivateKey;
            }
        }
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public byte[] choosePreSharedKey(String pskIdentity, String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentityHint(String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentity(String hint, String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Object[] getTrustedCredentials(String[] aliases, String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Key[] getCredentials(String[] types, String endpointURI, byte mode) {
        return null;
    }
}
