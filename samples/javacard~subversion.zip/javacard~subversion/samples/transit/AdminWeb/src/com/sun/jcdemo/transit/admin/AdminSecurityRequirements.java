/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.admin;

import java.util.Vector;
import javacardx.security.CredentialManager;

/**
 * This class implements the (application-defined)
 * <code>SecurityRequirements</code> of the <em>Transit Admin</em> web
 * application.
 * <p>
 * The <code>AdminSecurityRequirements</code> defines the required
 * characteristics of secure connections to the <em>Transit Admin</em> web front
 * end. Only the methods invoked for web container-managed connections in the
 * mode {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER} are
 * implemented. Specifically, an <code>AdminSecurityRequirements</code> object
 * selects RSA cipher suites for TLS connections. The other security
 * requirements for the mode {@link CredentialManager#MODE_WEB_SERVER
 * MODE_WEB_SERVER} are inherited from the base class. These requirements
 * correspond by default to the requirements expressed in the descriptors of the
 * <em>Transit Admin</em> web application.
 * <p>
 * An instance of this class is registered for the mode
 * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
 */
public class AdminSecurityRequirements extends
        CredentialManager.SecurityRequirements {

    /**
     * Chooses among the provided supported or accepted names the list of cipher
     * suite names that are based on RSA, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}. Returns
     * <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public String[] chooseCipherSuites(String[] supportedCipherSuites,
            String endpointURI, byte mode) {
        if (mode == CredentialManager.MODE_WEB_SERVER) {
            Vector<String> selectedCipherSuites = new Vector<String>(
                    supportedCipherSuites.length);
            for (String cipherSuite : supportedCipherSuites) {
                if (cipherSuite.startsWith("TLS_RSA")) {
                    selectedCipherSuites.addElement(cipherSuite);
                }
            }
            String[] cipherSuites = new String[selectedCipherSuites.size()];
            selectedCipherSuites.copyInto(cipherSuites);
            return cipherSuites;
        }
        return null;
    }
}
