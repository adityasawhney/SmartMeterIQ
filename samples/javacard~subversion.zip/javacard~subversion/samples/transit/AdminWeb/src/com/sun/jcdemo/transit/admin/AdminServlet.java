/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.admin;

import com.sun.jcdemo.transit.DateFormatter;
import com.sun.jcdemo.transit.I18nDispatcher;
import com.sun.jcdemo.transit.Utils;
import javacardx.facilities.ServiceRegistry;
import javacardx.framework.JCSystem;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.RequestDispatcher;

import java.io.PrintWriter;
import java.io.IOException;
import java.util.Date;

import com.sun.jcdemo.transit.SharedTicketBook;
import com.sun.jcdemo.transit.pos.SharedTicketBookControl;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;
import javacard.security.PrivateKey;
import javacardx.security.CredentialManager;
import javax.microedition.pki.Certificate;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpSession;

/**
 * This class implements the front-end of the <em>Transit Admin</em> web
 * application.
 * 
 * This servlet allows for an administrator to administer the transit
 * application, typically from a
 * <em>remote (non-card holder-facing) terminal</em>. Access to the
 * <em>Transit Admin</em> web application and to this servlet in particular must
 * be explictly authorized by the card holder. This feature is configured in the
 * Java Card Platform-specific application descriptor.
 * <p>
 * Each of the administrative operations may be invoked using a dedicated URL
 * query path.
 * <dl>
 * <dt><code>/balance</code></dt>
 * <dd>to get the ticketbook balance</dd>
 * <dt><code>/history</code></dt>
 * <dd>get the transaction history (time and amount of debits and credits)</dd>
 * <dt><code>/unblock</code></dt>
 * <dd>to unblock the ticketbook, hence enabling the use of the
 * <em>Transit Turnstile</em> application</dd>
 * </dl>
 * This servlet retrieves from the service registry the <em>Ticketbook</em> SIO
 * - a singleton - exposed by the <em>Transit POS</em> application and invokes
 * its Shareable Interface methods to perform the related administrative
 * operations. The URI of the <em>Transit POS</em> application is provided via
 * an application property that can be configured in this application's runtime
 * descriptor.
 * <p>
 * The URL for each of the administrative operations are protected using
 * declarative security. That is, to each of these URLs is associated a security
 * constraint in the deployment descriptor of this web application that may be
 * configure to require user authentication and confidentiality of the
 * connections over which requests to this servlet are sent.
 * <p>
 * Note that the implementation of the <em>Transit Admin</em> web application
 * assumes by default that it is not running in the same firewall context as the
 * <em>Transit POS</em> web application.
 * 
 * @see com.sun.jcdemo.transit.pos.POSServlet
 * @see com.sun.jcdemo.transit.SharedTicketBook
 * @see com.sun.jcdemo.transit.pos.SharedTicketBookControl
 * @see javacardx.framework.JCSystem#getAppProperty
 * @see javacardx.facilities.ServiceRegistry
 * 
 */
public class AdminServlet extends HttpServlet {

    /**
     * The context attribute name for the web server certificate chain.
     */
    public static final String WEB_SERVER_CERTS_ATTR = "com.sun.javacard.credentials.webServerCerts";

    /**
     * The context attribute name for the web server private key.
     */
    public static final String WEB_SERVER_PRIV_KEY_ATTR = "com.sun.javacard.credentials.webServerPrivKey";

    /**
     * The context attribute name for the trusted web client or CA certificates.
     */
    public static final String WEB_CLIENT_CERTS_ATTR = "com.sun.javacard.credentials.webClientTrustedCerts";

    /**
     * The session attribute name for the current resource bundle.
     */
    static final String RESOURCES_ATTR = "com.sun.jcdemo.transit.admin.resources";

    /**
     * The <code>I18nDispatcher</code>.
     */
    private I18nDispatcher i18nDispatcher;

    /**
     * Initializes this <code>AminServlet</code>.
     * <p>
     * This method retrieves the web authentication credentials that were set as
     * context attributes by the RI-specific card manager, creates and
     * initializes an instance of {@link AdminCredentialManager
     * AdminCredentialManager} with these credentials, then registers it for the
     * mode {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
     * 
     * {@inheritDoc}
     */
    @Override
    public void init(ServletConfig config) {
        i18nDispatcher = new I18nDispatcher(config.getServletContext());

        Certificate[] webServerCerts = (Certificate[]) config
                .getServletContext().getAttribute(WEB_SERVER_CERTS_ATTR);
        PrivateKey webServerPrivateKey = (PrivateKey) config
                .getServletContext().getAttribute(WEB_SERVER_PRIV_KEY_ATTR);
        Certificate[] webClientCerts = (Certificate[]) config
                .getServletContext().getAttribute(WEB_CLIENT_CERTS_ATTR);
        if (webServerCerts != null && webServerPrivateKey != null) {
            CredentialManager.setCredentialManager(new AdminCredentialManager(
                    webServerCerts, webServerPrivateKey, webClientCerts),
                    CredentialManager.MODE_WEB_SERVER);
            CredentialManager
                    .setSecurityRequirements(new AdminSecurityRequirements(),
                            CredentialManager.MODE_WEB_SERVER);
        }
    }

    /**
     * Handles requests for administrative operations submitted with a POST HTTP
     * method.
     * <p>
     * Each of the administrative operations has a dedicated URL query path.
     * <dl>
     * <dt><code>/balance</code></dt>
     * <dd>to get the ticketbook balance</dd>
     * <dt><code>/history</code></dt>
     * <dd>to get the transaction history (time and amount of debits and
     * credits)</dd>
     * <dt><code>/unblock</code></dt>
     * <dd>to unblock the use of the ticketbook and turnstile application</dd>
     * <dt><code>/branding</code></dt>
     * <dd>to retrieve the branding banner common to all Transit applications</dd>
     * </dl>
     * Before handling a request, the <em>Ticketbook</em> service is looked up.
     * This allows for a loose-coupling between this application and the
     * <em>Transit POS</em> web application. They can be deployed/instantiated
     * and deleted/undeployed in any order. Methods of the <em>Ticketbook</em>
     * SIO are invoked to perform the related administrative operations.
     * <p>
     * When assembling pages from static page fragments or when forwarding to a
     * static resource, this method invokes the {@link I18nDispatcher
     * com.sun.jcdemo.transit.I18nDispatcher} object to search for a localized
     * version of the static resource that is acceptable to the user and forward
     * the request to that localized resource.
     * 
     * {@inheritDoc}
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String transitPOSAppURI = JCSystem.getAppProperty("transit-pos-app",
                null);

        HttpSession session = request.getSession(true);

        RequestDispatcher dispatcher;

        ResourceBundle resourceBundle = (ResourceBundle) session
                .getAttribute(RESOURCES_ATTR);
        if (resourceBundle == null) {
            resourceBundle = getResourceBundle((Enumeration<Locale>) request
                    .getLocales());
            session.setAttribute(RESOURCES_ATTR, resourceBundle);
        }

        String path = request.getServletPath();
        if (path.equals("/branding")) {
            InputStream is = getClass()
                    .getResourceAsStream("/com/sun/jcdemo/transit/rsrc/images/title.png");
            if (is != null) {
                Utils.copy(is, response.getOutputStream());
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        } else {
            // Note that getWriter is called before a dispatcher.include
            // to ensure that the PrintWriter can be used for dynamic content
            PrintWriter out = response.getWriter();

            SharedTicketBook ticketBook = lookupTicketBookService();

            if (ticketBook == null) {
                response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE,
                        "No Ticket Book Service");
                return;
            }

            try {
                if (path.equals("/balance")) {
                    // No request parameter to parse...
                    int balance = ticketBook.getBalance();
                    // Build response...
                    // Use dispatcher include and explain that filters are not
                    // invoked
                    i18nDispatcher.include("/WEB-INF/AdminMain-1.html",
                            request,
                            response);

                    out.println(balance);
                    i18nDispatcher.include("/WEB-INF/AdminMain-Footer.html",
                            request,
                            response);
                } else if (path.equals("/unblock")) {
                    // No request parameter to parse...
                    ((SharedTicketBookControl) ticketBook).unblock();
                    // Forward to /balance
                    dispatcher = request.getRequestDispatcher("/balance");
                    dispatcher.forward(request, response);
                } else if (path.equals("/history")) {

                    int balance = ticketBook.getBalance();
                    // format history page
                    i18nDispatcher.include("/WEB-INF/AdminHistory-1.html",
                            request,
                            response);

                    out.println(balance);
                    i18nDispatcher.include("/WEB-INF/AdminHistory-2.html",
                            request,
                            response);

                    DateFormatter dateFormatter = (DateFormatter) resourceBundle
                            .getObject("DateFormatter");
                    String timeLabel = resourceBundle.getString("Time:");
                    String creditLabel = resourceBundle.getString("Credit:");
                    String debitLabel = resourceBundle.getString("Debit:");

                    // length corresponds to the number of history
                    // entries to be displayed per group in the page.
                    String numtransstring = request
                            .getParameter("NumTransactionsDropDown");
                    int length = 5;
                    if (numtransstring != null) {
                        try {
                            length = Integer.parseInt(numtransstring);
                        } catch (Exception e) {
                        }
                    }
                    if (length <= 0) {
                        length = 5;
                    }

                    long[][] history = null;
                    history = new long[length][2];
                    for (int j = 0; j < history.length; j++) {
                        // Transfer each element to server: no copy
                        JCSystem
                                .transferOwnership(history[j], transitPOSAppURI);
                    }
                    // Transfer history buffer to server: no copy
                    JCSystem.transferOwnership(history, transitPOSAppURI);

                    int start = 0;
                    history = ticketBook.getHistory(history, start);
                    while (history != null) {
                        // iterate to print transaction history
                        for (int i = 0; i < history.length; i++) {
                            if (history[i][0] == 0) {
                                break; // zero filled transaction

                            }
                            out.print(timeLabel
                                    + " "
                                    + dateFormatter.format(new Date(
                                            history[i][0])) + "   ");
                            if (history[i][1] < 0) {
                                out.print(debitLabel + " " + history[i][1]
                                        + "<br>");
                            } else {
                                out.print(creditLabel + " " + history[i][1]
                                        + "<br>");
                            }
                        }
                        start = start += length;
                        if (length == 0) {
                            break;
                        } else {
                            // prepare to call SIO again
                            for (int j = 0; j < history.length; j++) {
                                // Transfer each element to server: no copy
                                JCSystem.transferOwnership(history[j],
                                        transitPOSAppURI);
                            }
                            // Transfer history buffer to server: no copy
                            JCSystem.transferOwnership(history,
                                    transitPOSAppURI);
                        }
                    }
                    i18nDispatcher.include("/WEB-INF/AdminHistory-Footer.html",
                            request,
                            response);
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (SecurityException se) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN,
                        "Ticket book operation denied.");
                return;
            }
        }
    }

    /**
     * Handles requests for account operations submitted with a GET HTTP method.
     * <p>
     * This method delegates to the
     * {@link #doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     * doPost} method.
     * 
     * {@inheritDoc}
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Looks up the <em>Ticketbook</em> service.
     * 
     * @return the <em>Ticketbook</em> service.
     */
    private SharedTicketBook lookupTicketBookService() {
        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        String transitPOSAppURI = JCSystem.getAppProperty("transit-pos-app",
                null);
        SharedTicketBook ticketBook = (SharedTicketBook) serviceRegistry
                .lookup(transitPOSAppURI, "ticketbook");
        return ticketBook;
    }

    private ResourceBundle getResourceBundle(Enumeration<Locale> locales)
            throws IOException, ServletException {
        ResourceBundle resourceBundle = null;
        while (locales.hasMoreElements()) {
            Locale locale = locales.nextElement();
            resourceBundle = ResourceBundle
                    .getBundle("com.sun.jcdemo.transit.Resources", locale);
            // resourceBundle can't be null
            // Keep searching unless this is the default locale
            // and one of the acceptable locales
            if ((locale.equals(Locale.getDefault()) && resourceBundle
                    .getLocale().equals(Locale.getDefault()))
                    || !resourceBundle.getLocale().toString().equals("")) {
                break;
            }
        }
        return resourceBundle;
    }
}
