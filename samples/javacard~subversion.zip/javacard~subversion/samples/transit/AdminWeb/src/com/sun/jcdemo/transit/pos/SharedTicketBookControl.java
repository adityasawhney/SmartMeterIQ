/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import javacard.framework.Shareable;

/**
 * This interface defines the methods of a <em>TicketBook</em> object that may
 * be exposed to applications outside the context of the <em>Transit POS</em>
 * application to administrative client applications such as the
 * <em>Transit Admin</em> application.
 * <p>
 * The methods exposed by this Shareable Interface perform the following
 * administration operations:
 * <ul>
 * <li>unblock the use of the ticketbook and of the turnstile application</li>
 * </ul>
 * <p>
 * Note that when the (only) administrative client application, that is the
 * <em>Transit Admin</em> web application, is actually bundled and deployed
 * along with the <em>Transit POS</em> application to run in the same firewall
 * context, this Shareable Interface is <em>demoted</em> and not exposed to
 * applications outside the application group. It simply behaves as a regular
 * interface.
 */
public interface SharedTicketBookControl extends Shareable {

    /**
     * Unblock the ticketbook.
     */
    void unblock();
}
