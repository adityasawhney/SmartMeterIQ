/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.walletplus;

import javacard.framework.APDU;
import javacard.framework.Applet;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacard.framework.OwnerPIN;
import javacard.framework.AID;
import javacard.framework.Shareable;

/**
 * This class implements the APDU front-end of the <em>Wallet</em> classic
 * applet application. It has been enhanced to also perform debit operations via
 * a <em>Wallet</em> service from a trusted <em>WalletAssist</em> client
 * application on the card. On the connected platform, the <em>Transit POS</em>
 * web application performs <em>debit</em> operations on the wallet via the
 * <em>WalletAssist</em> extended applet application when transit tickets are
 * credited in the <em>TicketBook</em>
 * <p>
 * The APDU commands that this applet handles are:
 * <dl>
 * <dt>{@link #GET_BALANCE}</dt>
 * <dd>Returns the Wallet Balance.</dd>
 * <dl>
 * <dt>{@link #DEBIT}</dt>
 * <dd>Deducts the specified amount from the Wallet. PIN verification required.</dd>
 * <dl>
 * <dt>{@link #CREDIT}</dt>
 * <dd>
 * Credits the specified amount to the Wallet. PIN verification required.</dd>
 * <dl>
 * <dt>{@link #VERIFY}</dt>
 * <dd>
 * Verifies the PIN code presented.</dd>
 * </dl>
 * </dd> </dl> This <em>Wallet</em> applet also services debit requests from an
 * the <em>WalletAssist</em> on-card client applet application when it requests
 * the <em>Wallet</em> SIO using the parameter code <code>0x55</code>. The
 * <em>WalletAccess</em> SIO object returned implements the
 * <em>SharedWalletAccess</em> shareable interface.
 * 
 * @see com.sun.jcdemo.wallet.SharedWalletAccess
 * 
 */
public class ClassicWalletApplet extends Applet {

    /* constants declaration */

    // code of CLA byte in the command APDU header
    final static byte Wallet_CLA = (byte) 0x80;

    // codes of INS byte in the command APDU header
    public final static byte VERIFY = (byte) 0x20;

    public final static byte CREDIT = (byte) 0x30;

    public final static byte DEBIT = (byte) 0x40;

    public final static byte GET_BALANCE = (byte) 0x50;

    // maximum balance
    final static short MAX_BALANCE = 0x7FFF;

    // maximum transaction amount
    final static byte MAX_TRANSACTION_AMOUNT = 127;

    // maximum number of incorrect tries before the
    // PIN is blocked
    final static byte PIN_TRY_LIMIT = (byte) 0x03;

    // maximum size PIN
    final static byte MAX_PIN_SIZE = (byte) 0x08;

    // signal that the PIN verification failed
    final static short SW_VERIFICATION_FAILED = 0x6300;

    // signal the the PIN validation is required
    // for a credit or a debit transaction
    final static short SW_PIN_VERIFICATION_REQUIRED = 0x6301;

    // signal invalid transaction amount
    // amount > MAX_TRANSACTION_AMOUNT or amount < 0
    final static short SW_INVALID_TRANSACTION_AMOUNT = 0x6A83;

    // signal that the balance exceed the maximum
    final static short SW_EXCEED_MAXIMUM_BALANCE = 0x6A84;

    // signal the the balance becomes negative
    final static short SW_NEGATIVE_BALANCE = 0x6A85;

    // parameter value to request wallet SIO
    private static byte WALLET_PARAM = (byte) 0x55;

    /* instance variables declaration */
    OwnerPIN pin;

    /** Wallet Balance initialized with $10 credit */
    short balance = 10;

    WalletAccess walletSIO;

    private ClassicWalletApplet(byte[] bArray, short bOffset, byte bLength) {
        // It is good programming practice to allocate
        // all the memory that an applet needs during
        // its lifetime inside the constructor
        pin = new OwnerPIN(PIN_TRY_LIMIT, MAX_PIN_SIZE);

        // instantiate WalletAccess SIO for on-card client access
        walletSIO = new WalletAccess(this);

        byte iLen = bArray[bOffset]; // aid length
        bOffset = (short) (bOffset + iLen + 1);
        byte cLen = bArray[bOffset]; // info length
        bOffset = (short) (bOffset + cLen + 1);
        byte aLen = bArray[bOffset]; // applet data length

        // The installation parameters contain the PIN
        // initialization value
        pin.update(bArray, (short) (bOffset + 1), aLen);

        register();
    }

    /**
     * Creates a <code>ClassicWalletApplet</code> instance which registers
     * itself.
     * 
     * @param bArray
     *            contains the instance AID information in the install params
     * @param bOffset
     *            offset where the install parameters starts
     * @param bLength
     *            length of install parameters
     */
    public static void install(byte[] bArray, short bOffset, byte bLength) {
        // create a Wallet applet instance
        new ClassicWalletApplet(bArray, bOffset, bLength);
    }

    /**
     * Allows this <code>ClassicWalletApplet</code> to be selected only if the
     * PIN is not blocked.
     * 
     * {@inheritDoc}
     */
    public boolean select() {
        // The applet declines to be selected
        // if the pin is blocked.
        if (pin.getTriesRemaining() == 0) {
            return false;
        }
        return true;
    }

    /**
     * Deselects this <code>ClassicWalletApplet</code> and resets the PIN
     * verification status.
     * 
     * {@inheritDoc}
     */
    public void deselect() {
        // reset the pin value
        pin.reset();
    }

    /**
     * Process incoming request from off-card client.
     * 
     * {@inheritDoc}
     */
    public void process(APDU apdu) {
        // APDU object carries a byte array (buffer) to
        // transfer incoming and outgoing APDU header
        // and data bytes between card and CAD

        // At this point, only the first header bytes
        // [CLA, INS, P1, P2, P3] are available in
        // the APDU buffer.
        // The interface javacard.framework.ISO7816
        // declares constants to denote the offset of
        // these bytes in the APDU buffer

        byte[] buffer = apdu.getBuffer();
        // check SELECT APDU command

        if (apdu.isISOInterindustryCLA()) {
            if (buffer[ISO7816.OFFSET_INS] == (byte) (0xA4)) {
                return;
            }
            ISOException.throwIt(ISO7816.SW_CLA_NOT_SUPPORTED);
        }

        // verify the reset of commands have the
        // correct CLA byte, which specifies the
        // command structure
        if (buffer[ISO7816.OFFSET_CLA] != Wallet_CLA) {
            ISOException.throwIt(ISO7816.SW_CLA_NOT_SUPPORTED);
        }

        switch (buffer[ISO7816.OFFSET_INS]) {
        case GET_BALANCE:
            getBalance(apdu);
            return;
        case DEBIT:
            debit(apdu);
            return;
        case CREDIT:
            credit(apdu);
            return;
        case VERIFY:
            verify(apdu);
            return;
        default:
            ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
        }
    }

    /**
     * Process incoming CREDIT request from off-card client.
     * 
     * {@inheritDoc}
     */
    private void credit(APDU apdu) {
        // access authentication
        if (!pin.isValidated()) {
            ISOException.throwIt(SW_PIN_VERIFICATION_REQUIRED);
        }

        byte[] buffer = apdu.getBuffer();

        // Lc byte denotes the number of bytes in the
        // data field of the command APDU
        byte numBytes = buffer[ISO7816.OFFSET_LC];

        // indicate that this APDU has incoming data
        // and receive data starting from the offset
        // ISO7816.OFFSET_CDATA following the 5 header
        // bytes.
        byte byteRead = (byte) (apdu.setIncomingAndReceive());

        // it is an error if the number of data bytes
        // read does not match the number in Lc byte
        if ((numBytes != 1) || (byteRead != 1)) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // get the credit amount
        byte creditAmount = buffer[ISO7816.OFFSET_CDATA];

        // check the credit amount
        if ((creditAmount > MAX_TRANSACTION_AMOUNT) || (creditAmount < 0)) {
            ISOException.throwIt(SW_INVALID_TRANSACTION_AMOUNT);
        }

        // check the new balance
        if ((short) (balance + creditAmount) > MAX_BALANCE) {
            ISOException.throwIt(SW_EXCEED_MAXIMUM_BALANCE);
        }

        // credit the amount
        balance = (short) (balance + creditAmount);
    }

    /**
     * Process incoming DEBIT request from off-card client.
     */
    private void debit(APDU apdu) {
        // access authentication
        if (!pin.isValidated()) {
            ISOException.throwIt(SW_PIN_VERIFICATION_REQUIRED);
        }

        byte[] buffer = apdu.getBuffer();

        byte numBytes = (buffer[ISO7816.OFFSET_LC]);

        byte byteRead = (byte) (apdu.setIncomingAndReceive());

        if ((numBytes != 1) || (byteRead != 1)) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // get debit amount
        byte debitAmount = buffer[ISO7816.OFFSET_CDATA];

        doDebit(debitAmount);
    }

    boolean doDebit(byte amount) {
        // check debit amount
        if ((amount > MAX_TRANSACTION_AMOUNT) || (amount < 0)) {
            ISOException.throwIt(SW_INVALID_TRANSACTION_AMOUNT);
        }

        // check the new balance
        if ((short) (balance - amount) < (short) 0) {
            ISOException.throwIt(SW_NEGATIVE_BALANCE);
        }

        balance = (short) (balance - amount);
        return true; // success
    }

    /**
     * Process incoming GET_BALANCE request from off-card client.
     */
    private void getBalance(APDU apdu) {
        byte[] buffer = apdu.getBuffer();

        // inform system that the applet has finished
        // processing the command and the system should
        // now prepare to construct a response APDU
        // which contains data field
        short le = apdu.setOutgoing();

        if (le < 2) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // informs the CAD the actual number of bytes
        // returned
        apdu.setOutgoingLength((byte) 2);

        // move the balance data into the APDU buffer
        // starting at the offset 0
        buffer[0] = (byte) (balance >> 8);
        buffer[1] = (byte) (balance & 0xFF);

        // send the 2-byte balance at the offset
        // 0 in the apdu buffer
        apdu.sendBytes((short) 0, (short) 2);
    }

    /**
     * Process incoming VERIFY_PIN request from off-card client.
     */
    private void verify(APDU apdu) {
        byte[] buffer = apdu.getBuffer();
        // retrieve the PIN data for validation.
        byte byteRead = (byte) (apdu.setIncomingAndReceive());

        // check pin
        // the PIN data is read into the APDU buffer
        // at the offset ISO7816.OFFSET_CDATA
        // the PIN data length = byteRead
        if (pin.check(buffer, ISO7816.OFFSET_CDATA, byteRead) == false) {
            ISOException.throwIt(SW_VERIFICATION_FAILED);
        }
    }

    /**
     * Returns the <em>WalletAccess</em> SIO if requested by trusted
     * <em>Wallet Assist</em> applet application with parameter equals
     * <code>0x55</code>.
     * 
     * {@inheritDoc}
     */
    public Shareable getShareableInterfaceObject(AID clientAID, byte parameter) {
        if (!clientAID.equals(WalletAccess.WALLET_CLIENT_AID,
                (byte) 0,
                (byte) WalletAccess.WALLET_CLIENT_AID.length)) {
            return null;
        } else if (parameter == WALLET_PARAM) {
            return walletSIO;
        } else {
            return null;
        }
    }
}

