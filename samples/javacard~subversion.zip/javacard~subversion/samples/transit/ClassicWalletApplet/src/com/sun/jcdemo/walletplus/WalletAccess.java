/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.walletplus;

import javacard.framework.JCSystem;
import javacard.framework.ISOException;
import com.sun.jcdemo.wallet.SharedWalletAccess;

/**
 * This is the <em>WalletAccess</em> SIO class. The <em>WalletAccess</em> class
 * implements the <em>SharedWalletAccess</em> Shareable Interface. The
 * <em>debit</em> method of the interface debits the Wallet when requested by
 * the trusted <em>WalletAssist</em> client.
 */
public class WalletAccess implements SharedWalletAccess {

    /**
     * The {@link #WALLET_CLIENT_AID} client AID. This AID is the AID of the
     * trusted client application which is enabled to perform debit operations
     * on the wallet
     */
    public static final byte[] WALLET_CLIENT_AID = { (byte) 0xA0, 0x00, 0x00,
            0x00, (byte) 0x62, 0x03, 0x01, 0x0C, 0x06, 0x02 };

    private ClassicWalletApplet wallet;

    /**
     * Creates an instance of <code>WalletAccess</code>.
     * 
     * @param walletInstance
     *            the clasic wallet applet instance.
     */
    public WalletAccess(ClassicWalletApplet walletInstance) {
        this.wallet = walletInstance;
    }

    /**
     * Debits the wallet. If the requested debit amount cannot be debited this
     * method returns false.
     * 
     * @param debitAmount
     *            the amount to debit
     * @return true if successful, false otherwise
     * @throws SecurityException
     *             if the application client attempting this operation is not
     *             the extended applet with AID equals
     *             {@link #WALLET_CLIENT_AID}.
     */
    public boolean debit(byte debitAmount) throws SecurityException {
        boolean success;
        // verify that the caller is the trusted wallet agent app
        if (!JCSystem.getPreviousContextAID().equals(WALLET_CLIENT_AID,
                (byte) 0,
                (byte) WALLET_CLIENT_AID.length)) {
            success = false;
        } else {
            try {
                success = wallet.doDebit(debitAmount);
            } catch (Exception ex) {
                success = false;
            }
        }
        return success;
    }
}
