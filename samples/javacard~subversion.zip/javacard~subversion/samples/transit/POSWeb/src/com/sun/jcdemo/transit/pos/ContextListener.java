/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import com.sun.jcdemo.transit.pos.auth.GlobalPINAuthFactory;
import com.sun.jcdemo.transit.SharedTicketBook;
import com.sun.jcdemo.transit.pos.auth.SessionPINAuthFactory;
import javacard.security.PrivateKey;
import javacardx.framework.JCSystem;
import javacardx.facilities.ServiceRegistry;

import javacardx.framework.Authenticator;
import javacardx.security.CredentialManager;
import javax.microedition.pki.Certificate;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import static com.sun.jcdemo.transit.pos.POSServlet.*;

/**
 * This class implements a servlet context listener. An instance of this class
 * is automatically created by the servlet container when the
 * <em>Transit POS</em> web application is instantiated and before any request
 * is dispatched to it. The registered instance is invoked by the servlet
 * container to handle the web application lifecycle events: instance creation
 * and deletion:
 * <ul>
 * <li>Upon creation of the web application instance:
 * <ul>
 * <li>an application-defined credential manager is created and registered to
 * handle the credentials required for controlling accesses to the web front-end
 * and to the <em>Ticketbook</em> service.</li>
 * <li>the <em>Ticketbook</em> service is created and registered,
 * <li>the global card holder authenticator used to authorize remote access to
 * the <em>Transit Admin</em> application is looked up and cached in the
 * context.
 * </ul>
 * <li>Upon deletion of the web application instance, the <em>Ticketbook</em>
 * service is unregistered.</li>
 * </ul>
 * This servlet context listener is declared and configured in the deployment
 * descriptor of the <em>Transit POS</em> web application.
 */
public class ContextListener implements ServletContextListener {

    /**
     * The application property name for the data of the DES secret key shared
     * with the <em>Transit Turnstile</em> application.
     */
    public static final String TURNSTILE_KEY_PROPERTY = "TURNSTILE-KEY";

    /**
     * The context attribute name for the web server certificate chain.
     */
    public static final String WEB_SERVER_CERTS_ATTR = "com.sun.javacard.credentials.webServerCerts";

    /**
     * The context attribute name for the web server private key.
     */
    public static final String WEB_SERVER_PRIV_KEY_ATTR = "com.sun.javacard.credentials.webServerPrivKey";

    /**
     * The context attribute name for the trusted web client or CA certificates.
     */
    public static final String WEB_CLIENT_CERTS_ATTR = "com.sun.javacard.credentials.webClientTrustedCerts";

    private String ownerAdminAuthURI = null;

    private String ownerPOSAuthURI = null;

    /**
     * Invoked when the <em>Transit POS</em> web application instance is
     * created.
     * <p>
     * This method:
     * <ul>
     * <li>retrieves the web authentication credentials and the on-card client
     * authentication credential that were set as context attributes by the
     * RI-specific card manager and as an application property, resp., creates
     * and initializes an instance of {@link POSCredentialManager
     * POSCredentialManager} with these credentials, then registers it for both
     * modes {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER} and
     * {@link CredentialManager#MODE_SIO_SERVER MODE_SIO_SERVER},</li>
     * <li>creates the <em>Ticketbook</em> SIO singleton instance, sets it as a
     * servlet context attribute and registers a service factory that will
     * return it when looked up by client applications,</li>
     * <li>retrieves, as an application property, the URI of the authenticator
     * to be used authorizing remote administration (by a ticket booth clerk),
     * looks it up in the service registry and sets it in the context for faster
     * access.</li>
     * </ul>
     * 
     * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce) {
        Certificate[] webServerCerts = (Certificate[]) sce.getServletContext()
                .getAttribute(WEB_SERVER_CERTS_ATTR);
        PrivateKey webServerPrivateKey = (PrivateKey) sce.getServletContext()
                .getAttribute(WEB_SERVER_PRIV_KEY_ATTR);
        Certificate[] webClientCerts = (Certificate[]) sce.getServletContext()
                .getAttribute(WEB_CLIENT_CERTS_ATTR);
        String onCardClientKeyData = JCSystem
                .getAppProperty(TURNSTILE_KEY_PROPERTY, null);
        CredentialManager credentialManager = new POSCredentialManager(
                webServerCerts, webServerPrivateKey, webClientCerts,
                onCardClientKeyData);
        if (webServerCerts != null && webServerPrivateKey != null) {
            CredentialManager.setCredentialManager(credentialManager,
                    CredentialManager.MODE_WEB_SERVER);
        }
        CredentialManager.setCredentialManager(credentialManager,
                CredentialManager.MODE_SIO_SERVER);

        ServiceRegistry registry = ServiceRegistry.getServiceRegistry();
        registry.register(TICKETBOOK_URI, new TicketBookFactory());
        // Retrieving the ticketbook service instance from the registry ensures
        // that the singleton instance is initialized with a canonicalized
        // service URI
        TicketBook ticketBook = (TicketBook) lookupTicketBookService();
        ServletContext context = sce.getServletContext();
        context.setAttribute(POSServlet.TICKETBOOK_ATTR, ticketBook);

        String authenticatorURI = JCSystem
                .getAppProperty(OWNER_ADMIN_URI_PROPERTY, null);
        if (authenticatorURI != null
                && authenticatorURI
                        .startsWith("sio:///standard/auth/holder/global/")) {
            Authenticator authenticator = (Authenticator) registry
                    .lookup(authenticatorURI);
            if (authenticator == null) {
                // No pre-register authenticator... register our own
                ownerAdminAuthURI = authenticatorURI;
                String pin = JCSystem.getAppProperty(OWNER_ADMIN_PIN_PROPERTY,
                        null);
                registry.register(authenticatorURI, new GlobalPINAuthFactory(
                        pin.getBytes(), 3));
                authenticator = (Authenticator) registry
                        .lookup(authenticatorURI);
            }
            context.setAttribute(POSServlet.GLOBAL_CH_AUTHENTICATOR_ATTR,
                    authenticator);
        }

        authenticatorURI = JCSystem
                .getAppProperty(OWNER_POS_URI_PROPERTY, null);
        if (authenticatorURI != null) {
            Authenticator authenticator = (Authenticator) registry
                    .lookup(authenticatorURI);
            if (authenticator == null
                    && authenticatorURI
                            .startsWith("sio:///standard/auth/holder/session/")) {
                // No pre-register authenticator... register our own
                ownerPOSAuthURI = authenticatorURI;
                String pin = JCSystem.getAppProperty(OWNER_POS_PIN_PROPERTY,
                        null);
                registry.register(authenticatorURI, new SessionPINAuthFactory(
                        pin.getBytes(), 3));
                authenticator = (Authenticator) registry
                        .lookup(authenticatorURI);
            }
        }
    }

    /**
     * Invoked when the <em>Transit POS</em> web application instance is
     * deleted.
     * <p>
     * This method unregisters the service factory that was registered to return
     * the <em>Ticketbook</em> SIO singleton instance to client applications.
     * 
     * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce) {
        ServiceRegistry registry = ServiceRegistry.getServiceRegistry();
        registry.unregister(TICKETBOOK_URI);
        if (ownerAdminAuthURI != null) {
            registry.unregister(ownerAdminAuthURI);
        }
        if (ownerPOSAuthURI != null) {
            registry.unregister(ownerPOSAuthURI);
        }
    }

    private SharedTicketBook lookupTicketBookService() {
        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        SharedTicketBook ticketBook = (SharedTicketBook) serviceRegistry
                .lookup(TICKETBOOK_URI);
        return ticketBook;
    }
}
