/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import javacard.security.DESKey;
import javacard.security.Key;
import javacard.security.KeyBuilder;
import javacard.security.PrivateKey;
import javacardx.security.CredentialManager;
import javax.microedition.pki.Certificate;
import javax.microedition.pki.CertificateException;

/**
 * This class implements the (application-defined)
 * <code>CredentialManager</code> of the <em>Transit POS</em> web application.
 * <p>
 * The <code>POSCredentialManager</code> manages:
 * <ul>
 * <li>the credentials required for granting access to the <em>Ticketbook</em>
 * service. For this purpose, only the methods invoked for on-card client
 * authentication in the mode {@link CredentialManager#MODE_SIO_SERVER
 * MODE_SIO_SERVER} are implemented.</li>
 * <li>the credentials required for securing connections to the
 * <em>Transit POS</em> web front end. For this purpose, only the methods
 * invoked for web container-managed connections in the mode
 * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER} are implemented.</li>
 * </ul>
 * An instance of this class is registered for the modes
 * {@link CredentialManager#MODE_SIO_SERVER MODE_SIO_SERVER} and
 * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
 * 
 * @see com.sun.jcdemo.transit.turnstile.TurnstileCredentialManager
 */
public class POSCredentialManager extends CredentialManager {

    /**
     * The web server certificate chain, for securing web connections.
     */
    private Certificate[] webServerCertChain;

    /**
     * The web server private key, for securing web connections.
     */
    private PrivateKey webServerPrivateKey;

    /**
     * The trusted web client or CA certificates, for securing web connections.
     */
    private Certificate[] webClientCertIssuers;

    /**
     * The DES secret key, for on-card authentication of the
     * <em>Transit Turnstile</em> application.
     */
    private DESKey turnstileKey;

    /**
     * Creates an instance of the <code>POSCredentialManager</code> that manages
     * the provided authentication credentials for securing connections to the
     * web front-end and on-card client accesses to the <em>TicketBook</em>
     * service.
     * 
     * @param webServerCertChain
     *            the web server certificate chain, for securing web
     *            connections.
     * @param webServerPrivateKey
     *            the web server private key, for securing web connections.
     * @param webClientCertIssuers
     *            the trusted web client or CA certificates, for securing web
     *            connections.
     * @param onCardClientKeyData
     *            the data of the DES secret key, for on-card authentication.
     */
    public POSCredentialManager(Certificate[] webServerCertChain,
            PrivateKey webServerPrivateKey, Certificate[] webClientCertIssuers,
            String onCardClientKeyData) {
        this.webServerCertChain = webServerCertChain;
        this.webServerPrivateKey = webServerPrivateKey;
        this.webClientCertIssuers = webClientCertIssuers;

        if (onCardClientKeyData != null) {
            turnstileKey = (DESKey) KeyBuilder.buildKey("DES",
                    KeyBuilder.LENGTH_DES,
                    false);
            byte[] keyDataBytes = onCardClientKeyData.getBytes();
            turnstileKey.setKey(keyDataBytes, (short) 0);
        } else {
            // should throw some kind of exception
        }
    }

    /**
     * Checks whether the provided certificate was issued by one of the trusted
     * client Certificate Authorities or is one of the trusted client
     * certificates, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
     * 
     * {@inheritDoc}
     */
    @Override
    public void checkTrusted(Certificate[] certificateChain, String authType,
            String endpointURI, byte mode) throws CertificateException {
        if (mode == MODE_WEB_SERVER) {
            for (Certificate certificate : certificateChain) {
                for (Certificate trustedCertificate : webClientCertIssuers) {
                    if (trustedCertificate.equals(certificate)) {
                        return;
                    }
                }
            }
            throw new CertificateException(
                    certificateChain[certificateChain.length - 1],
                    CertificateException.UNRECOGNIZED_ISSUER);
        }
        throw new CertificateException(
                certificateChain[certificateChain.length - 1],
                CertificateException.VERIFICATION_FAILED);
    }

    /**
     * Returns the list of trusted web client or CA certificates, when invoked
     * for the mode {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}.
     * Returns <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] getAcceptedCertificateIssuers(String endpointURI,
            byte mode) {
        if (mode == MODE_WEB_SERVER) {
            return webClientCertIssuers;
        }
        return null;
    }

    /**
     * Returns the web server certificate chain, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}. Returns
     * <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] chooseCertificateChain(String[] types,
            String[] issuers, String endpointURI, byte mode) {
        if (mode == MODE_WEB_SERVER) {
            return webServerCertChain;
        }
        return null;
    }

    /**
     * Returns the web server private key, when invoked for the mode
     * {@link CredentialManager#MODE_WEB_SERVER MODE_WEB_SERVER}. Returns
     * <code>null</code> otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public PrivateKey getMatchingPrivateKey(Certificate certificate,
            String endpointURI, byte mode) {
        if (mode == MODE_WEB_SERVER) {
            System.err.println("getMatchingPrivateKey 1");
            if (webServerCertChain[0].equals(certificate)) {
                System.err.println("getMatchingPrivateKey 2: "
                        + webServerPrivateKey);
                return webServerPrivateKey;
            }
        }
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public byte[] choosePreSharedKey(String pskIdentity, String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentityHint(String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentity(String hint, String endpointURI, byte mode) {
        return null;
    }

    /**
     * Returns the DES secret key shared with the <em>Transit Turnstile</em>
     * application. This key is only returned if <code>endpointURI</code>
     * corresponds to the <em>Ticketbook</em> service URI and if
     * <code>aliases</code> contains the alias
     * <code>"TURNSTILE-CREDENTIAL"</code> declared in the runtime descriptor of
     * the <em>Transit POS</em> application. Returns <code>null</code>
     * otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Object[] getTrustedCredentials(String[] aliases, String endpointURI,
            byte mode) {
        if (endpointURI.indexOf("/ticketbook") > 0) {
            for (String alias : aliases) {
                if (alias.equals("TURNSTILE-CREDENTIAL")) {
                    return new Object[] { turnstileKey };
                }
            }
        }
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Key[] getCredentials(String[] types, String endpointURI, byte mode) {
        return null;
    }
}
