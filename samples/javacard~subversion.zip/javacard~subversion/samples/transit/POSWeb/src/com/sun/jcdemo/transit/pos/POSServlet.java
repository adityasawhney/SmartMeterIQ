/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import com.sun.jcdemo.transit.I18nDispatcher;
import com.sun.jcdemo.transit.DateFormatter;
import com.sun.jcdemo.transit.Utils;

import java.io.PrintWriter;
import java.io.IOException;

import java.io.InputStream;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;
import javacardx.framework.Authenticator;
import javax.servlet.http.HttpSession;

/**
 * This class implements the front-end component of the
 * <em>Transit POS (Point Of Sale)</em> web application.
 * 
 * This servlet allows for the card holder to perform some ticketing account
 * operations. Access to the <em>Transit POS</em> web application and to this
 * servlet in particular is only allowed from a
 * <em>card holder-facing terminal</em>, such as the owner's mobile phone. This
 * constraint is set in the Java Card Platform-specific application descriptor.
 * <p>
 * Each of the account operations may be invoked using a dedicated URL query
 * path.
 * <dl>
 * <dt><code>/balance</code></dt>
 * <dd>to get the ticketbook balance</dd>
 * <dt><code>/credit-form</code></dt>
 * <dd>to fill-in a ticketbook credit form</dd>
 * <dt><code>/credit</code></dt>
 * <dd>to credit the ticketbook</dd>
 * <dt><code>/history</code></dt>
 * <dd>to get the transaction history (time and amount of debits and credits)</dd>
 * </dl>
 * This servlet retrieves from the <code>ServletContext</code> of the
 * <em>Transit POS</em> web application instance the <em>Ticketbook</em> SIO and
 * invokes its methods to perform the related account operations. Note that
 * since the the <em>Ticketbook</em> SIO is owned by this web application, the
 * methods that this servlet can invoke are not restricted to those exposed in
 * the Shareable Interface <code>SharedTicketBook</code>.
 * <p>
 * The URL for each of the ticketing account operations are protected using
 * declarative security. That is, to each of these URLs is associated a security
 * constraint in the deployment descriptor of this web application that may be
 * configure to require user authentication and confidentiality of the
 * connections over which requests to this servlet are received.
 * 
 * @see com.sun.jcdemo.transit.admin.AdminServlet
 * @see com.sun.jcdemo.transit.pos.TicketBook
 * @see com.sun.jcdemo.transit.SharedTicketBook
 * @see com.sun.jcdemo.transit.pos.SharedTicketBookControl
 * @see javacardx.facilities.ServiceRegistry
 * 
 */
public class POSServlet extends HttpServlet {

    /**
     * The <em>Ticketbook</em> service URI (relative).
     */
    static final String TICKETBOOK_URI = "ticketbook";

    /**
     * The context attribute name for the <em>Ticketbook</em> SIO.
     */
    static final String TICKETBOOK_ATTR = "com.sun.jcdemo.transit.pos.ticketbook";

    /**
     * The session attribute name for the current resource bundle.
     */
    static final String RESOURCES_ATTR = "com.sun.jcdemo.transit.pos.resources";

    /**
     * The session attribute name for the global card holder authenticator used
     * for authorizing remote administration (by a ticket booth clerk).
     */
    static final String GLOBAL_CH_AUTHENTICATOR_ATTR = "com.sun.jcdemo.transit.pos.gch_authenticator";

    /**
     * The application property name for the URI of the authenticator
     * authorizing remote administration (by a ticket booth clerk). If the
     * authenticator URI does not correspond to an already registered
     * authenticator, a PIN authenticator is registered by this application
     * (this is to provide an example of application-defined authenticator).
     */
    static final String OWNER_ADMIN_URI_PROPERTY = "OWNER-ADMIN-URI";

    /**
     * The application property name for the PIN of the authenticator for
     * authorizing remote administration (used only if the authenticator is
     * registered by this application).
     */
    static final String OWNER_ADMIN_PIN_PROPERTY = "OWNER-ADMIN-PIN";

    /**
     * The application property name for the URI of the POS user authenticator.
     * If the authenticator URI does not correspond to an already registered
     * authenticator, a PIN authenticator is registered by this application
     * (this is to provide an example of application-defined authenticator).
     */
    static final String OWNER_POS_URI_PROPERTY = "OWNER-POS-URI";

    /**
     * The application property name for the PIN of the POS user authenticator
     * (used only if the authenticator is registered by this application).
     */
    static final String OWNER_POS_PIN_PROPERTY = "OWNER-POS-PIN";

    /**
     * The application property name for the URI of the wallet service of the
     * Wallet Assist Application. The Wallet Assist extended applet
     * intermediates to allow the POS web appliction to access the classic
     * wallet applet application.
     */
    static final String WALLET_ASSIST_SIO_URI_PROPERTY = "WALLET-ASSIST-SIO-URI";

    /**
     * The <em>"GUEST-POS"</em> user role name. This role must be mapped in the
     * runtime descriptor of the <em>Transit POS</em> application to a card
     * holder user authenticator.
     */
    private static final String GUEST_ROLE = "GUEST-POS";

    /**
     * The <code>I18nDispatcher</code>.
     */
    private I18nDispatcher i18nDispatcher;

    /**
     * The <em>Ticketbook</em> SIO.
     */
    private TicketBook ticketBook = null;

    /**
     * The global card holder authenticator used for authorizing remote
     * administration (by a ticket booth clerk).
     */
    private Authenticator cardHolderAuthenticator;

    /**
     * Creates an instance of <code>POSServlet</code>.
     */
    public POSServlet() {
    }

    /**
     * Initializes this <code>POSServlet</code>.
     * <p>
     * This method retrieves from the servlet context the <em>Ticketbook</em>
     * object singleton and the global card holder authenticator used for
     * authorizing remote administration (by a ticket booth clerk). It also
     * creates and caches an instance of {@link I18nDispatcher}.
     * 
     * {@inheritDoc}
     */
    @Override
    public void init(ServletConfig config) {
        i18nDispatcher = new I18nDispatcher(config.getServletContext());

        ticketBook = (TicketBook) config.getServletContext()
                .getAttribute(TICKETBOOK_ATTR);
        cardHolderAuthenticator = (Authenticator) config.getServletContext()
                .getAttribute(GLOBAL_CH_AUTHENTICATOR_ATTR);
    }

    /**
     * Handles requests for account operations submitted with a POST HTTP
     * method.
     * <p>
     * Each of the account operations has a dedicated URL query path.
     * <dl>
     * <dt><code>/balance</code></dt>
     * <dd>to get the ticketbook balance</dd>
     * <dt><code>/credit-form</code></dt>
     * <dd>to fill-in a ticketbook credit form</dd>
     * <dt><code>/credit</code></dt>
     * <dd>to credit the ticketbook</dd>
     * <dt><code>/history</code></dt>
     * <dd>to get the transaction history (time and amount of debits and
     * credits)</dd>
     * <dt><code>/cancel-remote-admin</code></dt>
     * <dd>to cancel the authorization for remote administration</dd>
     * <dt><code>/logout</code></dt>
     * <dd>to logout and invalidate the session</dd>
     * <dt><code>/branding</code></dt>
     * <dd>to retrieve the branding banner common to all Transit applications</dd>
     * </dl>
     * Methods of the <em>Ticketbook</em> object are invoked to perform the
     * related account operations.
     * <p>
     * The handling of the <code>/balance</code> URL query path uses
     * programmatic user role-based security to support a
     * <code>GUEST_ROLE</code> which provides a restricted view of the balance
     * information.
     * <p>
     * When assembling pages from static page fragments or when forwarding to a
     * static resource, this method invokes the {@link I18nDispatcher
     * com.sun.jcdemo.transit.I18nDispatcher} object to search for a localized
     * version of the static resource that is acceptable to the user and forward
     * the request to that localized resource.
     * 
     * {@inheritDoc}
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();

        HttpSession session = request.getSession(true);

        RequestDispatcher dispatcher;

        ResourceBundle resourceBundle = (ResourceBundle) session
                .getAttribute(RESOURCES_ATTR);
        if (resourceBundle == null) {
            resourceBundle = getResourceBundle((Enumeration<Locale>) request
                    .getLocales());
            session.setAttribute(RESOURCES_ATTR, resourceBundle);
        }

        if (path.equals("/branding")) {
            InputStream is = getClass()
                    .getResourceAsStream("/com/sun/jcdemo/transit/rsrc/images/title.png");
            if (is != null) {
                Utils.copy(is, response.getOutputStream());
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        } else {
            // Note that getWriter is called before a i18nDispatcher.include
            // to ensure that the PrintWriter can be used for dynamic content
            PrintWriter out = response.getWriter();

            if (path.equals("/balance")) {
                String authorizeLabel = resourceBundle.getString("AUTHORIZE");
                String cancelLabel = resourceBundle.getString("CANCEL");

                // No request parameter to parse...
                int balance = ticketBook.getBalance();
                // Build response...
                i18nDispatcher.include("/WEB-INF/POSMain-1.html",
                        request,
                        response);

                if (request.isUserInRole(GUEST_ROLE)) {
                    out.println(balance);
                } else {
                    out.println(balance);
                    i18nDispatcher.include("/WEB-INF/POSMain-footer.html",
                            request,
                            response);

                    boolean enabled = (cardHolderAuthenticator != null && cardHolderAuthenticator
                            .isValidated());
                    out.print("<form action=\"OwnerAuthorization.html\" method=\"get\"><button type=\"submit\" ");
                    out.println((enabled ? "disabled" : "enabled") + ">"
                            + authorizeLabel + "</button></form>");
                    out.print("<form action=\"cancel-remote-admin\" method=\"post\"><button type=\"submit\" ");
                    out.println((enabled ? "enabled" : "disabled") + ">"
                            + cancelLabel + "</button></form>");
                }
                i18nDispatcher.include("/WEB-INF/POSMain-footer-2.html",
                        request,
                        response);
            } else if (path.equals("/credit-form")) {
                int balance = ticketBook.getBalance();
                // Build response...
                i18nDispatcher.include("/WEB-INF/POSCredit-1.html",
                        request,
                        response);

                out.println(balance);
                i18nDispatcher.include("/WEB-INF/POSCredit-footer.html",
                        request,
                        response);
            } else if (path.equals("/credit")) {
                String numtktsstring = request.getParameter("NumTickets");
                if (numtktsstring != null) {
                    int count = 0;
                    try {
                        count = Integer.parseInt(numtktsstring);
                    } catch (Exception e) {
                    }
                    if (count > 0) {
                        /*
                         * Interact with wallet application to perform the
                         * financial transaction
                         */
                        int balance = ticketBook.getBalance();
                        if (balance == ticketBook.credit(count)) { // unchanged
                            i18nDispatcher.forward("/WalletDebitFailed.html",
                                    request,
                                    response);
                        }
                    }
                    // Forward to /balance
                    dispatcher = request.getRequestDispatcher("/balance");
                    dispatcher.forward(request, response);
                }
            } else if (path.equals("/history")) {
                DateFormatter dateFormatter = (DateFormatter) resourceBundle
                        .getObject("DateFormatter");
                String timeLabel = resourceBundle.getString("Time:");
                String creditLabel = resourceBundle.getString("Credit:");
                String debitLabel = resourceBundle.getString("Debit:");

                // length corresponds to the number of history
                // entries to be displayed per group in the page.
                String numtransstring = request
                        .getParameter("NumTransactionsDropDown");
                int length = 5;
                if (numtransstring != null) {
                    try {
                        length = Integer.parseInt(numtransstring);
                    } catch (Exception e) {
                    }
                }
                long[][] history = null;
                if (length <= 0) {
                    length = 5;
                }
                history = new long[length][2];

                int balance = ticketBook.getBalance();
                // format history page
                i18nDispatcher.include("/WEB-INF/POSHistory-1.html",
                        request,
                        response);
                out.println(balance);
                i18nDispatcher.include("/WEB-INF/POSHistory-2.html",
                        request,
                        response);
                int start = 0;
                while ((history = ticketBook.getHistory(history, start)) != null) {
                    // iterate to print transaction history
                    for (int i = 0; i < history.length; i++) {
                        if (history[i][0] == 0) {
                            break; // zero filled transaction
                        }
                        out.print(timeLabel + " "
                                + dateFormatter.format(new Date(history[i][0]))
                                + "   ");
                        if (history[i][1] < 0) {
                            out.print(debitLabel + " " + history[i][1] + "<br>");
                        } else {
                            out.print(creditLabel + " " + history[i][1] + "<br>");
                        }
                    }
                    start = start += length;
                    if (length == 0) {
                        break;
                    }
                }
                i18nDispatcher.include("/WEB-INF/POSHistory-Footer.html",
                        request,
                        response);
            } else if (path.equals("/cancel-remote-admin")) {
                if (cardHolderAuthenticator != null) {
                    cardHolderAuthenticator.reset();
                }
                i18nDispatcher.forward("/OwnerAuthorizationCancelled.html",
                        request,
                        response);
            } else if (path.equals("/logout")) {
                boolean basicAuth = HttpServletRequest.BASIC_AUTH
                        .equals(request.getAuthType());
                if (session != null) {
                    session.invalidate();
                }
                if (basicAuth) {
                    // Force to re-authenticate as an "exit" user
                    response.sendRedirect(response
                            .encodeRedirectURL("logout-from-basic-auth"));
                } else {
                    // Assume invalidation of session effectively logs the user
                    // out
                    dispatcher = request.getRequestDispatcher("/balance");
                    dispatcher.forward(request, response);
                }
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        }
    }

    /**
     * Handles requests for account operations submitted with a GET HTTP method.
     * <p>
     * This method delegates to the
     * {@link #doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     * doPost} method.
     * 
     * {@inheritDoc}
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    /**
     * Cleans up this <code>POSServlet</code> state and used resources.
     * <p>
     * The references to the <em>Ticketbook</em> object, global card holder
     * authenticator and {@link I18nDispatcher} are cleared.
     * 
     * {@inheritDoc}
     */
    @Override
    public void destroy() {
        ticketBook = null;
        cardHolderAuthenticator = null;
        i18nDispatcher = null;
    }

    private ResourceBundle getResourceBundle(Enumeration<Locale> locales)
            throws IOException, ServletException {
        ResourceBundle resourceBundle = null;
        while (locales.hasMoreElements()) {
            Locale locale = locales.nextElement();
            resourceBundle = ResourceBundle
                    .getBundle("com.sun.jcdemo.transit.Resources", locale);
            // resourceBundle can't be null
            // Keep searching unless this is the default locale
            // and one of the acceptable locales
            if ((locale.equals(Locale.getDefault()) && resourceBundle
                    .getLocale().equals(Locale.getDefault()))
                    || !resourceBundle.getLocale().toString().equals("")) {
                break;
            }
        }
        return resourceBundle;
    }
}
