/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import javacardx.framework.Authenticator;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * This class implements an HTTP session listener. An instance of this class is
 * automatically created by the servlet container when the <em>Transit POS</em>
 * web application is instantiated and before any request is dispatched to it.
 * The registered instance is invoked by the servlet container to handle HTTP
 * session lifecycle events: session creation and destruction. Only the
 * destruction event is handled:
 * <ul>
 * <li>Upon destruction of the HTTP session, the global card holder
 * authenticator used for authorizing remote administration (by a ticket booth
 * clerk) is reset, hence preventing any further use of the service.</li>
 * </ul>
 * This HTTP session listener is declared and configured in the deployment
 * descriptor of the <em>Transit POS</em> web application.
 */
public class SessionListener implements HttpSessionListener {

    /**
     * Invoked when a new HTTP session is created.
     * 
     * @see javax.servlet.http.HttpSessionListener#sessionCreated(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent hse) {
    }

    /**
     * Invoked when an HTTP session is destroyed.
     * <p>
     * This method resets the global card holder authenticator used for
     * authorizing remote administration (by a ticket booth clerk).
     * 
     * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent hse) {
        ServletContext context = hse.getSession().getServletContext();
        Authenticator authenticator = (Authenticator) context
                .getAttribute(POSServlet.GLOBAL_CH_AUTHENTICATOR_ATTR);
        if (authenticator != null) {
            authenticator.reset();
        }
    }
}
