/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import com.sun.jcdemo.transit.SharedTicketBook;
import java.util.Vector;

import javacardx.facilities.Event;
import javacardx.facilities.EventRegistry;
import javacardx.facilities.ServiceRegistry;
import javacardx.framework.JCSystem;
import javacardx.framework.TransactionType;
import static javacardx.framework.TransactionTypeValue.REQUIRED;
import com.sun.jcdemo.wallet.SharedWalletAccess;
import static com.sun.jcdemo.transit.pos.POSServlet.WALLET_ASSIST_SIO_URI_PROPERTY;

/**
 * This class encapsulates the functionalities of a <em>TicketBook</em>.
 * <p>
 * A single instance of this class is created by the <em>Transit POS</em>
 * application and exposed as a service to client applications: the
 * <em>Transit Admin</em> and <em>Transit Turnstile</em> applications, which
 * executes in different contexts.
 * <p>
 * The methods of a <em>TicketBook</em> object perform the following
 * administration and ticketing account operations:
 * <ul>
 * <li>get the ticketbook balance</li>
 * <li>debit the ticketbook</li>
 * <li>credit the ticketbook</li>
 * <li>unblock the use of the ticketbook</li>
 * </ul>
 * Certain operations asynchronously notify through the event registry client
 * applications of particular occurring conditions such as:
 * <dl>
 * <dt><code>ticketbook/credited</code></dt>
 * <dd>The ticketbook has been credited of an amount sufficient to allow the use
 * of the <em>Transit Turnstile</em> application.</dd>
 * <dt><code>ticketbook/overdraft</code></dt>
 * <dd>The ticketbook has been debited of an amount that results in a negative
 * balance.</dd>
 * <dt><code>ticketbook/unblocked</code></dt>
 * <dd>The ticketbook has been unblocked either by an administrator or by the
 * user by crediting enough his ticketbook.</dd>
 * </dl>
 * Each such occurring condition is encapsulated in an instance of the
 * <code>Event</code> class. The source of the event object is set to the URI of
 * the ticketbook service. This potentially allows for the same
 * <em>Transit POS</em> application to manage and expose different ticketbook
 * services and for the event consuming applications to discriminate between the
 * sources of the events. Note also that the ticketbook event URI above are
 * relative and will get resolved against the <em>Transit POS</em> application's
 * URI. If two instances of the <em>Transit POS</em> application were created
 * these relative event URI would be resolved to different absolute URIs.
 * <p>
 * Operations on the ticketbook are protected using role-based programmatic
 * security. That is, each method implements specific access control checks
 * based on the calling client and the user on behalf of whom the operation is
 * attempted. The roles used for these security checks -
 * <em>"TURNSTILE_CLIENT"</em>, <em>"ADMIN_CLIENT"</em>, <em>"ADMIN"</em> and
 * <em>"OWNER-POS"</em> are logical names that are mapped to actual clients and
 * users, repsectively, in the runtime descriptor of the <em>Transit POS</em>
 * application.
 */
public class TicketBook implements SharedTicketBook, SharedTicketBookControl {

    /**
     * The <em>"TURNSTILE_CLIENT"</em> client role name. This role must be
     * mapped in the runtime descriptor of the <em>Transit POS</em> application
     * to some characteristics of the <em>Transit Turnstile</em> application.
     */
    static final String TURNSTILE_CLIENT_ROLE = "TURNSTILE_CLIENT";

    /**
     * The <em>"ADMIN_CLIENT"</em> client role name. This role must be mapped in
     * the runtime descriptor of the <em>Transit POS</em> application to some
     * characteristics of the <em>Transit Admin</em> application.
     */
    static final String ADMIN_CLIENT_ROLE = "ADMIN_CLIENT";

    /**
     * The <em>"ADMIN"</em> user role name. This role must be mapped in the
     * runtime descriptor of the <em>Transit POS</em> application to a
     * "non-card holder" user authenticator.
     */
    private static final String ADMIN_USER_ROLE = "ADMIN";

    /**
     * The <em>"OWNER-POS"</em> user role name. This role must be mapped in the
     * runtime descriptor of the <em>Transit POS</em> application to a card
     * holder user authenticator.
     */
    private static final String USER_ROLE = "OWNER-POS";

    /**
     * The <em>"COST_PER_TICKET"</em> is the $ cost of each transit ride ticket.
     */
    private static final byte COST_PER_TICKET = 1;

    /**
     * The <em>"walletAssistSIOURI"</em> applet uri. This attribute must be
     * mapped in the runtime descriptor of the <em>Transit POS</em> application
     * to the wallet assist extended application sio uri.
     */
    String walletAssistSIOURI
            = JCSystem.getAppProperty(WALLET_ASSIST_SIO_URI_PROPERTY, null);

    /**
     * The ticketbook service URI.
     */
    private final String serviceURI;

    /**
     * The current ticketbook balance
     */
    private int balance = 0;

    /**
     * The transaction history. Each entry is a pair of <code>long</code> of the
     * form: {time of transaction, debited/credited ticket count}.
     */
    private Vector<long[]> history = new Vector<long[]>();

    /**
     * The event registry reference (caching purpose).
     */
    private EventRegistry eventRegistry;

    /**
     * Creates an instance of <em>TicketBook</em>.
     * 
     * @param serviceURI
     *            the ticketbook service URI.
     */
    public TicketBook(String serviceURI) {
        this.serviceURI = serviceURI;
        eventRegistry = EventRegistry.getEventRegistry();
    }

    /**
     * Returns the ticketbook balance.
     * 
     * @return the ticketbook balance.
     * @throws SecurityException
     *             <ul>
     *             <li>if the caller is not the <em>Transit POS</em> application
     *             itself (calling on an actual instance),</li> <li>and, if the
     *             application client attempting this operation is not in the
     *             <em>"ADMIN_CLIENT"</em> client role or the user on behalf of
     *             whom this operation is attempted is not in the <em>"ADMIN"
     *             </em> user role (calling through a proxy).</li>
     *             </ul>
     */
    public synchronized int getBalance() throws SecurityException {
        if (!JCSystem.getURI().equals(JCSystem.getClientURI())) {
            if (!(JCSystem.isClientInRole(ADMIN_CLIENT_ROLE, serviceURI)
                    && JCSystem.isUserInRole(ADMIN_USER_ROLE, null))) {
                throw new SecurityException();
            }
        }

        /*
         * There is no need to check that the calling user is in the "OWNER-POS"
         * since this is already enforced by the web declarative security.
         */
        return balance;
    }

    /**
     * Credits the ticketbook. If the balance was negative and becomes positive,
     * an event with the <code>ticketbook/credited</code> URI is fired to notify
     * client applications such as the <em>Transit Turnstile</em> application
     * that it can resume transit entrance authorizations.
     * 
     * @param count
     *            the number of tickets credited.
     * @return the current balance.
     */
    @TransactionType(REQUIRED)
    public synchronized int credit(int count) {
        /*
         * There is no need to check the calling user since this is already
         * enforced by the web declarative security and this method is not
         * exposed to other applications.
         */

        // debit the cost of the tickets from wallet
        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        SharedWalletAccess wallet = (SharedWalletAccess) serviceRegistry
                .lookup(walletAssistSIOURI);

        if ((wallet == null)
                || (!wallet.debit((byte) (count * COST_PER_TICKET)))) {
            history.addElement(new long[] { System.currentTimeMillis(), 0 });
            return balance; // no tickets credited
        }

        if (/* balance <= 0 && */(balance + count) > 0) {
            eventRegistry.notifyListenersInRole(new Event(
            /* serviceURI, */"ticketbook/credited", null),
                    TURNSTILE_CLIENT_ROLE);
        }
        balance += count;
        // log credit operation in transaction history
        history.addElement(new long[] { System.currentTimeMillis(), count });
        return balance;
    }

    /**
     * Debits the ticketbook. If the balance becomes negative, an event with the
     * <code>ticketbook/overdraft</code> URI is fired to notify client
     * applications such as the <em>Transit Turnstile</em> application that it
     * should stop delivering transit entrance authorizations.
     * 
     * @param count
     *            the number of tickets credited.
     * @return the new ticketbook balance.
     * @throws SecurityException
     *             if the application client attempting this operation is not in
     *             the <em>"TURNSTILE_CLIENT"</em> client role.
     */
    @TransactionType(REQUIRED)
    public synchronized int debit(int count) throws SecurityException {
        if (!JCSystem.isClientInRole(TURNSTILE_CLIENT_ROLE, serviceURI)) {
            throw new SecurityException();
        }

        balance -= count;
        if (balance <= 0) {
            eventRegistry.notifyListenersInRole(new Event(
            /* serviceURI, */"ticketbook/overdraft", null),
                    TURNSTILE_CLIENT_ROLE);
        }
        // log debit operation in transaction history
        history.addElement(new long[] { System.currentTimeMillis(), -count });
        return balance;
    }

    /**
     * Unblocks the ticketbook. An event with the
     * <code>ticketbook/unblocked</code> URI is fired to notify client
     * applications such as the <em>Transit Turnstile</em> application that it
     * should resume delivering transit entrance authorizations.
     * <p>
     * The ticketbook may have been blocked after some inconsistency in the
     * entrance and exit tracking by the <em>Transit Turnstile</em> application
     * or because the user attempted to exit in a fare zone for which he does
     * not have sufficient balance.
     * 
     * @throws SecurityException
     *             if the application client attempting this operation is not in
     *             the <em>"TURNSTILE_CLIENT"</em> client role or the user on
     *             behalf of whom this operation is attempted is not in the
     *             <em>"ADMIN"</em> user role.
     */
    public synchronized void unblock() {
        if (!JCSystem.getURI().equals(JCSystem.getClientURI())) {
            if (!(JCSystem.isClientInRole(ADMIN_CLIENT_ROLE, serviceURI)
                    && JCSystem.isUserInRole(ADMIN_USER_ROLE, null))) {
                throw new SecurityException();
            }
        }

        eventRegistry.notifyListenersInRole(new Event(
        /* serviceURI, */"ticketbook/unblocked", null), TURNSTILE_CLIENT_ROLE);
    }

    /**
     * Gets the transaction history. The history is returned as an array of
     * <code>long</code> pairs of the form: {time of transaction,
     * debited/credited ticket count}.
     * <p>
     * If the provided <code>buffer</code> argument is <code>null</code> this
     * method returns the complete transaction history available.
     * <p>
     * If the provided <code>buffer</code> argument is not <code>null</code>
     * this method copies into the provided <code>buffer</code> the transaction
     * history up to the size of the provided buffer.
     * <p>
     * If the provided <code>start</code> parameter is too large, it returns
     * <code>null</code>
     * <p>
     * This method zero fills the unused entries of the buffer
     * 
     * @param buffer
     *            if not <code>null</code>, the buffer to be reused to return
     *            all or a part of the available transaction history (in which
     *            case the ownership of this buffer must have been transferred
     *            by the calling client to this application); if
     *            <code>null</code>, the complete available history must be
     *            returned in a newly allocated buffer.
     * @param start
     *            contains the offset within the history vector to start. This
     *            parameter is ignored if the complete available history is
     *            being returned.
     * @return all or a part of the available transaction history; the ownership
     *         of the returned buffer is transferred to the calling client.
     * 
     * @throws SecurityException
     *             <ul>
     *             <li>if the caller is not the <em>Transit POS</em> application
     *             itself,</li> <li>and, if the application client attempting
     *             this operation is not in the <em>"ADMIN_CLIENT"</em> client
     *             role or the user on behalf of whom this operation is
     *             attempted is not in the <em>"ADMIN"</em> user role.</li>
     *             </ul>
     */
    public synchronized long[][] getHistory(long[][] buffer, int start) {
        if (!JCSystem.getURI().equals(JCSystem.getClientURI())) {
            if (!(JCSystem.isClientInRole(ADMIN_CLIENT_ROLE, serviceURI)
                    && JCSystem.isUserInRole(ADMIN_USER_ROLE, null))) {
                throw new SecurityException();
            }
        }

        int len; // length to copy
        if (buffer == null) {
            // return entire history
            buffer = new long[history.size()][2];
            len = history.size();
            start = 0;
        } else if (start >= history.size()) {
            // requested history item is out of bounds
            return null;
        } else if (history.size() - start < buffer.length) {
            // history items to be written are not enough to fill buffer
            len = history.size() - start;
        } else {
            // history items to be written can fill buffer
            len = buffer.length;
        }
        // copy history entries into buffer
        int j = 0; // buffer offset
        for (int i = start; j < len; i++, j++) {
            long[] historyElement = history.elementAt(i);
            System.arraycopy(historyElement, 0, buffer[j], 0, 2);
        }
        // zero out unused entries of buffer
        while (j < buffer.length) {
            buffer[j][0] = 0;
            buffer[j][1] = 0;
            j++;
        }

        // Data transfer back and forth b/w client
        // and server reusing the same buffer array
        for (int i = 0; i < buffer.length; i++) {
            // Transfer each element back to client: no copy
            JCSystem.transferOwnership(buffer[i]);
        }
        // Transfer history buffer back to client: no copy
        JCSystem.transferOwnership(buffer);

        return buffer;
    }
}
