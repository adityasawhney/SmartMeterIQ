/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos;

import static com.sun.jcdemo.transit.pos.TicketBook.ADMIN_CLIENT_ROLE;
import static com.sun.jcdemo.transit.pos.TicketBook.TURNSTILE_CLIENT_ROLE;
import javacard.framework.Shareable;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.JCSystem;

/**
 * This class implements a <em>TicketBook</em> service factory. An instance of
 * this class is registered in the service registry in order for the
 * <em>Transit Admin</em> and <em>Transit Turnstile</em> applications to
 * retrieve the <em>TicketBook</em> service - a singleton SIO instance.
 * 
 */
public class TicketBookFactory implements ServiceFactory {

    /**
     * The singleton <code>TicketBook</code> SIO instance to be returned to
     * client applications.
     */
    private TicketBook instance = null;

    /**
     * Creates an instance of <code>TicketBookFactory</code>.
     */
    TicketBookFactory() {
    }

    /**
     * Returns the singleton <code>TicketBook</code> instance.
     * 
     * @return the singleton <code>TicketBook</code> instance.
     * @throws SecurityException
     *             if the application client attempting to retrieve the
     *             <em>Ticketbook</em> service is not the <em>Transit Admin</em>
     *             or <em>Transit Turnstile</em> application. Note that this is
     *             only a fail-fast security check at lookup-time and that the
     *             <code>TicketBook</code> SIO implements more specific access
     *             controls.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        System.err
                .println("JCSystem.getClientURI():" + JCSystem.getClientURI());
        if (!(JCSystem.getClientURI() == null
                || JCSystem.getClientURI().equals(JCSystem.getURI())
                || JCSystem.isClientInRole(ADMIN_CLIENT_ROLE, serviceURI)
                || JCSystem.isClientInRole(TURNSTILE_CLIENT_ROLE, serviceURI))) {
            throw new SecurityException();
        }
        synchronized (this) {
            if (instance == null) {
                instance = new TicketBook(serviceURI);
            }
        }
        return instance;
    }
}
