/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos.auth;

import javacard.framework.OwnerPIN;
import javacard.framework.Shareable;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.SharedPINAuth;
import javacardx.framework.TransactionType;
import javacardx.framework.TransactionTypeValue;

/**
 * This class encapsulates a Global Card Holder PIN-based authentication service
 * factory. It implements the following characteristics:
 * <ul>
 * <li>it returns the same instance of {@link javacardx.framework.SharedPINAuth
 * SharedPINAuth} upon each call (regsitry lookup), hence encapsulating a shared
 * authentication state</li>
 * <li>it must be registered in the service registry for a Global Card Holder
 * authenticator URI with a PIN authentication scheme:<br>
 * <code>sio:///standard/auth/holder/global/<i>[&lt;realm&gt;/]</i><i>&lt;user&gt;</i>/pin</code>
 * </li>
 * <li>it provides access to the underlying owner PIN
 * {@link javacard.framework.OwnerPIN} for administration of the PIN.</li>
 * </ul>
 */
@TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
public class GlobalPINAuthFactory implements ServiceFactory {

    /**
     * Underlying <code>OwnerPIN</code> instance.
     */
    private final OwnerPIN ownerPIN;

    /**
     * Authenticator singleton - owner PIN proxy.
     */
    private final GlobalPINAuth auth;

    /**
     * Creates a service factory for Global Card Holder PIN-based
     * authentication.
     * 
     * @param pin
     *            the initial PIN.
     * @param tryLimit
     *            the maximum number of failed tries.
     */
    public GlobalPINAuthFactory(byte[] pin, int tryLimit) {
        super();
        ownerPIN = new OwnerPIN((byte) tryLimit, (byte) pin.length);
        ownerPIN.update(pin, (byte) 0, (byte) pin.length);
        auth = new GlobalPINAuth();
    }

    /**
     * Creates a Global Card Holder PIN-based authenticator. Returns the same
     * instance each time.
     * 
     * @param serviceURI
     *            the registered URI of this authenticator.
     * @param parameter
     *            ignored.
     * @return the Global Card Holder PIN-based authenticator, or null if
     *         <code>serviceURI</code> is not that of a Global Card Holder
     *         PIN-based authenticator.
     * @throws java.lang.SecurityException
     *             if a security exception occurs.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        if (serviceURI.startsWith("sio:///standard/auth/holder/global/")
                && serviceURI.endsWith("/pin")) {
            return auth;
        }
        return null;
    }

    /**
     * This class encapsulates a Global Card Holder PIN-based authenticator. It
     * ensures synchronized access to the underlying <code>OwnerPIN</code>
     * instance.
     */
    @TransactionType(value = TransactionTypeValue.SUPPORTS)
    private class GlobalPINAuth implements SharedPINAuth {

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public synchronized boolean check(byte[] pin, short offset, byte length) {
            return ownerPIN.check(pin, offset, length);
        }

        /**
         * {@inheritDoc}
         */
        public synchronized byte getTriesRemaining() {
            return ownerPIN.getTriesRemaining();
        }

        /**
         * {@inheritDoc}
         */
        public synchronized boolean isValidated() {
            return ownerPIN.isValidated();
        }

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public synchronized void reset() {
            ownerPIN.reset();
        }
    }

    /**
     * Returns the underlying <code>OwnerPIN</code> instance.
     * 
     * @return the underlying <code>OwnerPIN</code instance.
     */
    public OwnerPIN getOwnerPIN() {
        return ownerPIN;
    }
}
