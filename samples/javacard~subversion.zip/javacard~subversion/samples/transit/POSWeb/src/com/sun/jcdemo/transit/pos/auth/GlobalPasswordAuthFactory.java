/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos.auth;

import javacard.framework.Shareable;
import javacardx.biometry.BioBuilder;
import javacardx.biometry.OwnerBioTemplate;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.SharedPasswordAuth;
import javacardx.framework.TransactionType;
import javacardx.framework.TransactionTypeValue;

/**
 * This class encapsulates a Global Card Holder password-based authentication
 * service factory. It implements the following characteristics:
 * <ul>
 * <li>it returns the same instance of
 * {@link javacardx.framework.SharedPasswordAuth SharedPasswordAuth} upon each
 * call (regsitry lookup), hence encapsulating a shared authentication state</li>
 * <li>it must be registered in the service registry for a Global Card Holder
 * authenticator URI with a password authentication scheme:<br>
 * <code>sio:///standard/auth/holder/global/<i>[&lt;realm&gt;/]</i><i>&lt;user&gt;</i>/password</code>
 * </li>
 * <li>it provides access to the underlying owner password
 * {@link javacardx.biometry.OwnerBioTemplate} for adminstration of the
 * password.</li>
 * </ul>
 */
@TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
public class GlobalPasswordAuthFactory implements ServiceFactory {

    /**
     * Underlying <code>OwnerBioTemplate</code> instance.
     */
    private final OwnerBioTemplate ownerPassword;

    /**
     * Authenticator singleton - owner password proxy.
     */
    private final GlobalPasswordAuth auth;

    /**
     * Creates a service factory for Global Card Holder password-based
     * authentication.
     * 
     * @param password
     *            the initial passowrd.
     * @param tryLimit
     *            the maximum number of failed tries.
     */
    public GlobalPasswordAuthFactory(String password, int tryLimit) {
        super();
        ownerPassword = BioBuilder.buildBioTemplate(BioBuilder.PASSWORD,
                (byte) tryLimit);
        byte[] pwdBytes = password.getBytes();
        ownerPassword.init(pwdBytes, (byte) 0, (byte) pwdBytes.length);
        ownerPassword.doFinal();
        auth = new GlobalPasswordAuth();
    }

    /**
     * Creates a Global Card Holder password-based authenticator. Returns the
     * same instance each time.
     * 
     * @param serviceURI
     *            the registered URI of this authenticator.
     * @param parameter
     *            ignored.
     * @return the Global Card Holder password-based authenticator, or null if
     *         <code>serviceURI</code> is not that of a Global Card Holder
     *         password-based authenticator.
     * @throws java.lang.SecurityException
     *             if a security exception occurs.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        if (serviceURI.startsWith("sio:///standard/auth/holder/global/")
                && serviceURI.endsWith("/password")) {
            return auth;
        }
        return null;
    }

    /**
     * This class encapsulates a Global Card Holder password-based
     * authenticator. It ensures synchronized access to the underlying
     * <code>OwnerBioTemplate</code> instance.
     */
    @TransactionType(value = TransactionTypeValue.SUPPORTS)
    private class GlobalPasswordAuth implements SharedPasswordAuth {

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public synchronized boolean check(String password) {
            byte[] pwdBytes = password.getBytes();
            ownerPassword.initMatch(pwdBytes, (byte) 0, (byte) pwdBytes.length);
            return ownerPassword.isValidated();
        }

        /**
         * {@inheritDoc}
         */
        public synchronized byte getTriesRemaining() {
            return ownerPassword.getTriesRemaining();
        }

        /**
         * {@inheritDoc}
         */
        public synchronized boolean isValidated() {
            return ownerPassword.isValidated();
        }

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public synchronized void reset() {
            ownerPassword.reset();
        }
    }

    /**
     * Returns the underlying <code>OwnerBioTemplate</code> instance.
     * 
     * @return the underlying <code>OwnerBioTemplate</code instance.
     */
    public OwnerBioTemplate getOwnerPassword() {
        return ownerPassword;
    }
}
