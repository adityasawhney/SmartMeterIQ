/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos.auth;

import javacard.framework.OwnerPIN;
import javacard.framework.Shareable;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.SharedPINAuth;
import javacardx.framework.TransactionType;
import javacardx.framework.TransactionTypeValue;
import javacardx.framework.TransientReference;

/**
 * This class encapsulates a session PIN-based authentication service factory.
 * It implements the following characteristics:
 * <ul>
 * <li>it returns a different instance of
 * {@link javacardx.framework.SharedPINAuth SharedPINAuth} upon each call
 * (regsitry lookup), hence encapsulating a distinct authentication state</li>
 * <li>it must be registered in the service registry for a session authenticator
 * URI with a PIN authentication scheme:<br>
 * <code>sio:///standard/auth/<i>[</i>holder<i>|</i>user<i>]</i>/session/<i>[&lt;realm&gt;/]</i><i>&lt;user&gt;</i>/pin</code>
 * </li>
 * <li>it provides access to the underlying "master" owner PIN
 * {@link javacard.framework.OwnerPIN} for administration of the PIN.</li>
 * </ul>
 */
@TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
public class SessionPINAuthFactory implements ServiceFactory {

    /**
     * Underlying <code>OwnerPIN</code> instance.
     */
    private final OwnerPIN ownerPIN;

    /**
     * Creates a service factory for session PIN-based authentication.
     * 
     * @param pin
     *            the initial PIN.
     * @param tryLimit
     *            the maximum number of failed tries.
     */
    public SessionPINAuthFactory(byte[] pin, int tryLimit) {
        super();
        ownerPIN = new OwnerPIN((byte) tryLimit, (byte) pin.length);
        ownerPIN.update(pin, (byte) 0, (byte) pin.length);
    }

    /**
     * Creates a session PIN-based authenticator. Returns a different instance
     * each time.
     * 
     * @param serviceURI
     *            the registered URI of this authenticator.
     * @param parameter
     *            ignored.
     * @return the session PIN-based authenticator, or null if
     *         <code>serviceURI</code> is not that of a session PIN-based
     *         authenticator.
     * @throws java.lang.SecurityException
     *             if a security exception occurs.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        if ((serviceURI.startsWith("sio:///standard/auth/holder/session/") || serviceURI
                .startsWith("sio:///standard/auth/user/session/"))
                && serviceURI.endsWith("/pin")) {
            return new SessionPINAuth();
        }
        return null;
    }

    /**
     * This class encapsulates a session PIN-based authenticator. It ensures
     * synchronized access to the underlying <code>OwnerPIN</code> instance and
     * maintains a distinct authentication state (validated flag) which is reset
     * on every card reset.
     */
    @TransactionType(value = TransactionTypeValue.SUPPORTS)
    private class SessionPINAuth implements SharedPINAuth {

        private final TransientReference<Boolean> validated = new TransientReference<Boolean>(
                false);

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public boolean check(byte[] pin, short offset, byte length) {
            validated.set(false);
            synchronized (ownerPIN) {
                try {
                    validated.set(ownerPIN.check(pin, offset, length));
                } finally {
                    ownerPIN.reset();
                }
            }
            return validated.get();
        }

        /**
         * {@inheritDoc}
         */
        public byte getTriesRemaining() {
            synchronized (ownerPIN) {
                return ownerPIN.getTriesRemaining();
            }
        }

        /**
         * {@inheritDoc}
         */
        public boolean isValidated() {
            return validated.get() != null && validated.get();
        }

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public void reset() {
            if (validated.get() != null && validated.get()) {
                validated.set(false);
            }
        }
    }

    /**
     * Returns the underlying <code>OwnerPIN</code> instance.
     * 
     * @return the underlying <code>OwnerPIN</code instance.
     */
    public OwnerPIN getOwnerPIN() {
        return ownerPIN;
    }
}
