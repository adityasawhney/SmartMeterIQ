/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.pos.auth;

import javacard.framework.Shareable;
import javacardx.biometry.BioBuilder;
import javacardx.biometry.BioException;
import javacardx.biometry.OwnerBioTemplate;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.SharedPasswordAuth;
import javacardx.framework.TransactionType;
import javacardx.framework.TransactionTypeValue;
import javacardx.framework.TransientReference;

/**
 * This class encapsulates a session password-based authentication service
 * factory. It implements the following characteristics:
 * <ul>
 * <li>it returns a different instance of
 * {@link javacardx.framework.SharedPasswordAuth SharedPasswordAuth} upon each
 * call (regsitry lookup), hence encapsulating a distinct authentication state</li>
 * <li>it must be registered in the service registry for a session authenticator
 * URI with a password authentication scheme:<br>
 * <code>sio:///standard/auth/<i>[</i>holder<i>|</i>user<i>]</i>/session/<i>[&lt;realm&gt;/]</i><i>&lt;user&gt;</i>/password</code>
 * </li>
 * <li>it provides access to the underlying "master" owner password
 * {@link javacardx.biometry.OwnerBioTemplate} for adminstration of the
 * password.</li>
 * </ul>
 */
@TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
public class SessionPasswordAuthFactory implements ServiceFactory {

    /**
     * Underlying <code>OwnerBioTemplate</code> instance.
     */
    private final OwnerBioTemplate ownerPassword;

    /**
     * Creates a service factory for session password-based authentication.
     * 
     * @param password
     *            the initial passowrd.
     * @param tryLimit
     *            the maximum number of failed tries.
     */
    public SessionPasswordAuthFactory(String password, int tryLimit) {
        super();
        ownerPassword = BioBuilder.buildBioTemplate(BioBuilder.PASSWORD,
                (byte) tryLimit);
        byte[] pwdBytes = password.getBytes();
        ownerPassword.init(pwdBytes, (byte) 0, (byte) pwdBytes.length);
        ownerPassword.doFinal();
    }

    /**
     * Creates a session password-based authenticator. Returns a different
     * instance each time.
     * 
     * @param serviceURI
     *            the registered URI of this authenticator.
     * @param parameter
     *            ignored.
     * @return the session password-based authenticator, or null if
     *         <code>serviceURI</code> is not that of a session password-based
     *         authenticator.
     * @throws java.lang.SecurityException
     *             if a security exception occurs.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        if ((serviceURI.startsWith("sio:///standard/auth/holder/session/") || serviceURI
                .startsWith("sio:///standard/auth/user/session/"))
                && serviceURI.endsWith("/password")) {
            return new SessionPasswordAuth();
        }
        return null;
    }

    /**
     * This class encapsulates a session password-based authenticator. It
     * ensures synchronized access to the underlying
     * <code>OwnerBioTemplate</code> instance and maintains a distinct
     * authentication state (validated flag) which is reset on every card reset.
     */
    @TransactionType(value = TransactionTypeValue.SUPPORTS)
    private class SessionPasswordAuth implements SharedPasswordAuth {

        private final TransientReference<Boolean> validated = new TransientReference<Boolean>(
                false);

        /**
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public boolean check(String password) {
            validated.set(false);
            synchronized (ownerPassword) {
                try {
                    try {
                        byte[] pwdBytes = password.getBytes();
                        ownerPassword.initMatch(pwdBytes,
                                (byte) 0,
                                (byte) pwdBytes.length);
                        validated.set(ownerPassword.isValidated());
                    } finally {
                        ownerPassword.reset();
                    }
                } catch (BioException be) {
                }
            }
            return validated.get();
        }

        /**
         * {@inheritDoc}
         */
        public byte getTriesRemaining() {
            synchronized (ownerPassword) {
                return ownerPassword.getTriesRemaining();
            }
        }

        /**
         * {@inheritDoc}
         */
        public boolean isValidated() {
            return validated.get() != null && validated.get();
        }

        /**
         * Only resets the validated flag for this instance. It does not reset
         * the try counter of the underlying <code>OwnerBioTemplate</code>
         * instance.
         * 
         * {@inheritDoc}
         */
        @TransactionType(value = TransactionTypeValue.NOT_SUPPORTED)
        public void reset() {
            if (validated.get() != null && validated.get()) {
                validated.set(false);
            }
        }
    }

    /**
     * Returns the underlying <code>OwnerBioTemplate</code> instance.
     * 
     * @return the underlying <code>OwnerBioTemplate</code instance.
     */
    public OwnerBioTemplate getOwnerPassword() {
        return ownerPassword;
    }
}
