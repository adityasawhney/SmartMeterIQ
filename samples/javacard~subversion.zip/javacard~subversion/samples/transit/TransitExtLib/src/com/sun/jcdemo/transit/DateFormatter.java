/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import java.util.Date;

/**
 * This class defines the interface and common methods for formatting dates in a
 * locale-specific way.
 */
public abstract class DateFormatter {

    /**
     * Formats the provided <code>Date</code> object for display.
     * 
     * @param time
     *            the date/time.
     * @return a string representation of the provided date/time.
     */
    public abstract String format(Date time);

    /**
     * Appends the provided value to the provided <code>StringBuffer</code>
     * object and inserts any number of leading <code>'0'</code> to match the
     * provided total length.
     * 
     * @param buffer
     *            the <code>StringBuffer</code> object to append to.
     * @param value
     *            the value to be appended.
     * @param length
     *            the total number of digits to be appended.
     * @return the same <code>StringBuffer</code> object.
     */
    protected StringBuffer append(StringBuffer buffer, int value, int length) {
        String val = String.valueOf(value);
        for (int i = (length - val.length()); i > 0; i--) {
            buffer.append('0');
        }
        return buffer.append(val);
    }
}
