/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Locale;

import java.util.StringTokenizer;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * This class implements support for internationalization and localization of
 * web resources.
 * <p>
 * The <code>Accept-language</code> header is retrieved from the request (by a
 * call to {@link ServletRequest#getLocales()}) and a localized version of the
 * requested resource (e.g.:
 * <code>http://&lt;host&gt;:&lt;port&gt;/somepage.html</code>) is searched in
 * the following order:
 * <ol>
 * <li>The <code>Accept-language</code> list, for example <code>fr-CH, de</code>:
 * <ul>
 * <li><code>/fr_ch/somepage.html</code></li>
 * <li><code>/de/somepage.html</code></li>
 * </ul>
 * </li>
 * <li>Language codes without the country codes (<code>fr</code> in the case of
 * <code>fr-CH</code>):
 * <ul>
 * <li><code>/fr/somepage.html</code></li>
 * </ul>
 * </li>
 * <li>The default locale, such as <code>en</code>, returned by a call to
 * {@link java.util.Locale#getDefault()}:
 * <ul>
 * <li><code>/en/somepage.html</code></li>
 * </ul>
 * </li>
 * <li>If none of these are found, then the requested resource:
 * <ul>
 * <li><code>/somepage.html</code></li>
 * </ul>
 * </li>
 * </ol>
 */
public class I18nDispatcher {

    /**
     * The context attribute name for the supported locales.
     */
    public static final String SUPPORTED_LOCALES_PARAM = "supportedLocales";

    /**
     * The context attribute name for the turning on the delegation chain when
     * searching for a localized resource.
     */
    public static final String CHAIN_LOCALES_PARAM = "chainLocales";

    private Vector<Locale> supportedLocales = null;

    private boolean chainLocales = false;

    private ServletContext context;

    /**
     * Creates a <code>I18nDispatcher</code> object.
     * 
     * @param context
     *            the servlet context.
     */
    public I18nDispatcher(ServletContext context) {
        this.context = context;
        String locales = context.getInitParameter(SUPPORTED_LOCALES_PARAM);
        if (locales != null) {
            StringTokenizer tokenizer = new StringTokenizer(locales, ",");
            supportedLocales = new Vector<Locale>(tokenizer.countTokens());
            while (tokenizer.hasMoreTokens()) {
                String locale = tokenizer.nextToken();
                int i = locale.lastIndexOf('_');
                if (i > 0) {
                    String language = locale.substring(0, i);
                    String country = locale.substring(i + 1);
                    supportedLocales.addElement(new Locale(language, country));
                } else {
                    supportedLocales.addElement(new Locale(locale));
                }
            }
        }
        chainLocales = "true".equalsIgnoreCase(context
                .getInitParameter(CHAIN_LOCALES_PARAM));
    }

    /**
     * Searches for a localized version of the requested resource that is
     * acceptable for the web user, then invokes the
     * {@link RequestDispatcher#forward(ServletRequest, ServletResponse)} method
     * for that localized resource.
     * 
     * @param request
     *            the request.
     * @param response
     *            the response.
     * @return <code>true</code> if the localized resource was found and its
     *         dispatcher invoked.
     * @throws IOException
     *             if any I/O exception occurred.
     * @throws ServletException
     *             if any servlet exception occurred.
     */
    public boolean forward(ServletRequest request, ServletResponse response)
            throws IOException, ServletException {
        return forward(null, request, response);
    }

    /**
     * Searches for a localized version of the requested resource that is
     * acceptable for the web user, then invokes the
     * {@link RequestDispatcher#include(ServletRequest, ServletResponse)} method
     * for that localized resource.
     * 
     * @param request
     *            the request.
     * @param response
     *            the response.
     * @return <code>true</code> if the localized resource was found and its
     *         dispatcher invoked.
     * @throws IOException
     *             if any I/O exception occurred.
     * @throws ServletException
     *             if any servlet exception occurred.
     */
    public boolean include(ServletRequest request, ServletResponse response)
            throws IOException, ServletException {
        return include(null, request, response);
    }

    /**
     * Searches for a localized version of the resource designated by the
     * provided URI that is acceptable for the web user, then invokes the
     * {@link RequestDispatcher#forward(ServletRequest, ServletResponse)} method
     * for that localized resource.
     * 
     * @param request
     *            the request.
     * @param response
     *            the response.
     * @return <code>true</code> if the localized resource was found and its
     *         dispatcher invoked.
     * @throws IOException
     *             if any I/O exception occurred.
     * @throws ServletException
     *             if any servlet exception occurred.
     */
    public boolean forward(String uri, ServletRequest request,
            ServletResponse response) throws IOException, ServletException {
        request = wrapRequest((HttpServletRequest) request);
        uri = (uri != null) ? uri : ((HttpServletRequest) request)
                .getServletPath();
        RequestDispatcher dispatcher = getDispatcher(uri, request);
        if (dispatcher != null) {
            dispatcher.forward(request, response);
            return true;
        }
        return false;
    }

    /**
     * Searches for a localized version of the resource designated by the
     * provided URI that is acceptable for the web user, then invokes the
     * {@link RequestDispatcher#include(ServletRequest, ServletResponse)} method
     * for that localized resource.
     * 
     * @param request
     *            the request.
     * @param response
     *            the response.
     * @return <code>true</code> if the localized resource was found and its
     *         dispatcher invoked.
     * @throws IOException
     *             if any I/O exception occurred.
     * @throws ServletException
     *             if any servlet exception occurred.
     */
    public boolean include(String uri, ServletRequest request,
            ServletResponse response) throws IOException, ServletException {
        request = wrapRequest((HttpServletRequest) request);
        uri = (uri != null) ? uri : ((HttpServletRequest) request)
                .getServletPath();
        RequestDispatcher dispatcher = getDispatcher(uri, request);
        if (dispatcher != null) {
            dispatcher.include(request, response);
            return true;
        }
        return false;
    }

    /**
     * Searches for a localized version of the resource designated by the
     * provided URI that is acceptable for the web user, then returns the
     * {@link RequestDispatcher} object for that localized resource.
     * 
     * @param uri
     *            the requested uri.
     * @param request
     *            the original request.
     * @return the {@link RequestDispatcher} object for the localized resource,
     *         if found; <code>null</code> otherwise.
     * @throws IOException
     *             if any I/O exception occurred.
     * @throws ServletException
     *             if any servlet exception occurred.
     */
    public RequestDispatcher getDispatcher(String uri, ServletRequest request)
            throws IOException, ServletException {
        boolean[] countryCodes = { true, false };
        for (boolean countryCode : countryCodes) {
            Enumeration<Locale> locales = (Enumeration<Locale>) request
                    .getLocales();
            while (locales.hasMoreElements()) {
                Locale locale = locales.nextElement();
                locale = countryCode ? locale
                        : new Locale(locale.getLanguage());
                RequestDispatcher dispatcher = getLocalizedDispatcher(uri,
                        locale);
                if (dispatcher != null) {
                    return dispatcher;
                }
            }
        }
        RequestDispatcher dispatcher = getLocalizedDispatcher(uri, Locale
                .getDefault());
        if (dispatcher != null) {
            return dispatcher;
        }
        return context.getRequestDispatcher(uri);
    }

    private RequestDispatcher getLocalizedDispatcher(String uri, Locale locale) {
        if (supportedLocales != null) {
            System.err.println("getDispatcher supportedLocales.contains(l): "
                    + locale + " " + supportedLocales.contains(locale));
            if (supportedLocales.contains(locale)) {
                String localizedURI = createLocalizedURI(uri, locale);
                System.err.println("getDispatcher: " + localizedURI);
                if (!chainLocales || isResourceAvailable(localizedURI)) {
                    RequestDispatcher dispatcher = context
                            .getRequestDispatcher(localizedURI);
                    if (dispatcher != null) {
                        return dispatcher;
                    }
                }
            }
        }
        return null;
    }

    private String createLocalizedURI(String requestedURI, Locale locale) {
        String localeStr = locale.toString().toLowerCase();
        if (requestedURI.startsWith("/WEB-INF")) {
            requestedURI = requestedURI.substring("/WEB-INF".length());
            return new StringBuffer("/WEB-INF/").append(localeStr)
                    .append(requestedURI).toString();
        }
        return new StringBuffer("/").append(localeStr).append(requestedURI)
                .toString();
    }

    private boolean isResourceAvailable(String uri) {
        InputStream is = context.getResourceAsStream(uri);
        if (is != null) {
            try {
                is.close();
            } catch (IOException ioe) {
            }
            return true;
        }
        return false;
    }

    private HttpServletRequest wrapRequest(HttpServletRequest request) {
        return new HttpServletRequestWrapper(request) {

            @Override
            public String getMethod() {
                return "GET";
            }
        };

    }
}
