/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * This class is a filter that implements support for internationalization and
 * localization of web resources. It delegates to a {@link I18nDispatcher}
 * object the search for the localized resource appropriate for the web user's
 * acceptable locales.
 * <p>
 * This filter is declared and configured in the deployment descriptor of web
 * applications. It is mapped to the default servlet
 * {@link javacardx.servlet.http.DefaultServlet} that services static resources.
 */
public class I18nFilter implements Filter {

    private I18nDispatcher dispatcher;

    /**
     * Initializes this <code>I18nFilter</code>.
     * <p>
     * This method creates and caches an instance of {@link I18nDispatcher}.
     * 
     * {@inheritDoc}
     */
    public void init(FilterConfig config) throws ServletException {
        dispatcher = new I18nDispatcher(config.getServletContext());
    }

    /**
     * Cleans up this <code>I18nFilter</code> state and used resources.
     * <p>
     * This method clears the reference to the cached {@link I18nDispatcher}
     * object.
     * 
     * {@inheritDoc}
     */
    public void destroy() {
        dispatcher = null;
    }

    /**
     * Handles requests to static resources.
     * <p>
     * This method invokes the {@link I18nDispatcher} object to search for a
     * localized version of the requested resource that is acceptable to the
     * user and forward the request to that localized resource.
     * 
     * {@inheritDoc}
     */
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
        if (!dispatcher.forward(request, response)) {
            chain.doFilter(request, response);
        }
    }
}
