/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import java.util.Calendar;
import java.util.Date;
import java.util.ListResourceBundle;

/**
 * This class is a resource bundle that contains British English-localized
 * resources and components. It only contains those resources and components
 * whose localization differs from the parent English resource bundle (
 * {@link Resources_en}).
 * <p>
 * This class is dynamically loaded at runtime. It must therefore be declared in
 * the Java Card platform-specific application descriptor (
 * <code>javacard.xml</code>) of the web application when the application is
 * intended to be deployed for the <code>en_GB</code> locale.
 * 
 * @see Resources
 * @see Resources_en
 */
public class Resources_en_GB extends ListResourceBundle {

    private Object[][] contents;

    @Override
    public Object[][] getContents() {
        if (contents == null) {
            contents = new Object[][] {
                // LOCALIZE THIS
                { "DateFormatter", new DateFormatter_en_GB() }
                // END OF MATERIAL TO LOCALIZE
            };
        }
        return contents;
    }

    private static class DateFormatter_en_GB extends DateFormatter {

        public DateFormatter_en_GB() {
        }

        @Override
        public String format(Date time) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(time);

            StringBuffer sb = new StringBuffer();

            // LOCALIZE THIS
            sb.append(calendar.get(Calendar.HOUR)).append(':');
            append(sb, calendar.get(Calendar.MINUTE), 2);
            sb.append(calendar.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM")
                    .append(' ');
            sb.append(calendar.get(Calendar.DAY_OF_MONTH)).append('/');
            sb.append(calendar.get(Calendar.MONTH)).append('/');
            sb.append(calendar.get(Calendar.YEAR));
            // END OF MATERIAL TO LOCALIZE

            return sb.toString();
        }
    }
}