/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import java.util.Calendar;
import java.util.Date;
import java.util.ListResourceBundle;

/**
 * This class is a resource bundle that contains French-localized resources and
 * components. It only contains those resources and components whose
 * localization differs from the base resource bundle ({@link Resources}).
 * <p>
 * This class is dynamically loaded at runtime. It must therefore be declared in
 * the Java Card platform-specific application descriptor (
 * <code>javacard.xml</code>) of the web application when the application is
 * intended to be deployed for the <code>fr</code> locale.
 * 
 * @see Resources
 */
public class Resources_fr extends ListResourceBundle {

    private Object[][] contents;

    @Override
    public Object[][] getContents() {
        if (contents == null) {
            contents = new Object[][] {
                    // LOCALIZE THIS
                    { "AUTHORIZE", "AUTORISER" },
                    { "CANCEL", "ANNULER" },
                    { "Time:", "Date et Heure:" },
                    { "Debit:", "D&eacute;bit:" },
                    { "Credit:", "Cr&eacute;dit:" },
                    { "DateFormatter", new DateFormatter_fr() }
                    // END OF MATERIAL TO LOCALIZE
            };
        }
        return contents;
    }

    private static class DateFormatter_fr extends DateFormatter {

        public DateFormatter_fr() {
        }

        @Override
        public String format(Date time) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(time);

            StringBuffer sb = new StringBuffer();

            // LOCALIZE THIS
            sb.append(calendar.get(Calendar.HOUR_OF_DAY)).append('h');
            append(sb, calendar.get(Calendar.MINUTE), 2).append(' ');
            sb.append(calendar.get(Calendar.DAY_OF_MONTH)).append('/');
            sb.append(calendar.get(Calendar.MONTH)).append('/');
            sb.append(calendar.get(Calendar.YEAR));
            // END OF MATERIAL TO LOCALIZE

            return sb.toString();
        }
    }
}