/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit;

import javacard.framework.Shareable;

/**
 * This interface defines the methods of a <em>TicketBook</em> object that may
 * be exposed to applications outside the context of the <em>Transit POS</em>
 * application.
 * <p>
 * The methods exposed by this Shareable Interface perform the following
 * administration and ticketing account operations:
 * <ul>
 * <li>get the ticketbook balance</li>
 * <li>debit the ticketbook</li>
 * <li>get the transaction history (time and amount of debits and credits)</li>
 * </ul>
 * Note that the <em>credit</em> operation is not exposed as this operation is
 * restricted by design to the <em>Transit POS</em> application.
 */
public interface SharedTicketBook extends Shareable {

    /**
     * Returns the ticketbook balance.
     * 
     * @return the ticketbook balance.
     */
    int getBalance();

    /**
     * Debits the ticketbook of the provided ticket count.
     * 
     * @param count
     *            the number of tickets to be debited.
     * @return the new ticketbook balance.
     */
    int debit(int count);

    /**
     * Gets the transaction history. The history is returned as an array of
     * <code>long</code> pairs of the form: {time of transaction,
     * debited/credited ticket count}.
     * <p>
     * If the provided <code>buffer</code> argument is <code>null</code> this
     * method returns the complete transaction history available.
     * <p>
     * If the provided <code>buffer</code> argument is not <code>null</code>
     * this method copies into the provided <code>buffer</code> the transaction
     * history up to the size of the provided buffer.
     * <p>
     * If the provided <code>start</code> parameter is too large, it returns
     * <code>null</code>
     * <p>
     * This method zero fills the unused entries of the buffer.
     * 
     * @param buffer
     *            if not <code>null</code>, the buffer to be reused to return
     *            all or a part of the available transaction history (in which
     *            case the ownership of this buffer must have been transferred
     *            by the calling client to this application); if
     *            <code>null</code>, the complete available history must be
     *            returned in a newly allocated buffer.
     * @param start
     *            contains the offset within the history vector to start. This
     *            parameter is ignored if the complete available history is
     *            being returned.
     * @return all or a part of the available transaction history; the ownership
     *         of the returned buffer is transferred to the calling client.
     */
    public long[][] getHistory(long[][] buffer, int start);

}
