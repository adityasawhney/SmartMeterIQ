/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.transit;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Common utilities.
 */
public class Utils {

    /**
     * Copies content from an input stream to an output stream.
     *
     * @param is the input stream.
     * @param os the output stream.
     * @throws IOException if any I/O exception occurs.
     */
    public static void copy(InputStream is, OutputStream os) throws IOException {
        byte[] buffer = new byte[256];
        int count;
        while ((count = is.read(buffer)) > 0) {
            os.write(buffer, 0, count);
        }
        return;
    }

    private Utils() {
    }
}
