/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.turnstile;

import javacardx.facilities.EventNotificationListener;
import javacardx.facilities.SharedEvent;

/**
 * This class implements an event notification listener that must be registered
 * to catch <em>TicketBook</em> overdraft events in order to prevent further
 * Transit System entrance authorization by the <em>Transit Turnstile</em>
 * application.
 */
public class BlockedEventListener implements EventNotificationListener {
    private TurnstileApplet applet;

    /**
     * Creates an instance of <code>BlockedEventListener</code>.
     * 
     * @param applet
     *            the <code>TurnstileApplet</code> instance.
     */
    public BlockedEventListener(TurnstileApplet applet) {
        this.applet = applet;
    }

    /**
     * Handles <em>TicketBook</em> overdraft events.
     * <p>
     * This method blocks the <code>TurnstileApplet</code> instance.
     * 
     * {@inheritDoc}
     */
    public void notify(SharedEvent e) {
        // block turnstile applet
        applet.setBlocked(true);
    }
}
