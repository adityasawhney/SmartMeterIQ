/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.turnstile;

import javacard.framework.APDU;
import javacard.framework.Applet;
import javacard.framework.AppletEvent;
import javacard.framework.ISOException;
import javacardx.facilities.EventNotificationListener;
import javacardx.facilities.EventRegistry;
import javacardx.facilities.ServiceRegistry;
import javacardx.facilities.SharedEvent;
import javacardx.facilities.Event;
import javacard.framework.JCSystem;

import com.sun.jcdemo.transit.SharedTicketBook;
import javacard.security.Signature;
import javacard.framework.ISO7816;
import javacard.framework.Util;
import javacard.security.DESKey;
import javacard.security.KeyBuilder;
import javacard.security.RandomData;
import javacardx.crypto.Cipher;
import javacardx.framework.Authenticator;
import javacardx.framework.SharedPINAuth;
import javacardx.security.CredentialManager;
import javacardx.framework.TransactionType;
import static javacardx.framework.TransactionTypeValue.REQUIRES_NEW;

/**
 * This class implements the APDU front-end of the <em>Transit Turnstile</em>
 * applet-based application.
 * 
 * This applet interacts over the contactless interface with the
 * <em>Transit Turnstile Terminal</em> in order to permit or deny the
 * <em>Transit System User</em> - the card holder - the access to the
 * <em>Transit System</em> (entrance authorization).
 * <p>
 * The APDU commands that this applet handles are:
 * <dl>
 * <dt>{@link #INITIALIZE_SESSION INITIALIZE_SESSION}</dt>
 * <dd>Initializes a CAD/card interaction session secured by mutual
 * authentication.</dd>
 * <dt>{@link #PROCESS_REQUEST PROCESS_REQUEST}</dt>
 * <dd>Processes an incoming request. The request message signature is verified,
 * then it is dispatched to the relevant handling method. The resulting response
 * message is then signed and sent back. A request can be one of the following.
 * <dl>
 * <dt>{@link #PROCESS_ENTRY PROCESS_ENTRY}</dt>
 * <dd>
 * Processes a transit entry event at an entry zone. If the ticketbook is
 * blocked, the turnstile terminal prevents the user from entering.</dd>
 * <dt>{@link #PROCESS_EXIT PROCESS_EXIT}</dt>
 * <dd>
 * Processes a transit exit event at an exit zone. The transit fee is computed
 * based on the entry and exit zones, and debited from the account. If the
 * ticketbook is already blocked or if the current debit transaction results in
 * the ticketbook to be blocked because of insufficient balance, the turnstile
 * terminal prevents the user from exiting.</dd>
 * <dt>{@link #PROCESS_LET_THROUGH PROCESS_LET_THROUGH}</dt>
 * <dd>
 * Processes a transit a "let through" admin command. The administrator must
 * provide a correct PIN. Upon success, The current ride session is cleared and
 * the turnstile terminal lets the user go through (despite his/her negative
 * balance).</dd>
 * </dl>
 * </dd>
 * </dl>
 * This applet retrieves from the service registry the <em>Ticketbook</em> SIO -
 * a singleton - exposed by the <em>Transit POS</em> application and invokes its
 * Shareable Interface methods to perform the related ticketbook account debit
 * operations. The URI of the <em>Transit POS</em> web application is provided
 * via an application property that can be configured in this application's
 * runtime descriptor. This applet monitors the lifecycle of the
 * <em>Transit POS</em> web application to be notified of the availability of
 * the <em>Ticketbook</em> service (hence removing any dependency that may
 * prevent the deletion of the <em>Transit POS</em> web application and also
 * allowing these interdepending applications to be deployed in any order).
 * 
 * @see com.sun.jcdemo.transit.SharedTicketBook
 * @see javacardx.framework.JCSystem#getAppProperty
 * @see javacardx.facilities.EventRegistry
 * @see javacardx.facilities.ServiceRegistry
 * 
 */
public class TurnstileApplet extends Applet implements AppletEvent {

    /**
     * The application property name that maps the security role to the URI of
     * the authenticator for the remote admin (a ticket booth clerk).
     */
    public static final String ADMIN_MAPPING_PROPERTY = "ADMIN-URI"; // Codes of

    /*
     * INS byte in the command APDU header
     */

    /**
     * The application property name that contains the spec data for the DES key
     * used for authenticating with the POS application.
     */
    public static final String TURNSTILE_KEY_PROPERTY = "TURNSTILE-KEY";

    /**
     * INS value for ISO 7816-4 VERIFY command
     */
    static final byte VERIFY = (byte) 0x20;

    /**
     * INS value for INITIALIZE_SESSION command
     */
    public static final byte INITIALIZE_SESSION = (byte) 0x30;

    /**
     * INS value for PROCESS_REQUEST command
     */
    public static final byte PROCESS_REQUEST = (byte) 0x40;

    /*
     * Tags for TLV records in PROCESS_REQUEST C-APDU
     */

    /**
     * TLV Tag for PROCESS_ENTRY request
     */
    public static final byte PROCESS_ENTRY = (byte) 0xC1;

    /**
     * TLV Tag for PROCESS_EXIT request
     */
    public static final byte PROCESS_EXIT = (byte) 0xC2;

    /**
     * TLV Tag for PROCESS_LET_THROUGH request
     */
    public static final byte PROCESS_LET_THROUGH = (byte) 0xC3;

    /*
     * Offsets of TLV components in PROCESS_REQUEST C-APDU: [CLA, INS, P1, P2,
     * LC T L V...]
     */
    /**
     * TLV tag offset
     */
    static final short TLV_TAG_OFFSET = ISO7816.OFFSET_CDATA;

    /**
     * TLV length offset
     */
    static final short TLV_LENGTH_OFFSET = TLV_TAG_OFFSET + 1;

    /**
     * TLV value offset
     */
    static final short TLV_VALUE_OFFSET = TLV_LENGTH_OFFSET + 1;

    /**
     * Maximum allowed balance
     */
    static final short MAX_BALANCE = (short) 500;

    /**
     * Minimum balance to start transit
     */
    static final short MIN_TRANSIT_BALANCE = (short) 10;

    /**
     * Maximum amount to be credited
     */
    static final short MAX_CREDIT_AMOUNT = (short) 100;

    /**
     * Maximum number of incorrect tries before the PIN is blocked
     */
    static final byte MAX_PIN_TRIES = (byte) 0x03;

    /**
     * Maximum PIN size
     */
    static final byte MAX_PIN_SIZE = (byte) 0x08;

    /**
     * SW bytes for PIN verification failure
     */
    static final short SW_VERIFICATION_FAILED = 0x6300;

    /**
     * SW bytes for PIN validation required
     */
    static final short SW_PIN_VERIFICATION_REQUIRED = 0x6301;

    /**
     * SW bytes for invalid credit amount (amount > MAX_CREDIT_AMOUNT or amount
     * < 0)
     */
    static final short SW_INVALID_TRANSACTION_AMOUNT = 0x6A83;

    /**
     * SW bytes for card blocked
     */
    static final short SW_CARD_BLOCKED = 0x6A84;

    /**
     * SW bytes for wrong signature condition
     */
    static final short SW_WRONG_SIGNATURE = (short) 0x9105;

    /**
     * SW bytes for minimum transit balance not met
     */
    static final short SW_MIN_TRANSIT_BALANCE = (short) 0x9106;

    /**
     * SW bytes for invalid transit state
     */
    static final short SW_INVALID_TRANSIT_STATE = (short) 0x9107;

    /**
     * SW bytes for invalid zone
     */
    static final short SW_INVALID_ZONE = (short) 0x9108;

    /**
     * Maximum value for zone
     */
    static final byte MAX_ZONE = 4;

    /**
     * SW bytes for success, used in MAC
     */
    static final short SW_SUCCESS = (short) 0x9000;

    /**
     * Unique ID length
     */
    static final short UID_LENGTH = (short) 8;

    /**
     * DES key length in bytes
     */
    static final short LENGTH_DES_BYTE = (short) (KeyBuilder.LENGTH_DES / 8);

    /**
     * Host and card challenge length (note: (2 * CHALLENGE_LENGTH) * 8 ==
     * KeyBuilder.LENGTH_DES
     */
    static final short CHALLENGE_LENGTH = (short) 4;

    /**
     * MAC length as generated by Signature.ALG_DES_MAC8_ISO9797_M2
     */
    static final short MAC_LENGTH = (short) 8;

    /**
     * Creates and registers an instance of <code>TurnstileApplet</code>.
     * 
     * {@inheritDoc}
     */
    public static void install(byte[] bArray, short bOffset, byte bLength) {
        // Create a Transit applet instance
        new TurnstileApplet(bArray, bOffset, bLength);
    }

    /**
     * Boolean is set to flag that cryptography configured
     */
    private Boolean crypto_configured = Boolean.TRUE;

    /**
     * Indicates whether the Transit System entrance authorization must be
     * blocked.
     */
    private Boolean blocked = Boolean.TRUE;

    /**
     * 4-bytes Card challenge
     */
    private byte[] cardChallenge; // Transient

    /**
     * Cipher used to encrypt - using the static DES key - the derivation data
     * to form the session key
     */
    private Cipher cipher;

    /**
     * A correlation id that may be used by the backend system to correlate
     * entry and exit events
     */
    private byte correlationId = (byte) 0;

    /**
     * 8-bytes key derivation data, generated from the host challenge and the
     * card challenge
     */
    private byte[] keyDerivationData; // Transient

    /**
     * Random data generator, used to generate the card challenge
     */
    private RandomData random;

    /**
     * DES session key, generated from the derivation data
     */
    private DESKey sessionKey; // Transient key

    /**
     * 8-bytes session key data, generated from the derivation data
     */
    private byte[] sessionKeyData; // Transient

    /**
     * Signature initialized with the DES key and used to verify incoming
     * messages and to sign outgoing messages
     */
    private Signature signature;

    /**
     * DES static key, shared b/w host and card
     */
    private DESKey staticKey;

    /**
     * The <em>Ticketbook</em> SIO.
     */
    private SharedTicketBook ticketBook = null;

    /**
     * The application property name for the <em>Transit POS</em> application
     * URI.
     */
    private String transitPOSAppURI = javacardx.framework.JCSystem
            .getAppProperty("transit-pos-app", null);

    /**
     * Unique ID
     */
    private byte[] uid; // Signature/key objects

    /**
     * Indicates whether or not to use transient session key - for performance
     * measurement only
     */
    private boolean useTransientKey = true;

    /**
     * The authenticator for the remote admin (a ticket booth clerk).
     */
    private SharedPINAuth adminAuthenticator = null;

    /**
     * The entry zone for the current ride.
     */
    private static int entryZone = -1;

    /**
     * Creates an instance of <code>TurnstileApplet</code>.
     * <p>
     * This method creates and registers <em>Transit POS</em> application
     * lifecycle event listeners. These event listeners are in charge of looking
     * up the <em>Ticketbook</em> service when the <em>Transit POS</em>
     * application is first created and resetting any reference to the
     * <em>Ticketbook</em> service when the the <em>Transit POS</em> application
     * is deleted or about to be deleted (hence removing any dependency that may
     * prevent the deletion).
     * <p>
     * This method also creates and registers <em>TicketBook</em> overdraft and
     * credit event listeners for blocking and unblocking
     * <em>Transit System</em> entrance authorizations.
     * 
     * @param bArray
     *            The array containing installation parameters
     * @param bOffset
     *            The starting offset in bArray
     * @param bLength
     *            The length in bytes of the parameter data in bArray
     */
    protected TurnstileApplet(byte[] bArray, short bOffset, byte bLength) {

        setup();

        // if TURNSTILE_KEY_PROPERTY not configured avoid cryptography
        String keyData = javacardx.framework.JCSystem
                .getAppProperty(TURNSTILE_KEY_PROPERTY, null);
        if (keyData == null) {
            crypto_configured = Boolean.FALSE;
        }
        if (crypto_configured) {
            // Create static DES key
            staticKey = (DESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_DES,
                    KeyBuilder.LENGTH_DES,
                    false);

            // Create cipher
            cipher = Cipher.getInstance(Cipher.ALG_DES_CBC_ISO9797_M2, false);
        }

        // Create card challenge transient buffer
        cardChallenge = JCSystem.makeTransientByteArray(CHALLENGE_LENGTH,
                JCSystem.CLEAR_ON_RESET);

        // Create key derivation data transient buffer
        keyDerivationData = JCSystem
                .makeTransientByteArray((short) (2 * CHALLENGE_LENGTH),
                        JCSystem.CLEAR_ON_RESET);

        // Create session key data transient buffer
        sessionKeyData = JCSystem
                .makeTransientByteArray((short) (2 * keyDerivationData.length),
                        JCSystem.CLEAR_ON_RESET);
        // XXX: Allocates more than actual key to contain the complete
        // encrypted key derivation data

        if (crypto_configured) {
            // Create signature
            signature = Signature
                    .getInstance(Signature.ALG_DES_MAC8_ISO9797_M2, false);
        }

        byte aidLen = bArray[bOffset]; // aid length
        if (aidLen == (byte) 0) {
            register();
        } else {
            register(bArray, (short) (bOffset + 1), aidLen);
        }

        // Ignore control info
        bOffset = (short) (bOffset + aidLen + 1);
        byte infoLen = bArray[bOffset]; // control info length
        bOffset = (short) (bOffset + infoLen + 1);

        byte paramLen = bArray[bOffset++]; // applet parameters length

        // Retrieve UID, static key data and the PIN initialization values
        // from
        // installation parameters
        if (paramLen <= (LENGTH_DES_BYTE + UID_LENGTH)
                || paramLen > (LENGTH_DES_BYTE + UID_LENGTH + MAX_PIN_SIZE)) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }
        uid = new byte[UID_LENGTH];
        // Retrieve the UID
        Util.arrayCopy(bArray, bOffset, uid, (short) 0, UID_LENGTH);
        bOffset += UID_LENGTH;

        // Retrieve the static key data
        if (crypto_configured) {
            staticKey.setKey(fixParity(bArray, bOffset, LENGTH_DES_BYTE),
                    bOffset);
        }
        bOffset += LENGTH_DES_BYTE;

        // Retrieve the flag indicating whether or not to use a transient
        // key
        useTransientKey = (bArray[bOffset] != (byte) 0);
        bOffset++;

        if (crypto_configured) {
            // Create transient DES session key
            if (useTransientKey) {
                sessionKey = (DESKey) KeyBuilder
                        .buildKey(KeyBuilder.TYPE_DES_TRANSIENT_DESELECT,
                                KeyBuilder.LENGTH_DES,
                                false);
            } else {
                sessionKey = (DESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_DES,
                        KeyBuilder.LENGTH_DES,
                        false);
            }

            // Create and initialize the ramdom data generator with the UID
            // (seed)
            random = RandomData.getInstance(RandomData.ALG_PSEUDO_RANDOM);
            random.setSeed(uid, (short) 0, UID_LENGTH);

            // Initialize the cipher with the static key
            cipher.init(staticKey, Cipher.MODE_ENCRYPT);
        }
    }

    private void setup() {
        ticketBook = lookupTicketBookService();

        EventRegistry eventRegistry = EventRegistry.getEventRegistry();
        // Transit POS Application lifecycle event listener registration
        EventNotificationListener listener = new EventNotificationListener() {

            public void notify(SharedEvent e) {
                if (e.getURI().equals(Event.EVENT_STANDARD_APP_CREATED_URI)) {
                    ticketBook = lookupTicketBookService();
                    setBlocked(true);
                } else if (e.getURI()
                        .equals(Event.EVENT_STANDARD_APP_DELETING_URI)
                        || e.getURI()
                                .equals(Event.EVENT_STANDARD_APP_DELETED_URI)) {
                    ticketBook = null;
                    setBlocked(true);
                }
            }
        };
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_CREATED_URI,
                listener);
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_DELETING_URI,
                listener);
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_DELETED_URI,
                listener);

        // TicketBook service event listener registration
        BlockedEventListener blockedListener = new BlockedEventListener(this);
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/overdraft",
                blockedListener);
        UnblockedEventListener unblockedListener = new UnblockedEventListener(
                this);
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/credited",
                unblockedListener);
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/unblocked",
                unblockedListener);

        String authenticatorURI = javacardx.framework.JCSystem
                .getAppProperty(ADMIN_MAPPING_PROPERTY, null);
        // For simplicity, assumes it is mapped to only one authenticator
        if (authenticatorURI != null) {
            ServiceRegistry registry = ServiceRegistry.getServiceRegistry();
            Authenticator authenticator = (Authenticator) registry
                    .lookup(authenticatorURI);
            if (authenticator != null && authenticator instanceof SharedPINAuth) {
                adminAuthenticator = (SharedPINAuth) authenticator;
            } // otherwise the let-through operation is disabled
        }
    }

    private SharedTicketBook lookupTicketBookService() {
        String keyData = javacardx.framework.JCSystem
                .getAppProperty(TURNSTILE_KEY_PROPERTY, null);
        CredentialManager.setCredentialManager(new TurnstileCredentialManager(
                keyData), CredentialManager.MODE_SIO_CLIENT);

        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        return (SharedTicketBook) serviceRegistry.lookup(transitPOSAppURI,
                "ticketbook");
    }

    /**
     * Checks the request message signature.
     * 
     * @param buffer
     *            The APDU buffer
     * @return true if the message signature is correct; false otherwise
     */
    private boolean checkMAC(byte[] buffer) {
        if (crypto_configured) {
            byte numBytes = buffer[ISO7816.OFFSET_LC];

            if (numBytes <= MAC_LENGTH) {
                ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
            }

            // Initialize signature with current session key for verification
            signature.init(sessionKey, Signature.MODE_VERIFY);
            // Verify request message signature
            return signature.verify(buffer,
                    ISO7816.OFFSET_CDATA,
                    (short) (numBytes - MAC_LENGTH),
                    buffer,
                    (short) (ISO7816.OFFSET_CDATA + numBytes - MAC_LENGTH),
                    MAC_LENGTH);
        } else {
            return (Boolean.TRUE);
        }
    }

    /**
     * Deselects this applet, resets the admin authenticator and resets the
     * secure session.
     */
    @Override
    public void deselect() {
        // Reset the PIN value
        adminAuthenticator.reset();
        if (!useTransientKey) {
            sessionKey.clearKey();
        }
    }

    /**
     * Fixes the parity on DES key data.
     * 
     * @param buffer
     *            The buffer containing the DES key data
     * @param offset
     *            The offset of the DES key data in the buffer
     * @param messageLength
     *            The length of the DES key data
     * @return The passed-in buffer with the DES key data parity fixed
     */
    private byte[] fixParity(byte[] buffer, short offset, short length) {
        for (byte i = 0; i < length; i++) {
            short parity = 0;
            buffer[(short) (offset + i)] &= 0xFE;
            for (byte j = 1; j < 8; j++) {
                if ((buffer[(short) (offset + i)] & (byte) (1 << j)) != 0) {
                    parity++;
                }
            }
            if ((parity % 2) == 0) {
                buffer[(short) (offset + i)] |= 1;
            }
        }
        return buffer;
    }

    /**
     * Generates a new random card challenge.
     * 
     */
    private void generateCardChallenge() {

        if (crypto_configured) {
            // Generate random card challenge
            random.generateData(cardChallenge, (short) 0, CHALLENGE_LENGTH);
        }
    }

    /**
     * Generates the session key derivation data from the passed-in host
     * challenge and the card challenge.
     * 
     * @param buffer
     *            The APDU buffer
     */
    private void generateKeyDerivationData(byte[] buffer) {
        byte numBytes = buffer[ISO7816.OFFSET_LC];

        if (numBytes < CHALLENGE_LENGTH) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Derivation data: [[8-bytes host challenge], [8-bytes card challenge]]

        // Append host challenge (from buffer) to derivation data
        Util.arrayCopy(buffer,
                ISO7816.OFFSET_CDATA,
                keyDerivationData,
                (short) 0,
                CHALLENGE_LENGTH);
        // Append card challenge to derivation data
        Util.arrayCopy(cardChallenge,
                (short) 0,
                keyDerivationData,
                CHALLENGE_LENGTH,
                CHALLENGE_LENGTH);
    }

    /**
     * Generates the response message MAC: generates the MAC and appends the MAC
     * to the response message.
     * 
     * @param buffer
     *            The APDU buffer
     * @param offset
     *            The offset of the MAC in the buffer
     * @return The resulting length of the response message
     */
    private short generateMAC(byte[] buffer, short offset) {
        if (crypto_configured) {
            // Initialize signature with current session key for signing
            signature.init(sessionKey, Signature.MODE_SIGN);
            // Sign response message and append the MAC to the response message
            short sigLength = signature.sign(buffer,
                    (short) 0,
                    offset,
                    buffer,
                    offset);
            return (short) (offset + sigLength);
        } else {
            return (short) (offset + 8);
        }
    }

    /**
     * Generates a new DES session key from the derivation data.
     * 
     */
    private void generateSessionKey() {
        if (crypto_configured) {
            cipher.doFinal(keyDerivationData,
                    (short) 0,
                    (short) keyDerivationData.length,
                    sessionKeyData,
                    (short) 0);
            // Generate new session key from encrypted derivation data
            sessionKey.setKey(fixParity(sessionKeyData,
                    (short) 0,
                    (short) sessionKeyData.length /* LENGTH_DES_BYTE */),
                    (short) 0);
        }
    }

    /**
     * Initializes a CAD/card interaction session. This is the first step of
     * mutual authentication. A new card challenge is generated and used along
     * with the passed-in host challenge to generate the derivation data from
     * which a new session key is derived. The card challenge is appended to the
     * response message. The response message is signed using the newly
     * generated session key then sent back. Note that mutual authentication is
     * subsequently completed upon successful verification of the signature of
     * the first request received.
     * 
     * @param apdu
     *            The APDU
     */
    private void initializeSession(APDU apdu) {

        // C-APDU: [CLA, INS, P1, P2, LC, [4-bytes Host Challenge]]

        byte[] buffer = apdu.getBuffer();

        if ((buffer[ISO7816.OFFSET_P1] != 0)
                || (buffer[ISO7816.OFFSET_P2] != 0)) {
            ISOException.throwIt(ISO7816.SW_INCORRECT_P1P2);
        }

        byte numBytes = buffer[ISO7816.OFFSET_LC];

        byte count = (byte) apdu.setIncomingAndReceive();

        if (numBytes != CHALLENGE_LENGTH || count != CHALLENGE_LENGTH) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Generate card challenge
        generateCardChallenge();

        // Generate key derivation data from host challenge and card challenge
        generateKeyDerivationData(buffer);

        // Generate session key from derivation data
        generateSessionKey();

        // R-APDU: [[4-bytes Card Challenge], [2-bytes Status Word], [8-bytes
        // MAC]]

        short offset = 0;

        // Append card challenge to response message
        offset = Util.arrayCopyNonAtomic(cardChallenge,
                (short) 0,
                buffer,
                offset,
                CHALLENGE_LENGTH);

        // Append status word to response message
        offset = Util.setShort(buffer, offset, SW_SUCCESS);

        // Sign response message and append MAC to response message
        offset = generateMAC(buffer, offset);

        // Send R-APDU
        apdu.setOutgoingAndSend((short) 0, offset);
    }

    /**
     * Indicates whether <em>Transit System</em> entrance authorizations must be
     * blocked.
     * 
     * @return true if <em>Transit System</em> entrance authorizations must be
     *         blocked; false, otherwise.
     */
    private boolean isBlocked() {
        synchronized (this.blocked) {
            return this.blocked;
        }
    }

    @Override
    public void process(APDU apdu) {

        // C-APDU: [CLA, INS, P1, P2, LC, ...]

        byte[] buffer = apdu.getBuffer();

        // Dispatch C-APDU for processing
        if (!apdu.isISOInterindustryCLA()) {
            switch (buffer[ISO7816.OFFSET_INS]) {
            case INITIALIZE_SESSION:
                initializeSession(apdu);
                return;
            case PROCESS_REQUEST:
                processRequest(apdu);
                return;
            default:
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
            }
        } else {
            if (buffer[ISO7816.OFFSET_INS] == (byte) (0xA4)) {
                return;
            } else if (buffer[ISO7816.OFFSET_INS] == VERIFY) {
                verify(apdu);
            } else {
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
            }
        }
    }

    /**
     * Processes a transit entry event. The passed-in entry zone is recorded and
     * the correlation ID is incremented. The UID and the correlation ID are
     * returned in the response message.
     * 
     * Request Message: [2-bytes Entry zone]
     * 
     * Response Message: [[2-bytes UID], [2-bytes Correlation ID]]
     * 
     * @param buffer
     *            The APDU buffer
     * @param messageOffset
     *            The offset of the request message content in the APDU buffer
     * @param messageLength
     *            The length of the request message content.
     * @return The offset at which content can be appended to the response
     *         message
     */
    private short processEntry(byte[] buffer, short messageOffset,
            short messageLength) {

        // Check if card blocked
        if (isBlocked()) {
            ISOException.throwIt(SW_CARD_BLOCKED);
        }

        // Request Message: [1-byte Entry Zone]

        if (messageLength != 1) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Check consistent transit state: should not currently be in transit
        if (entryZone >= 0) {
            ISOException.throwIt(SW_INVALID_TRANSIT_STATE);
        }

        // mark entry zone and corresponding correlationId
        byte zone = buffer[messageOffset];
        if ((zone <= 0) || (zone > MAX_ZONE)) {
            ISOException.throwIt(SW_INVALID_ZONE);
        }
        transactEntryInfo(zone);

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        short offset = 0;

        // Append UID to response message
        offset = Util.arrayCopy(uid, (short) 0, buffer, offset, UID_LENGTH);

        // Append correlation ID to response message
        offset = Util.setShort(buffer, offset, correlationId);

        return offset;
    }

    /**
     * Processes a transit exit event. The transit fee is computed based on the
     * entry zone and the passed-in exit zone, and debited from the account. The
     * UID and the correlation ID are returned in the response message.
     * 
     * Request Message: [1-bytes Exit Zone]]
     * 
     * Response Message: [[2-bytes UID], [2-bytes Correlation ID]]
     * 
     * @param buffer
     *            The APDU buffer
     * @param messageOffset
     *            The offset of the request message content in the APDU buffer
     * @param messageLength
     *            The length of the request message content.
     * @return The offset at which content can be appended to the response
     *         message
     */
    private short processExit(byte[] buffer, short messageOffset,
            short messageLength) {

        // Check if card blocked
        if (isBlocked()) {
            ISOException.throwIt(SW_CARD_BLOCKED);
        }

        // Request Message: [1-byte Exit Zone]

        if (messageLength != 1) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Check consistent transit state: should be currently in transit
        if (entryZone < 0) {
            ISOException.throwIt(SW_INVALID_TRANSIT_STATE);
        }

        // Get exit zone from request message
        short exitZone = buffer[messageOffset];
        if ((exitZone <= 0) || (exitZone > MAX_ZONE)) {
            ISOException.throwIt(SW_INVALID_ZONE);
        }

        // compute fee required
        short transitFare = 1;
        if (Math.abs(entryZone - exitZone) > 2) {
            // crossing more than 2 zones
            transitFare = 2;
        }

        transactTicketBookDebit(transitFare);

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        short offset = 0;

        // Append UID to response message
        offset = Util.arrayCopy(uid, (short) 0, buffer, offset, UID_LENGTH);

        // Append correlation ID to response message
        offset = Util.setShort(buffer, offset, correlationId);

        return offset;
    }

    /**
     * Processes a transit a "let through" admin command. The entry zone is
     * reset, hence clearing the current ride. The UID and the correlation ID
     * are returned in the response message.
     * 
     * Request Message: [0 Bytes]
     * 
     * Response Message: [[2-bytes UID], [2-bytes Correlation ID]]
     * 
     * @param buffer
     *            The APDU buffer
     * @param messageOffset
     *            The offset of the request message content in the APDU buffer
     * @param messageLength
     *            The length of the request message content.
     * @return The offset at which content can be appended to the response
     *         message
     */
    private short processLetThrough(byte[] buffer, short messageOffset,
            short messageLength) {

        // Check consistent transit state: should be currently in transit
        if (entryZone < 0) {
            ISOException.throwIt(SW_INVALID_TRANSIT_STATE);
        }

        if (adminAuthenticator.isValidated()) {
            // Reset entry zone
            entryZone = -1;
            adminAuthenticator.reset();
        } else {
            ISOException.throwIt(SW_PIN_VERIFICATION_REQUIRED);
        }

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        short offset = 0;

        // Append UID to response message
        offset = Util.arrayCopy(uid, (short) 0, buffer, offset, UID_LENGTH);

        // Append correlation ID to response message
        offset = Util.setShort(buffer, offset, correlationId);

        return offset;
    }

    /**
     * Processes an incoming request. The request message signature is verified,
     * then it is dispatched to the relevant handling method. The response
     * message is then signed and sent back.
     * 
     * @param apdu
     *            The APDU
     */
    private void processRequest(APDU apdu) {

        // C-APDU: [CLA, INS, P1, P2, LC, [Request Message], [8-bytes MAC]]
        // Request Message: [T, L, [V...]]

        byte[] buffer = apdu.getBuffer();

        if ((buffer[ISO7816.OFFSET_P1] != 0)
                || (buffer[ISO7816.OFFSET_P2] != 0)) {
            ISOException.throwIt(ISO7816.SW_INCORRECT_P1P2);
        }

        byte numBytes = buffer[ISO7816.OFFSET_LC];

        byte count = (byte) apdu.setIncomingAndReceive();

        if (numBytes != count) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Check request message signature
        if (!checkMAC(buffer)) {
            ISOException.throwIt(SW_WRONG_SIGNATURE);
        }

        if ((numBytes - MAC_LENGTH) != (buffer[TLV_LENGTH_OFFSET] + 2)) {
            ISOException.throwIt(ISO7816.SW_WRONG_DATA);
        }

        // R-APDU: [[Response Message], [2-bytes Status Word], [8-bytes MAC]]

        short offset = 0;

        // Dispatch request message for processing
        switch (buffer[TLV_TAG_OFFSET]) {
        case PROCESS_ENTRY:
            offset = processEntry(buffer,
                    TLV_VALUE_OFFSET,
                    buffer[TLV_LENGTH_OFFSET]);
            break;
        case PROCESS_EXIT:
            offset = processExit(buffer,
                    TLV_VALUE_OFFSET,
                    buffer[TLV_LENGTH_OFFSET]);
            break;
        case PROCESS_LET_THROUGH:
            offset = processLetThrough(buffer,
                    TLV_VALUE_OFFSET,
                    buffer[TLV_LENGTH_OFFSET]);
            break;
        default:
            ISOException.throwIt(ISO7816.SW_FUNC_NOT_SUPPORTED);
        }

        // Append status word to response message
        offset = Util.setShort(buffer, offset, SW_SUCCESS);

        // Sign response message and append MAC to response message
        offset = generateMAC(buffer, offset);

        // Send R-APDU
        apdu.setOutgoingAndSend((short) 0, offset);
    }

    /**
     * Selects this applet if the Admin authenticator is not blocked due to too
     * many failed tries.
     */
    @Override
    public boolean select() {
        // The applet declines to be selected
        // if the PIN is blocked.
        if (adminAuthenticator.getTriesRemaining() == 0) {
            return false;
        }
        return true;
    }

    /**
     * Blocks or unblocks <em>Transit System</em> entrance authorizations.
     * 
     * @param blocked
     *            whether or not <em>Transit System</em> entrance authorizations
     *            must be blocked.
     */
    void setBlocked(boolean blocked) {
        synchronized (this.blocked) {
            this.blocked = blocked;
        }
    }

    /**
     * Unregisters all listeners this application registered with the event
     * registry.
     */
    @Override
    public void uninstall() {
        EventRegistry eventRegistry = EventRegistry.getEventRegistry();
        eventRegistry.unregister(transitPOSAppURI, "*", null);
    } // Codes of INS byte in the command APDU header

    /**
     * Verifies the PIN.
     * 
     * @param apdu
     *            The APDU
     */
    private void verify(APDU apdu) {

        byte[] buffer = apdu.getBuffer();

        byte numBytes = buffer[ISO7816.OFFSET_LC];

        byte count = (byte) apdu.setIncomingAndReceive();

        if (numBytes != count) {
            ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
        }

        // Verify PIN
        if (adminAuthenticator.check(buffer, ISO7816.OFFSET_CDATA, numBytes) == false) {
            ISOException.throwIt(SW_VERIFICATION_FAILED);
        }
    }

    /**
     * Debits the ticketBook SIO within a transaction
     * 
     * @param transitFare
     *            number of ticket points to debit
     */
    @TransactionType(REQUIRES_NEW)
    void transactTicketBookDebit(short transitFare) {
        // Debit transit fee
        ticketBook.debit(transitFare);
        if (!isBlocked()) {
            // Reset entry zone
            entryZone = -1;
        }

    }

    /**
     * Updates entry zone and correlationId in a transaction
     * 
     * @param zone
     *            entry zone to be stored
     */
    @TransactionType(REQUIRES_NEW)
    void transactEntryInfo(byte zone) {

        // Get/assign entry zone from request message
        entryZone = zone;

        // Increment correlation ID
        correlationId++;
    }
}
