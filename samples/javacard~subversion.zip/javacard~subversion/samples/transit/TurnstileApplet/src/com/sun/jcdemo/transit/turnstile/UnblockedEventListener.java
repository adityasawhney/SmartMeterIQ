/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.turnstile;

import javacardx.facilities.EventNotificationListener;
import javacardx.facilities.SharedEvent;

/**
 * This class implements an event notification listener that must be registered
 * to catch <em>TicketBook</em> credit events in order to allow further Transit
 * System entrance authorization by the <em>Transit Turnstile</em> application.
 */
public class UnblockedEventListener implements EventNotificationListener {
    private TurnstileApplet applet;

    /**
     * Creates an instance of <code>UnblockedEventListener</code>.
     * 
     * @param applet
     *            the <code>TurnstileApplet</code> instance.
     */
    public UnblockedEventListener(TurnstileApplet applet) {
        this.applet = applet;
    }

    /**
     * Handles <em>TicketBook</em> credit events.
     * <p>
     * This method unblocks the <code>TurnstileApplet</code> instance.
     * 
     * {@inheritDoc}
     */
    public void notify(SharedEvent e) {
        // unblock turnstile applet
        applet.setBlocked(false);
    }
}
