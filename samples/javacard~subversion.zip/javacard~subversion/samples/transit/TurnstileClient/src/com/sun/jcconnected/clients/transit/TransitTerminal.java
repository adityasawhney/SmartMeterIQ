/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcconnected.clients.transit;

/**
 * This class implements a <em>Transit Turnstile</em> terminal.
 * 
 * It sends transit system entry and exit events to the on-card applet for
 * processing.
 */
public class TransitTerminal extends Terminal {

    /**
     * Creates a <em>Transit Turnstile</em> terminal.
     * 
     * @param hostName
     *            The hostname where the <em>jcre</em> is running.
     * @param hostPort
     *            The port used by the <em>jcre</em>.
     * @param staticKeyData
     *            The static DES key - secret shared by the on-card and off-card
     *            applications.
     * @throws Exception
     *             if any exception occurred.
     */
    TransitTerminal(String hostName, int hostPort, byte[] staticKeyData)
            throws Exception {
        super(hostName, hostPort, staticKeyData);
    }

    /**
     * Sends a transit system entry event to the on-card applet for processing.
     * 
     * @param entryZone
     *            The entry zone.
     * @throws Exception
     *             if any exception occurred.
     */
    private void processEntry(byte entryZone) throws Exception {

        // Request Message: [1-byte Entry Zone]

        byte[] requestMessage = new byte[1];

        copyByte(entryZone, requestMessage, 0);

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        byte[] responseMessage = processRequest(PROCESS_ENTRY, requestMessage);

        if (responseMessage != null) {

            // Retrieve the UID
            byte[] uid = new byte[UID_LENGTH];
            System.arraycopy(responseMessage, 0, uid, 0, UID_LENGTH);

            // Retrieve the correlation Id
            short correlationId = getShort(responseMessage, 2);

            System.out.println("processEntry: [" + entryZone + "] => " + "[ "
                    + new String(uid) + ", " + correlationId + "]");
        } else {

            System.out.println("processEntry: [" + entryZone + "] => "
                    + "error");
        }
    }

    /**
     * Sends a transit system exit event to the on-card applet for processing.
     * 
     * @param exitZone
     *            The exit zone.
     * @throws Exception
     *             if any exception occurred.
     */
    private void processExit(byte exitZone) throws Exception {

        // Request Message: [1-byte Exit Zone]

        byte[] requestMessage = new byte[1];

        copyByte(exitZone, requestMessage, 0);

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        byte[] responseMessage = processRequest(PROCESS_EXIT, requestMessage);

        if (responseMessage != null) {

            // Retrieve the UID
            byte[] uid = new byte[UID_LENGTH];
            System.arraycopy(responseMessage, 0, uid, 0, UID_LENGTH);

            // Retrieve the correlation Id
            short correlationId = getShort(responseMessage, 2);

            System.out.println("processExit: [" + exitZone + "] => " + "[ "
                    + new String(uid) + ", " + correlationId + "]");
        } else {

            System.out.println("processExit: [" + exitZone + "] => " + "error");
        }
    }

    /**
     * Sends a transit system let through event to the on-card applet for
     * processing.
     * 
     * @throws Exception
     *             if any exception occurred.
     */
    private void processLetThrough() throws Exception {

        // Request Message: [0 bytes]
        byte[] requestMessage = new byte[0];

        // Response Message: [[8-bytes UID], [2-bytes Correlation ID]]

        byte[] responseMessage = processRequest(PROCESS_LET_THROUGH,
                requestMessage);

        if (responseMessage != null) {

            // Retrieve the UID
            byte[] uid = new byte[UID_LENGTH];
            System.arraycopy(responseMessage, 0, uid, 0, UID_LENGTH);

            // Retrieve the correlation Id
            short correlationId = getShort(responseMessage, 2);

            System.out.println("processLetThrough: =>" + "[ " + new String(uid)
                    + ", " + correlationId + "]");
        } else {

            System.out.println("processLetThrough: =>" + "error");
        }
    }

    /**
     * Prints the usage.
     * 
     */
    private static void usage() {
        commonUsage();
        System.out
                .println("<command list>: ([VERIFY <pin>]|[PROCESS_LET_THROUGH]|[PROCESS_ENTRY <entry zone>]|[PROCESS_EXIT <exit zone])*");
    }

    /**
     * Parses and runs the CLI command.
     * 
     * @param args
     *            The CLI arguments: <command list>: ([PROCESS_ENTRY <entry
     *            zone>]|[PROCESS_EXIT <exit zone>]|[PROCESS_EXIT <exit zone])*
     * @throws Exception
     *             if any exception occurred.
     */
    public static void main(String[] args) throws Exception {
        int i = parseCommonArgs(args);
        if (i <= 0) {
            usage();
            System.exit(3);
        }

        TransitTerminal terminal = new TransitTerminal(hostName, port,
                staticKeyData);

        terminal.powerUp();

        try {
            terminal.selectApplet();

            for (; i < args.length; i++) {
                if (args[i].equals("PROCESS_ENTRY")) {
                    if (++i < args.length) {
                        terminal.initializeSession();
                        byte entryZone = new Byte(args[i]).byteValue();
                        terminal.processEntry(entryZone);
                    } else {
                        usage();
                        terminal.powerDown();
                        System.exit(3);
                    }
                } else if (args[i].equals("PROCESS_EXIT")) {
                    if (++i < args.length) {
                        terminal.initializeSession();
                        byte exitZone = new Byte(args[i]).byteValue();
                        terminal.processExit(exitZone);
                    } else {
                        usage();
                        terminal.powerDown();
                        System.exit(3);
                    }
                } else if (args[i].equals("VERIFY")) {
                    if (++i < args.length) {
                        byte[] pin = args[i].getBytes();
                        terminal.verifyPIN(pin);
                    } else {
                        usage();
                        terminal.powerDown();
                        System.exit(3);
                    }
                } else if (args[i].equals("PROCESS_LET_THROUGH")) {
                    terminal.initializeSession();
                    terminal.processLetThrough();
                } else {
                    usage();
                    terminal.powerDown();
                    System.exit(3);
                }
            }
        } catch (Exception e) {
            terminal.powerDown();
            throw e;
        }

        terminal.powerDown();

        System.exit(0);
    }
}
