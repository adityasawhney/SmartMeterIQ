/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.turnstile;

import javacard.security.DESKey;
import javacard.security.Key;
import javacard.security.KeyBuilder;
import javacard.security.PrivateKey;
import javacardx.security.CredentialManager;
import javax.microedition.pki.Certificate;
import javax.microedition.pki.CertificateException;

/**
 * This class implements the (application-defined)
 * <code>CredentialManager</code> of the <em>Transit Turnstile</em> applet
 * application.
 * <p>
 * The <code>TurnstileCredentialManager</code> manages the credentials required
 * to access the <em>Ticketbook</em> service exposed by the <em>Transit POS</em>
 * application. Only the methods invoked for on-card client authentication in
 * the mode {@link CredentialManager#MODE_SIO_CLIENT MODE_SIO_CLIENT} are
 * implemented.
 * <p>
 * An instance of this class is registered for the mode
 * {@link CredentialManager#MODE_SIO_CLIENT MODE_SIO_CLIENT}.
 * 
 * @see com.sun.jcdemo.transit.pos.POSCredentialManager
 */
public class TurnstileCredentialManager extends CredentialManager {

    /**
     * The DES secret key shared with the <em>Transit POS</em> application.
     */
    private DESKey turnstileKey;

    /**
     * Creates an instance of the <code>TurnstileCredentialManager</code> that
     * manages the provided authentication credentials required for accessing
     * the <em>TicketBook</em> service
     * 
     * @param keyData
     *            the data to create the DES secret key.
     */
    public TurnstileCredentialManager(String keyData) {
        if (keyData != null) { // cryptography enabled
            turnstileKey = (DESKey) KeyBuilder.buildKey("DES",
                    KeyBuilder.LENGTH_DES,
                    false);
            byte[] keyDataBytes = keyData.getBytes();
            turnstileKey.setKey(keyDataBytes, (short) 0);
        } else {
            // should throw some kind of exception
        }

    }

    /**
     * Not used.
     * 
     * {@inheritDoc}
     */
    @Override
    public void checkTrusted(Certificate[] certificateChain, String authType,
            String endpointURI, byte mode) throws CertificateException {
        return;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] getAcceptedCertificateIssuers(String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Certificate[] chooseCertificateChain(String[] types,
            String[] issuers, String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public byte[] choosePreSharedKey(String pskIdentity, String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentityHint(String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public String getPSKIdentity(String hint, String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public PrivateKey getMatchingPrivateKey(Certificate certificate,
            String endpointURI, byte mode) {
        return null;
    }

    /**
     * Not used. Returns <code>null</code>.
     * 
     * {@inheritDoc}
     */
    @Override
    public Object[] getTrustedCredentials(String[] aliases, String endpointURI,
            byte mode) {
        return null;
    }

    /**
     * Returns the DES secret key shared with the <em>Transit POS</em>
     * application. This key is only returned if <code>endpointURI</code>
     * corresponds to the <em>Ticketbook</em> service URI and if
     * <code>types</code> contains the DES key type. Returns <code>null</code>
     * otherwise.
     * 
     * {@inheritDoc}
     */
    @Override
    public Key[] getCredentials(String[] types, String endpointURI, byte mode) {
        if (endpointURI.indexOf("/ticketbook") > 0) {
            for (String type : types) {
                if (type.equals(turnstileKey.getTypeName())) {
                    return new Key[] { turnstileKey };
                }
            }
        }
        return null;
    }
}
