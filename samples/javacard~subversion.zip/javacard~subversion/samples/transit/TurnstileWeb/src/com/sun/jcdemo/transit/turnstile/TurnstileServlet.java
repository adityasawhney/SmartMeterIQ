/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.transit.turnstile;

import javacardx.facilities.EventRegistry;
import javacardx.facilities.ServiceRegistry;
import javacardx.framework.JCSystem;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;

import java.io.PrintWriter;
import java.io.IOException;

import com.sun.jcdemo.transit.SharedTicketBook;
import com.sun.jcdemo.transit.I18nDispatcher;
import com.sun.jcdemo.transit.Utils;

import java.io.InputStream;
import javacardx.facilities.EventNotificationListener;
import javacardx.facilities.SharedEvent;
import javacardx.facilities.Event;
import javacardx.framework.Authenticator;
import javacardx.framework.SharedPINAuth;
import javacardx.security.CredentialManager;

public class TurnstileServlet extends HttpServlet {

    /**
     * The application property name that maps the security role to the URI of
     * the authenticator for the remote admin (a ticket booth clerk).
     */
    static final String ADMIN_MAPPING_PROPERTY = "ADMIN-URI";

    static final String TURNSTILE_KEY_PROPERTY = "TURNSTILE-KEY";

    private String transitPOSAppURI = JCSystem
            .getAppProperty("transit-pos-app", null);

    private SharedTicketBook ticketBook = null;

    private Boolean blocked = Boolean.TRUE;

    private SharedPINAuth adminAuthenticator = null;

    // The following is only possible because the servlet is loaded on startup
    // ans is therefore persistent.
    private static int entryZone = 0;

    private static int exitZone = 0;

    /**
     * The <code>I18nDispatcher</code>.
     */
    private I18nDispatcher i18nDispatcher;

    /**
     * Creates an instance of <code>TurnstileServlet</code>.
     */
    public TurnstileServlet() {
    }

    @Override
    public void init(ServletConfig config) {
        i18nDispatcher = new I18nDispatcher(config.getServletContext());

        String keyData = JCSystem.getAppProperty(TURNSTILE_KEY_PROPERTY, null);
        CredentialManager.setCredentialManager(new TurnstileCredentialManager(
                keyData), CredentialManager.MODE_SIO_CLIENT);
        ticketBook = lookupTicketBookService();

        EventRegistry eventRegistry = EventRegistry.getEventRegistry();
        // Transit POS Application lifecycle event listener registration
        EventNotificationListener listener = new EventNotificationListener() {

            public void notify(SharedEvent e) {
                if (e.getURI().equals(Event.EVENT_STANDARD_APP_CREATED_URI)) {
                    ticketBook = lookupTicketBookService();
                    setBlocked(true);
                } else if (e.getURI().equals(Event.EVENT_STANDARD_APP_DELETING_URI)
                        || e.getURI().equals(Event.EVENT_STANDARD_APP_DELETED_URI)) {
                    ticketBook = null;
                    setBlocked(true);
                }
            }
        };
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_CREATED_URI,
                listener);
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_DELETING_URI,
                listener);
        eventRegistry.register(transitPOSAppURI,
                Event.EVENT_STANDARD_APP_DELETED_URI,
                listener);

        // TicketBook service event listener registration
        BlockedEventListener blockedListener = new BlockedEventListener();
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/overdraft",
                blockedListener);
        UnblockedEventListener unblockedListener = new UnblockedEventListener();
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/credited",
                unblockedListener);
        eventRegistry.register(transitPOSAppURI,
                "ticketbook/unblocked",
                unblockedListener);

        String authenticatorURI = JCSystem
                .getAppProperty(ADMIN_MAPPING_PROPERTY, null);
        // For simplicity, assumes it is mapped to only one authenticator
        if (authenticatorURI != null) {
            ServiceRegistry registry = ServiceRegistry.getServiceRegistry();
            Authenticator authenticator = (Authenticator) registry
                    .lookup(authenticatorURI);
            if (authenticator != null && authenticator instanceof SharedPINAuth) {
                adminAuthenticator = (SharedPINAuth) authenticator;
            } // otherwise the let-through operation is disabled
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String path = request.getServletPath();
        if (path.equals("/branding")) {
            InputStream is = getClass()
                    .getResourceAsStream("/com/sun/jcdemo/transit/rsrc/images/title.png");
            if (is != null) {
                Utils.copy(is, response.getOutputStream());
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            }
        } else {
            // Note that getWriter is called before a dispatcher.include
            // to ensure that the PrintWriter can be used for dynamic content
            PrintWriter out = response.getWriter();

            if (ticketBook == null) {
                response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE,
                        "No Ticket Book Service");
                return;
            }

            try {
                if (path.equals("/enter")) {
                    if (entryZone == 0) {
                        if (!isBlocked()) {
                            // Parse request parameters...
                            String zone = request.getParameter("Zone");
                            entryZone = Integer.parseInt(zone);

                            // Build response...
                            i18nDispatcher.include("/WEB-INF/TurnstileExit-1.html",
                                    request, response);
                            out.println(entryZone);
                            i18nDispatcher.include("/WEB-INF/TurnstileExit-footer.html",
                                    request, response);
                        } else {
                            // Redirect to Blocked Page
                            response.sendRedirect(response
                                    .encodeRedirectURL("TurnstileBlocked.html"));
                        }
                    } else {
                        /* User did not exit properly on last ride. */
                        setBlocked(true);
                        response.sendRedirect(response
                                .encodeRedirectURL("TurnstileBlocked.html"));
                    }
                } else if (path.equals("/exit")) {
                    if (entryZone != 0 && exitZone == 0) {
                        if (!isBlocked()) {
                            // Parse request parameters...
                            String zone = request.getParameter("Zone");
                            exitZone = Integer.parseInt(zone);
                            short fare = 1;
                            if (Math.abs(entryZone - exitZone) > 2) {
                                // crossing more than 2 zones
                                fare = 2;
                            }
                            debit(fare);
                            if (!isBlocked()) {
                                // Redirect to enter Page
                                entryZone = exitZone = 0; // reset the ride
                                // tracking
                                response.sendRedirect(response
                                        .encodeRedirectURL("TurnstileMain.html"));
                                return;
                            }
                        }
                        response.sendRedirect(response
                                .encodeRedirectURL("TurnstileBlocked.html"));
                    } else {
                        /* User did not enter or exit properly on last ride. */
                        setBlocked(true);
                        response.sendRedirect(response
                                .encodeRedirectURL("TurnstileBlocked.html"));
                    }
                } else if (path.equals("/let-through")) {
                    // Parse request parameters...
                    String adminPIN = request.getParameter("PIN");
                    if (adminAuthenticator != null) {
                        if (adminPIN != null) {
                            byte[] pin = (adminPIN).getBytes();
                            int pinLength = pin.length;
                            if (JCSystem.getServerURI(adminAuthenticator) != null) {
                                JCSystem.transferOwnership(pin,
                                        adminAuthenticator);
                            }
                            if (adminAuthenticator.check(pin,
                                    (short) 0,
                                    (byte) pinLength)) {
                                entryZone = exitZone = 0; // reset the ride
                                // tracking
                                adminAuthenticator.reset();
                                // Redirect to enter Page
                                response.sendRedirect(response
                                        .encodeRedirectURL("TurnstileMain.html"));
                                return;
                            }
                        }
                        if (adminAuthenticator.getTriesRemaining() > 0) {
                            response.sendRedirect(response
                                    .encodeRedirectURL("TurnstileLetThrough.html"));
                        } else {
                            response.sendError(HttpServletResponse.SC_FORBIDDEN,
                                    "Admin PIN blocked");
                        }
                    } else {
                        response.sendError(HttpServletResponse.SC_FORBIDDEN,
                                "Let through operation not available.");
                    }
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                }
            } catch (SecurityException se) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN,
                        "Ticket book operation denied.");
                return;
            }
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    void setBlocked(boolean blocked) {
        synchronized (this.blocked) {
            this.blocked = blocked;
            if (!blocked) {
                entryZone = exitZone = 0;
            }
        }
    }

    private boolean isBlocked() {
        synchronized (this.blocked) {
            return this.blocked;
        }
    }

    private void debit(short fare) {
        ticketBook.debit(fare);
    }

    @Override
    public void destroy() {
        EventRegistry eventRegistry = EventRegistry.getEventRegistry();
        eventRegistry.unregister(transitPOSAppURI, "*", null);
    }

    private SharedTicketBook lookupTicketBookService() {
        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        SharedTicketBook ticketBook = (SharedTicketBook) serviceRegistry
                .lookup(transitPOSAppURI, "ticketbook");
        return ticketBook;
    }

    /**
     * This class implements an event notification listener that must be
     * registered to catch <em>TicketBook</em> overdraft events in order to
     * prevent further Transit System entrance authorization by the
     * <em>Transit Turnstile</em> application.
     */
    public class BlockedEventListener implements EventNotificationListener {

        /**
         * Handles <em>TicketBook</em> overdraft events.
         * <p>
         * This method blocks the <code>TurnstileServlet</code> instance.
         * 
         * {@inheritDoc}
         */
        public void notify(SharedEvent e) {
            setBlocked(true);
        }
    }

    /**
     * This class implements an event notification listener that must be
     * registered to catch <em>TicketBook</em> credit events in order to allow
     * further Transit System entrance authorization by the
     * <em>Transit Turnstile</em> application.
     */
    public class UnblockedEventListener implements EventNotificationListener {

        /**
         * Handles <em>TicketBook</em> credit events.
         * <p>
         * This method unblocks the <code>TurnstileServlet</code> instance.
         * 
         * {@inheritDoc}
         */
        public void notify(SharedEvent e) {
            setBlocked(false);
        }
    }
}
