/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.walletassist;

import javacardx.framework.JCSystem;
import javacardx.facilities.ServiceRegistry;
import javacardx.framework.TransactionType;
import com.sun.jcdemo.wallet.SharedWalletAccess;
import static javacardx.framework.TransactionTypeValue.REQUIRED;

/**
 * This is the <em>WalletAssist</em> SIO class. The <em>WalletAssist</em> class
 * implements the <em>SharedWalletAccess</em> Shareable Interface. The debit
 * method of the interface simply delegates the debit operation to the
 * <em>debit</em> method of the SIO object of the Classic Wallet applet
 * application's "Wallet" service.
 */
public class WalletAssist implements SharedWalletAccess {

    /** POS application role */
    public static String POS_CLIENT_ROLE = "POS_WEB_CLIENT";

    /**
     * The <em>CLASSIC_WALLET_URI</em> server URI. This URI is the URI of the
     * actual clasic Wallet server application
     */
    private static final String CLASSIC_WALLET_URI = "//aid/a000000062/03010c0601";

    private static byte WALLET_PARAM = (byte) 0x55;

    private String serviceURI;

    /**
     * Creates an instance of <em>WalletAssist</em>.
     * 
     * @param walletInstance
     *            the clasic wallet applet instance.
     */
    public WalletAssist(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    /**
     * Delegates the debit operation to the classic wallet access SIO.
     * 
     * @param debitAmount
     *            the amount to debit
     * @return true if successful, false otherwise
     * @throws SecurityException
     *             if the application client attempting this operation is not in
     *             the <em>"POS_CLIENT"</em> client role.
     */
    @TransactionType(REQUIRED)
    public boolean debit(byte debitAmount) throws SecurityException {
        // verify that the caller is the POS web application
        if (!JCSystem.isClientInRole(POS_CLIENT_ROLE, serviceURI)) {
            throw new SecurityException();
        }

        // delegate to classic wallet SIO
        ServiceRegistry serviceRegistry = ServiceRegistry.getServiceRegistry();
        SharedWalletAccess wallet = (SharedWalletAccess) serviceRegistry
                .lookup(CLASSIC_WALLET_URI, WALLET_PARAM);

        return wallet.debit(debitAmount);
    }

}
