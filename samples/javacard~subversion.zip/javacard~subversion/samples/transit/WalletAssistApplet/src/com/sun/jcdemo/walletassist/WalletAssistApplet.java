/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.walletassist;

import javacard.framework.APDU;
import javacard.framework.Applet;
import javacard.framework.ISO7816;
import javacard.framework.ISOException;
import javacardx.facilities.ServiceRegistry;

/**
 * This is the <em>WalletAssist</em> extended applet class. The
 * <em>WalletAssist</em> applet serves as the bridge application between the
 * Transit POS Web application and the <em>ClassicWallet</em> classic applet
 * application.
 * <p>
 * It registers a service app relative URI called "Wallet" and responds only to
 * the POS Web Client application URI to service requests. It performs the
 * Wallet "debit" operation on the Classic Wallet applet application on behalf
 * of the POS Web client.
 * <p>
 * This extended applet does not directly interact with external card client via
 * APDU. It consistently refuses applet selection. The external client
 * attempting to select this applet will receive a 0x6999 error response status
 * code.
 */
public class WalletAssistApplet extends Applet {

    public static String WALLET_ASSIST_URI = "Wallet";

    private WalletAssistApplet(byte[] bArray, short bOffset, byte bLength) {

        byte iLen = bArray[bOffset]; // aid length
        bOffset = (short) (bOffset + iLen + 1);
        byte cLen = bArray[bOffset]; // info length
        bOffset = (short) (bOffset + cLen + 1);
        byte aLen = bArray[bOffset]; // applet data length

        register();

        // register the WalletAssistFactory in ServiceRegistry
        ServiceRegistry registry = ServiceRegistry.getServiceRegistry();
        registry.register(WALLET_ASSIST_URI, new WalletAssistFactory());
    }

    /**
     * This install() method contructs the <em>WalletAssistApplet</em> applet
     * class as registers itself. The constructor registers the
     * <em>WalletAssistFactory</em> object for the <em>Wallet</em> service
     */
    public static void install(byte[] bArray, short bOffset, byte bLength) {
        // create a Wallet applet instance
        new WalletAssistApplet(bArray, bOffset, bLength);
    }

    /**
     * This select() method simply returns <em>false</em> and refuses selection.
     */
    @Override
    public boolean select() {
        // no external interface
        return false;
    }

    /**
     * This process() method simply returns
     * <em>ISO7816.SW_INS_NOT_SUPPORTED</em> always.
     */
    @Override
    public void process(APDU apdu) {
        // No external acess
        ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);

    }

}

