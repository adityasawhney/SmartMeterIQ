/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jcdemo.walletassist;

import static com.sun.jcdemo.walletassist.WalletAssist.POS_CLIENT_ROLE;
import javacard.framework.Shareable;
import javacardx.facilities.ServiceFactory;
import javacardx.framework.JCSystem;

/**
 * This class implements a <em>WalletAssist</em> service factory. An instance of
 * this class is registered in the service registry in order for the
 * <em>POS Web</em> application to retrieve the <em>WalletAssist</em> delegation
 * service - a singleton SIO instance.
 * 
 */
public class WalletAssistFactory implements ServiceFactory {

    /**
     * The singleton <code>WalletAssist</code> SIO instance to be returned to
     * POS client application.
     */
    private WalletAssist instance = null;

    /**
     * Creates an instance of <code>WalletAssistFactory</code>.
     */
    WalletAssistFactory() {
    }

    /**
     * Returns the singleton <code>WalletAssist</code> instance.
     * 
     * @return the singleton <code>WalletAssist</code> instance.
     * @throws SecurityException
     *             if the application client attempting to retrieve the
     *             <em>WalletAssist</em> service is not the <em>POS Web</em>
     *             application. Note that this is only a fail-fast security
     *             check at lookup-time and that the <code>WalletAssist</code>
     *             SIO implements more specific access controls.
     */
    public Shareable create(String serviceURI, Object parameter)
            throws SecurityException {
        System.err
                .println("JCSystem.getClientURI():" + JCSystem.getClientURI());
        if (!(JCSystem.isClientInRole(POS_CLIENT_ROLE, serviceURI))) {
            throw new SecurityException();
        }
        synchronized (this) {
            if (instance == null) {
                instance = new WalletAssist(serviceURI);
            }
        }
        return instance;
    }
}
