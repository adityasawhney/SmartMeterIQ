/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jcdemo.wallet;

import javacard.framework.Shareable;

/**
 * This interface defines the methods of a <em>WalletAccess</em> object that
 * allows the <em>ClassicWalletApplet</em> application to service debit requests
 * from the <em>Transit POS</em> appplication for ticket purchases.
 * <p>
 * The methods exposed by this Shareable Interface perform the following
 * operations:
 * <ul>
 * <li>debit the requested amount from the wallet balance</li>
 * </ul>
 */
public interface SharedWalletAccess extends Shareable {

    /**
     * Debit the wallet.
     * 
     * @param debitAmount
     *            the amount to be debited from wallet
     * @return true if successful, false otherwise.
     */
    boolean debit(byte debitAmount);
}
