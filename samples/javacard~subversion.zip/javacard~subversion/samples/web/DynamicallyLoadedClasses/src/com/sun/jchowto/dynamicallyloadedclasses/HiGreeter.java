/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.dynamicallyloadedclasses;

/**
 *
 * @author Anki R Nelaturu
 */
public class HiGreeter implements Greeter {

    public String greet() {
        return "Hi";
    }

}
