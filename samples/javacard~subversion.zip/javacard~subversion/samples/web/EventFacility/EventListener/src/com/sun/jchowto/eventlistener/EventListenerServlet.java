/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.eventlistener;

import java.util.Vector;
import java.io.IOException;
import java.io.PrintWriter;

import javacardx.facilities.EventRegistry;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * A Simple Hello Servlet.
 */
public class EventListenerServlet extends HttpServlet {

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        MyListener myListener = new MyListener();
        EventRegistry.getEventRegistry().register("event:///eventsender/testEvent", myListener);
        config.getServletContext().setAttribute("MyListener", myListener);
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        MyListener myListener = (MyListener) getServletContext().getAttribute("MyListener");
        response.setContentType("text/html");
        RequestDispatcher dispatcher = null;

        dispatcher = request.getRequestDispatcher("/WEB-INF/header.i");
        dispatcher.include(request, response);

        Vector<Object> myEvents = myListener.getEventsList();
        int count = myEvents.size();
        
        out.println("        <tr>");
        out.println("            <td bgcolor=\"#FFFFFF\" align=\"center\" valign=\"middle\">");
        out.println("                <table bgcolor=\"#000000\" border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"15\">");
        out.println("                    <tr>");
        out.println("                        <td align=\"center\" bgcolor=\"#FFFFFF\">");       
        
        if (count == 0) {
            out.println("No Events Received.");
        } else {
            out.println(count + " Events Received.");
            out.println("<pre>");
            for (int i = 0; i < count; ++i) {
                out.println("Event " + (i+1) + ": \"" + myEvents.elementAt(i) + "\"");
            }
            out.println("</pre>");
        }
        
        out.println("                        </td>");
        out.println("                    </tr>");
        out.println("                </table>");
        out.println("            </td>");
        out.println("        </tr>");
        
        dispatcher = request.getRequestDispatcher("/WEB-INF/footer.i");
        dispatcher.include(request, response);
    }
}
