/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.eventlistener;

import java.util.Vector;
import javacardx.facilities.EventNotificationListener;
import javacardx.facilities.SharedEvent;

/**
 *
 */
public class MyListener implements EventNotificationListener {

    private Vector<Object> eventsList = new Vector<Object>();

    /**
     * The notify() method is called when requested event is fired
     * @param sharedEvent 
     */
    public void notify(SharedEvent sharedEvent) {
        System.out.println("\n\n\n---------");
        System.out.println("shared event " + sharedEvent.getData());
        eventsList.addElement(sharedEvent.getData());
    }

    public Vector<Object> getEventsList() {
        return eventsList;
    }
}
