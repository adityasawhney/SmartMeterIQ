/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.persistence;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * A Simple Hello Servlet.
 */
public class PresistanceServlet extends HttpServlet {    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */


    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String op = request.getParameter("op");
        String item = request.getParameter("item");

        if (op != null) {
            if (op.equals("Add")) {
                if (item != null) {
                    Database.addItem(item);
                }
            } else if (op.equals("Delete")) {
                if (item != null) {
                    Database.delete(item);
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        RequestDispatcher dispatcher = null;

        dispatcher = request.getRequestDispatcher("/WEB-INF/header.i");
        dispatcher.include(request, response);

        out.println("        <tr>");
        out.println("            <td bgcolor=\"#FFFFFF\" align=\"center\" valign=\"middle\">");
        out.println("                <table bgcolor=\"#000000\" border=\"0\" width=\"100%\" cellspacing=\"1\" cellpadding=\"15\">");
        out.println("                    <tr>");
        out.println("                        <td align=\"center\" bgcolor=\"#FFFFFF\">");

        out.println("</b><big><big>Simple Database</big></big></b>");
        out.println("<form method=\"get\" action=\"database\">");
        out.println("   <table border = 0>");
        out.println("       <tr>");
        out.println("           <td>Item : </td><td colspan=2><input type=\"text\" name=\"item\"></input></td>");
        out.println("       </tr>");
        out.println("       <tr>");
        out.println("           <td>&nbsp;</td>");
        out.println("           <td><input type=\"submit\" name=\"op\" value=\"Add\"></td>");
        out.println("           <td><input type=\"submit\" name=\"op\" value=\"Delete\"></td>");
        out.println("       </tr>");
        out.println("       <tr>");
        out.println("           <td colspan=3><hr></td>");
        out.println("       </tr>");
        out.println("       <tr>");
        out.println("           <td colspan=3><b>Items in Database</b></td>");
        out.println("       </tr>");
        out.println("<tr>");
        out.println("   <td colspan=3><textarea readonly rows=\"5\" cols=\"20\">");
        if(Database.getItems().size() <= 0) {
            out.print("&nbsp;\n&nbsp;\nDatabase is Empty;\n&nbsp;\n&nbsp;");
        } else {
        for (String str : Database.getItems()) {
            out.println(str);
        }
        }
        out.println("</textarea></td>");
        out.println("</tr>");
        out.println("   </table>");
        out.println("</form>");

        out.println("                        </td>");
        out.println("                    </tr>");
        out.println("                </table>");
        out.println("            </td>");
        out.println("        </tr>");

        dispatcher = request.getRequestDispatcher("/WEB-INF/footer.i");
        dispatcher.include(request, response);

    }
}
