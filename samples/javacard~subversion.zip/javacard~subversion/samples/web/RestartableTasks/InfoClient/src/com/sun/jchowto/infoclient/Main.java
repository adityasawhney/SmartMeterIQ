/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */

package com.sun.jchowto.infoclient;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 *
 */
public class Main {


    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 8079;
        if (args.length == 2) {
            host = args[0];
            port = Integer.parseInt(args[1]);
        }
        Socket socket = new Socket(host, port);
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("test");
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        String result = dis.readUTF();
        socket.close();
        System.out.println("\n" + result + "\n");
    }

}
