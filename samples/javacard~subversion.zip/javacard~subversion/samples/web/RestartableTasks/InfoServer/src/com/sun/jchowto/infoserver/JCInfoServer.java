/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.infoserver;

import javax.microedition.io.Connector;
import javax.microedition.io.ServerSocketConnection;
import javax.microedition.io.SocketConnection;

/**
 * A Simple ping-like server to demonstrate Restartable Tasks.<br>
 * Runs on port 8079 and sends a random string for every socket client.
 */
public class JCInfoServer implements Runnable {
    private static int hitCounter = 0;
    private static int tiredCounter = 0;
    private static int normalCounter = 0;
    private static String[] TIRED_MESSAGES = new String[] {
            "Oh come on, stop pinging me",
            "Go to hell",
            "Go get some coffee",
            "I am tired",
            "Don't you have anything else to do?",
            "Eeeeeenough"
    };

    private static String[] NORMAL_MESSAGES = new String[] {
            "Hello! I am Java Card",
            "I am the Next Generation in Java Card Family",
            "I have exciting new features",
            "I support all JDK 6 language features",
            "I have new @TransactionType annotation for transactions",
            "I can do multi threading too :)",
            "Oh, at last you can use Strings also"
    };

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        ServerSocketConnection serverSocketConnection = null;
        try {
            serverSocketConnection = (ServerSocketConnection) Connector.open("socket://:8079");
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        Thread.yield();
        String message = null;
        while (true) {
            try {
                SocketConnection socketConnection = (SocketConnection) serverSocketConnection.acceptAndOpen();
                socketConnection.openDataInputStream().readUTF();

                boolean tired = normalCounter >= NORMAL_MESSAGES.length;
                if (tired) {
                    normalCounter = 0;
                    message = TIRED_MESSAGES[tiredCounter];
                    tiredCounter = (tiredCounter + 1) % TIRED_MESSAGES.length;
                } else {
                    message = NORMAL_MESSAGES[normalCounter];
                    normalCounter++;
                }
                socketConnection.openDataOutputStream().writeUTF("[Hit-" + (++hitCounter) + "] " + message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}