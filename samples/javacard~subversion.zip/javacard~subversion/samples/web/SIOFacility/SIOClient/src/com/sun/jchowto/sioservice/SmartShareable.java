/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.sioservice;

import javacard.framework.Shareable;

/**
 *
 */
public interface SmartShareable extends Shareable {
    void setValue(int value);

    int getValue();
}
