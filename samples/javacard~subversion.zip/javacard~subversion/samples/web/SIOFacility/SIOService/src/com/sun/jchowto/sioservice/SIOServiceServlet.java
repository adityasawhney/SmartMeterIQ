/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.sioservice;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public class SIOServiceServlet extends HttpServlet {

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        RequestDispatcher dispatcher = null;
        int value = -1;
        try {
            value = Integer.parseInt(request.getParameter("value"));
        } catch (Exception ex) {
            //
        }

        SmartSIOFactory factory = (SmartSIOFactory) getServletContext().getAttribute("SmartSIO-Factory");
        factory.getSIO().setValue(value);

        dispatcher = request.getRequestDispatcher("/WEB-INF/header.i");
        dispatcher.include(request, response);

        dispatcher = request.getRequestDispatcher("/WEB-INF/index1.i");
        dispatcher.include(request, response);

        out.println(value);

        dispatcher = request.getRequestDispatcher("/WEB-INF/index2.i");
        dispatcher.include(request, response);

        dispatcher = request.getRequestDispatcher("/WEB-INF/footer.i");
        dispatcher.include(request, response);
    }
}
