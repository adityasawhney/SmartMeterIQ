/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.sioservice;

import javacardx.framework.JCSystem;

/**
 *
 */
public class SmartSIO implements SmartShareable {
    private int value = 0;

    public void setValue(int value) {
        this.value = value;
    }

    public int getValue() {
        //String clientURI = JCSystem.getClientURI();
        //if(!JCSystem.isClientInRole("sr", clientURI)) {
        //    throw new SecurityException("Client '" + clientURI + "'is not trusted");
        //}
        return value;
    }

}
