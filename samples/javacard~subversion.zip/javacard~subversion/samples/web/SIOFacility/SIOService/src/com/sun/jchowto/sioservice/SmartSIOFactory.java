/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.sioservice;

import javacard.framework.Shareable;
import javacardx.facilities.ServiceFactory;

/**
 *
 */
public class SmartSIOFactory implements ServiceFactory {

    SmartSIO sio = new SmartSIO();

    public SmartSIOFactory() {
        //
    }

    public Shareable create(String serviceURI, Object parameter) {
        return sio;
    }

    public SmartSIO getSIO() {
        return sio;
    }
}
