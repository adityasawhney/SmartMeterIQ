/*
 * Copyright (c) 2009 Sun Microsystems, Inc.
 * All rights reserved.
 * Use is subject to license terms.
 */
package com.sun.jchowto.transactions;

import javacardx.framework.TransactionType;
import javacardx.framework.TransactionTypeValue;

/**
 *
 * @author Anki R Nelaturu
 */
public class SomeValue {

    private static String value = "100";

    public static String getValue() {
        return value;
    }
    
    @TransactionType(TransactionTypeValue.REQUIRES_NEW)
    public static void setValue(String value, boolean crash) throws Exception {
        // Even though we set the this.value to new value, if crash happens, it will be rolledback.
        SomeValue.value = value;
        if (crash) {
            throw new Exception("crashed");
        }
    }
}
